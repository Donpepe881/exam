<?php

class User implements IHTTPGET, IHTTPPOST, IHTTPPUT, IHTTPDELETE
{
    //Egy felhasználó adatainak lekérdezése
    public function GET() : void
    {
        if(isset($_GET["id"]) && filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT))
        {
            $id = filter_input(INPUT_GET, "id", FILTER_SANITIZE_NUMBER_INT);
            $data = Model::GetUser($id);
            if(count($data) == 1)
            {
                View::setResponse(new JSONResponse($data[0]));
            }
            else
            {
                View::setResponse(new JSONResponse(array("error" => "A megadott felhasználó nem található!")));
            }
        }
        else
        {
            View::setResponse(new JSONResponse(array("error" => "Nem megfelelő, vagy hiányos azonosító!")));
        }
    }
    
    //Egy új felhasználó rögzítése
    public function POST() : void
    {
        $input = file_get_contents("php://input"); //Teljes request body
        $json = json_decode($input, true);
        if(is_array($json))
        {
            if(isset($json["username"]) && isset($json["password"]) && isset($json["fullname"]) && trim($json["username"]) != "" && trim($json["password"]) != "" && trim($json["fullname"]) != "")
            {
                if(Model::AddNewUser(htmlspecialchars(trim($json["username"])), hash("sha256", trim($json["password"])), htmlspecialchars(trim($json["fullname"]))))
                {
                    View::setResponse(new JSONResponse(array("result" => "Success!")));
                }
                else
                {
                    View::setResponse(new JSONResponse(array("error" => "Beszúrási hiba!")));
                }
            }
            else
            {
                View::setResponse(new JSONResponse(array("error" => "Hiányos adatok!")));
            }
        }
        else
        {
            View::setResponse(new JSONResponse(array("error" => "Nem értelmezhető bemenet!")));
        }
    }
    
    //Egy már létező felhasználó módosítása
    public function PUT() : void
    {
        if(isset($_GET["id"]) && filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT))
        {
            $id = filter_input(INPUT_GET, "id", FILTER_SANITIZE_NUMBER_INT);
            $input = file_get_contents("php://input"); //Teljes request body
            $json = json_decode($input, true);
            if(is_array($json))
            {
                if(isset($json["username"]) && isset($json["password"]) && isset($json["fullname"]) && trim($json["username"]) != "" && trim($json["password"]) != "" && trim($json["fullname"]) != "")
                {
                    if(Model::ModifyUser($id, htmlspecialchars(trim($json["username"])), hash("sha256", trim($json["password"])), htmlspecialchars(trim($json["fullname"]))))
                    {
                        View::setResponse(new JSONResponse(array("result" => "Success!")));
                    }
                    else
                    {
                        View::setResponse(new JSONResponse(array("error" => "Módosítási hiba!")));
                    }
                }
                else
                {
                    View::setResponse(new JSONResponse(array("error" => "Hiányos adatok!")));
                }
            }
            else
            {
                View::setResponse(new JSONResponse(array("error" => "Nem értelmezhető bemenet!")));
            }
        }
        else
        {
            View::setResponse(new JSONResponse(array("error" => "Nem megfelelő, vagy hiányos azonosító!")));
        }
    }
    
    //Egy létező felhasználó törlése
    public function DELETE() : void
    {
        if(isset($_GET["id"]) && filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT))
        {
            $id = filter_input(INPUT_GET, "id", FILTER_SANITIZE_NUMBER_INT);
            if($data = Model::DeleteUser($id))
            {
                View::setResponse(new JSONResponse(array("result" => "Success!")));
            }
            else
            {
                View::setResponse(new JSONResponse(array("error" => "A megadott felhasználó nem található!")));
            }
        }
        else
        {
            View::setResponse(new JSONResponse(array("error" => "Nem megfelelő, vagy hiányos azonosító!")));
        }
    }
}
