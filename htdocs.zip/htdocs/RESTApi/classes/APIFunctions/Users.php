<?php

class Users implements IHTTPGET
{
    //Az összes (lehet szűrhető) lekérdezése
    public function GET() : void
    {
        $data = Model::GetUsers();
        if(count($data) > 0)
        {
            View::setResponse(new JSONResponse($data));
        }
        else
        {
            View::setResponse(new JSONResponse(array("error" => "Nem található felhasználó!")));
        }
    }
    
    //ITT tehát nincs POST, PUT, DELETE --> nem tud egyszerre több felhasználót feltölteni, módosítani, törölni egy hívés keretében jelenleg
}
