<?php

abstract class Model
{
    private static PDO $pdo;
    
    public static function Connect() : void
    {
        global $conf;
        try
        {
            self::$pdo = new PDO("mysql:host={$conf["DBHost"]};dbname={$conf["DBName"]};port={$conf["DBPort"]}", $conf["DBUser"], $conf["DBPass"]);
            self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } 
        catch (Exception $ex) 
        {
            throw new DBException("Az adatbázis kapcsolódás sikertelen!", $ex);
        }
    }
    
    public static function AddNewUser(string $username, string $encPass, string $fullName) : bool
    {
        try
        {
            $prep = self::$pdo->prepare("INSERT INTO `users` VALUES (NULL, :user, :pass, :full)");
            $prep->bindParam(":user", $username, PDO::PARAM_STR);
            $prep->bindParam(":pass", $encPass, PDO::PARAM_STR);
            $prep->bindParam(":full", $fullName, PDO::PARAM_STR);
            return $prep->execute();
        }
        catch (Exception $ex)
        {
            throw new DBException("Sikertelen felhasználó felvitel!", $ex);
        }
    }
    
    public static function ModifyUser(int $id, string $username, string $encPass, string $fullName) : bool
    {
        try
        {
            $prep = self::$pdo->prepare("UPDATE `users` SET `username` = :user, `password` = :pass, `fullname` = :full WHERE `id` = :id");
            $prep->bindParam(":user", $username, PDO::PARAM_STR);
            $prep->bindParam(":pass", $encPass, PDO::PARAM_STR);
            $prep->bindParam(":full", $fullName, PDO::PARAM_STR);
            $prep->bindParam(":id", $id, PDO::PARAM_INT);
            return $prep->execute();
        }
        catch (Exception $ex)
        {
            throw new DBException("Sikertelen felhasználó módosítás!", $ex);
        }
    }
    
    public static function DeleteUser(int $id) : bool
    {
        try
        {
            $prep = self::$pdo->prepare("DELETE FROM `users` WHERE `id` = :id");
            $prep->bindParam(":id", $id, PDO::PARAM_INT);
            return $prep->execute();
        }
        catch (Exception $ex)
        {
            throw new DBException("Sikertelen felhasználó törlés!", $ex);
        }
    }
    
    public static function GetUser(int $id) : array
    {
        try
        {
            $prep = self::$pdo->prepare("SELECT * FROM `users` WHERE `id` = :id");
            $prep->bindParam(":id", $id, PDO::PARAM_INT);
            $prep->execute();
            $userInfo = $prep->fetchAll(PDO::FETCH_ASSOC);
            $prep->closeCursor();
            return $userInfo;
        } 
        catch (Exception $ex) 
        {
            throw new DBException("Sikertelen felhasználó lekérdezés!", $ex);
        }
    }
    
    public static function GetUsers() : array
    {
        try
        {
            $prep = self::$pdo->query("SELECT * FROM `users`");
            $userInfo = $prep->fetchAll(PDO::FETCH_ASSOC);
            $prep->closeCursor();
            return $userInfo;
        } 
        catch (Exception $ex) 
        {
            throw new DBException("Sikertelen összes felhasználó lekérdezés!", $ex);
        }
    }
}
