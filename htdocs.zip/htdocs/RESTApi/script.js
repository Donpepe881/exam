async function GetUsers() {
    fetch("http://localhost/RESTApi/index.php?method=USERS",
        {
            method: "GET"
        })
        .then(apiresponse => apiresponse.json())
        .then(jsonData => {
            console.log(jsonData);
            var dtable = document.getElementById("dataTable");
            dtable.innerHTML = "";
            var table = document.createElement("table");
            var header = document.createElement("tr");
            var id = document.createElement("th");
            id.innerHTML = "Azonosító";
            var username = document.createElement("th");
            username.innerHTML = "Felhasználónév";
            var pass = document.createElement("th");
            pass.innerHTML = "Jelszó";
            var name = document.createElement("th");
            name.innerHTML = "Teljes név";
            var del = document.createElement("th");
            del.innerHTML = "Törlés";
            var mod = document.createElement("th");
            mod.innerHTML = "Módosítás";
            header.appendChild(id);
            header.appendChild(username);
            header.appendChild(pass);
            header.appendChild(name);
            header.appendChild(del);
            header.appendChild(mod);
            table.appendChild(header);
            for (var i = 0; i < jsonData.length; i++) {
                var row = document.createElement("tr");
                var id = document.createElement("td");
                id.innerHTML = jsonData[i].id;
                var user = document.createElement("td");
                user.innerHTML = jsonData[i].username;
                var password = document.createElement("td");
                password.innerHTML = jsonData[i].password;
                var fullname = document.createElement("td");
                fullname.innerHTML = jsonData[i].fullname;
                var deluser = document.createElement("td");
                deluser.innerHTML = "<button onclick=\"DeleteUser(" + jsonData[i].id + ");\">Törlés</button>";
                var moduser = document.createElement("td");
                moduser.innerHTML = "<button onclick=\"FormForUser(" + jsonData[i].id + ");\">Módosítás</button>";
                row.appendChild(id);
                row.appendChild(user);
                row.appendChild(password);
                row.appendChild(fullname);
                row.appendChild(deluser);
                row.appendChild(moduser);
                table.appendChild(row);
            }
            dtable.appendChild(table);
        });
}

async function AddNewUser() {
    fetch("http://localhost/RESTApi/index.php?method=USER",
        {
            method: "POST",
            headers:
            {
                "Content-type": "application/json"
            },
            body: JSON.stringify(
                {
                    "username": document.getElementById("username").value,
                    "password": document.getElementById("pass").value,
                    "fullname": document.getElementById("name").value
                })
        })
        .then(apiresponse => apiresponse.json())
        .then(response => {
            console.log(response);
            var target = document.getElementById("result");
            if (response.hasOwnProperty("error")) {
                target.innerHTML = response.error;
                target.setAttribute("class", "error");
            }
            else {
                target.innerHTML = response.result;
                target.setAttribute("class", "success");
                GetUsers();
            }
        });
}

async function DeleteUser(id) {
    fetch("http://localhost/RESTApi/index.php?method=USER&id=" + id,
        {
            method: "DELETE"
        })
        .then(apiresponse => apiresponse.json())
        .then(response => {
            console.log(response);
            var target = document.getElementById("result");
            if (response.hasOwnProperty("error")) {
                target.innerHTML = response.error;
                target.setAttribute("class", "error");
            }
            else {
                target.innerHTML = response.result;
                target.setAttribute("class", "success");
                GetUsers();
            }
        });
}

async function FormForUser(id) {
    fetch("http://localhost/RESTApi/index.php?method=USER&id=" + id,
        {
            method: "GET"
        })
        .then(apiresponse => apiresponse.json())
        .then(response => {
            console.log(response);
            if (response.hasOwnProperty("error")) {
                var target = document.getElementById("result");
                target.innerHTML = response.error;
                target.setAttribute("class", "error");
            }
            else {
                document.getElementById("username").value = response.username;
                document.getElementById("name").value = response.fullname;
                document.getElementById("pass").value = "";
                var button = document.getElementById("DoCall");
                button.innerHTML = "Módosítás";
                button.setAttribute("onclick", "ModifyUser(" + response.id + ");");
            }
        });
}

async function ModifyUser(id) {
    fetch("http://localhost/RESTApi/index.php?method=USER&id=" + id,
        {
            method: "PUT",
            headers:
            {
                "Content-type": "application/json"
            },
            body: JSON.stringify(
                {
                    "username": document.getElementById("username").value,
                    "password": document.getElementById("pass").value,
                    "fullname": document.getElementById("name").value
                })
        })
        .then(apiresponse => apiresponse.json())
        .then(response => {
            console.log(response);
            var target = document.getElementById("result");
            if (response.hasOwnProperty("error")) {
                target.innerHTML = response.error;
                target.setAttribute("class", "error");
            }
            else {
                target.innerHTML = response.result;
                target.setAttribute("class", "success");
                GetUsers();
                document.getElementById("username").value = "";
                document.getElementById("name").value = "";
                document.getElementById("pass").value = "";
                var button = document.getElementById("DoCall");
                button.innerHTML = "Felvitel";
                button.setAttribute("onclick", "AddNewUser();");
            }
        });
}