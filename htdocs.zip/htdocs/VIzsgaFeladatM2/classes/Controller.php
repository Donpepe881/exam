<?php

class Controller
{
    public static function Init(): void
    {
        ModelDB::Init();
        View::Init("index.html");
    }

    public static function Route()
    {
        //$page = isset($_GET["page"]) ? htmlspecialchars($_GET["page"]) : "index";
        if (isset($_GET["page"])) {
            $page = htmlspecialchars($_GET["page"]);
        } elseif (isset($_SESSION["name"])) {
            $page = "main";
        } else {
            $page = "transmission";
        }
        /*$pages = Model::ReadCSV("pages");
        $pageData = "";
        foreach($pages["data"] as $pageRow)
        {
            if($pageRow[0] == $page)
            {
                $pageData = $pageRow;
                break;
            }
        }*/
        $pageData = ModelDB::GetPage($page);
        if ($pageData != false) {
            //$subPageTemplate = call_user_func(array("Controller", ucfirst($page)."Controller"));
            $subPageTemplate = call_user_func(array(ucfirst($page) . "Page", "Run"));
            if ($pageData[2] != "false") {
                $pageTemplate = Template::Load("{$pageData[2]}.html");
                $pageTemplate->AddData("PAGECONTENT", $subPageTemplate->Render());
            } else {
                $pageTemplate = $subPageTemplate;
            }
        } else {
            $pageTemplate = self::Error404Controller();
        }
        View::getBaseTemplate()->AddData("CONTENT", $pageTemplate->Render());
    }


    private static function Error404Controller(): Template
    {
        $template = Template::Load("notFound.html");
        $template->AddData("CONTENT", "Az oldal nem létezik!");
        $template->AddData("TITLE", "A megadott oldal nem található!");
        return $template;
    }

    /*private static function WelcomeController() : Template
    {
        View::getBaseTemplate()->AddData("ADDHEADER", "<script src=\"templates/welcomeScript.js\"></script>");
        $template = Template::Load("welcome.html");
        if(isset($_POST["register"]))
        {
            $writeback = true;
            if(isset($_POST["name"]) && filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL) && filter_input(INPUT_POST, "email2", FILTER_VALIDATE_EMAIL) && isset($_POST["pass"]) && isset($_POST["pass2"]))
            {
                $name = htmlspecialchars($_POST["name"]);
                $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
                $pass = htmlspecialchars($_POST["pass"]);
                if($email == filter_input(INPUT_POST, "email2", FILTER_SANITIZE_EMAIL))
                {
                    if($pass == htmlspecialchars($_POST["pass2"]))
                    {
                        if(preg_match("/[0-9]+/", $pass) && strtolower($pass) != $pass && strtoupper($pass) != $pass && mb_strlen($pass) >= 8)
                        {
                            Model::WriteCSV("users", array(array($name, $email, hash("sha256", $pass))), ";", true);
                            $template->AddData("RESULT", "Sikeres regisztráció!");
                            $template->AddData("RESULTCLASS", "success");
                            $writeback = false;
                        }
                        else
                        {
                            $template->AddData("RESULT", "Gyenge jelszó! A jelszónak legalább 8 karakteresnek kell lennie, melyben kis-nagy betű és szám is szerepel!");
                            $template->AddData("RESULTCLASS", "fail");
                        }
                    }
                    else
                    {
                        $template->AddData("RESULT", "Nem egyező jelszavak!");
                        $template->AddData("RESULTCLASS", "fail");
                    }
                }
                else
                {
                    $template->AddData("RESULT", "Nem egyező email címek!");
                    $template->AddData("RESULTCLASS", "fail");
                }
            }
            else
            {
                $template->AddData("RESULT", "Hiányos adatok!");
                $template->AddData("RESULTCLASS", "fail");
            }
            if($writeback) //logikai értékeket nem kell külön kiértékelni
            {
                $template->AddData("RNAME", $_POST["name"]);
                $template->AddData("REMAIL", $_POST["email"]);
                $template->AddData("REMAILK", $_POST["email2"]);
            }
        }
        elseif(isset($_POST["login"]))
        {
            if(filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL) && isset($_POST["password"]))
            {
                $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
                $pass = hash("sha256", htmlspecialchars($_POST["password"]));
                $logins = Model::ReadCSV("users");
                $login = false;
                foreach ($logins["data"] as $row)
                {
                    if(trim($row[1]) == trim($email) && trim($row[2]) == trim($pass))
                    {
                        $login = true;
                        $_SESSION["name"] = $row[0];
                        break;
                    }
                }
                if($login)
                {
                    $template->AddData("RESULT", "Sikeres belépés!");
                    $template->AddData("RESULTCLASS", "success");
                    $_SESSION["auth"] = true;
                    header("Location: index.php");
                }
                else
                {
                    $template->AddData("RESULT", "Hibás felhasználónév / jelszó!");
                    $template->AddData("RESULTCLASS", "fail");
                    $template->AddData("LEMAIL", $email);
                    session_destroy();
                }
            }
            else
            {
                $template->AddData("RESULT", "Hiányos adatok!");
                $template->AddData("RESULTCLASS", "fail");
                session_destroy();
            }
        }
        return $template;
    }
    
    private static function MainController() : Template
    {
        //View::getBaseTemplate()->AddData("ADDHEADER", "<style>body{color: red;}</style>");
        $template = Template::Load("main.html");
        $template->AddData("PAGECONTENT", "<h1>Főoldal</h1><p>Üdvözlünk az oldalunkon! Sikeresen beléptél!</p>");
        return $template;
    }
    
    private static function Vedett1Controller() : Template
    {
        if(isset($_SESSION["name"]))
        {
            $template = Template::Load("vedett1.html");
            $template->AddData("TITLE", "Védett oldal");
            return $template;
        }
        header("Location: index.php?page=notAllowed");
        return Template::Parse("");
    }
    
    private static function UsersController() : Template
    {
        if(isset($_SESSION["name"]))
        {
            $template = Template::Load("users.html");
            $template->AddData("TITLE", "Felhasználók");
            $tableData = Model::ReadCSV("users");
            $tableContent = "";
            foreach($tableData["data"] as $row)
            {
                $rowTemplate = Template::Parse("<tr><td>§NAME§</td><td>§EMAIL§</td><td>§PASS§</td></tr>");
                $rowTemplate->AddData("NAME", $row[0]);
                $rowTemplate->AddData("EMAIL", $row[1]);
                $rowTemplate->AddData("PASS", $row[2]);
                $tableContent .= $rowTemplate->Render();
            }
            $template->AddData("USERS", $tableContent);
            return $template;
        }
        header("Location: index.php?page=notAllowed");
        return Template::Parse("");
    }
    
    private static function LogoutController() : Template
    {
        session_destroy();
        header("Location: index.php");
        return Template::Parse("");
    }
    
    private static function NotAllowedController() : Template
    {
        $template = Template::Load("notAllowed.html");
        $template->AddData("CONTENT", "A megadott oldal megtekintéséhez előbb jelentkezzen be!");
        return $template;
    }*/
}
