<?php

abstract class ModelDB
{
    private static PDO $pdo;

    public static function Init()
    {
        self::$pdo = new PDO("mysql:host=localhost:3307;dbname=vizsgam", "pedro", "123456aA");
        self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public static function GetPage(string $key): bool|array
    {
        try {
            $result = self::$pdo->query("SELECT * FROM `pages` WHERE `key` = " . self::$pdo->quote($key));
            if ($result->rowCount() == 1) {
                $data = $result->fetchAll(PDO::FETCH_DEFAULT)[0];
                $result->closeCursor();
                return $data;
            }
            return false;
        } catch (Exception $ex) {

        }
    }


    public static function UploadDatas(string $szeria, string $gyarto, string $tipus, string $nev, string $telefon, string $email, string $statusz): bool
    {
        try {
            $prep = self::$pdo->prepare("INSERT INTO `products` VALUES (NULL, :szeria, :gyarto, :tipus, NOW(), NOW(), :nev, :telefon, :email, :statusz)");
            $prep->bindParam(":szeria", $szeria, PDO::PARAM_INT);
            $prep->bindParam(":gyarto", $gyarto, PDO::PARAM_STR);
            $prep->bindParam(":tipus", $tipus, PDO::PARAM_STR);
            $prep->bindParam(":nev", $nev, PDO::PARAM_STR);
            $prep->bindParam(":telefon", $telefon, PDO::PARAM_STR);
            $prep->bindParam(":email", $email, PDO::PARAM_STR);
            $prep->bindParam(":statusz", $statusz, PDO::PARAM_STR);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen adatbevitel!", $ex);
        }
    }

    public static function GetProductDatas(): array
    {
        $result = self::$pdo->query("SELECT * FROM `products` ORDER BY `products`.`statusz` ASC");
        $datas = $result->fetchAll(PDO::FETCH_ASSOC);
        $result->closeCursor();
        return $datas;
    }


    public static function GetStatusDatas(): array
    {
        $result = self::$pdo->query("SELECT * FROM `status` ");
        $datas = $result->fetchAll(PDO::FETCH_ASSOC);
        $result->closeCursor();
        return $datas;
    }

    public static function UpdateStatus(string $statusData, string $id): bool
    {
        try {
            $prep = self::$pdo->prepare("UPDATE `products` SET `products`.`statusz` = :statusData WHERE `products`.`id` = :id");
            $prep->bindParam(":statusData", $statusData, PDO::PARAM_STR);
            $prep->bindParam(":id", $id, PDO::PARAM_STR);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen Státusz módosítás!", $ex);
        }
    }




}
