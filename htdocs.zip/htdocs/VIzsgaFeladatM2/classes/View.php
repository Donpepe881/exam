<?php

class View
{
    private static Template $baseTemplate;
    
    public static function getBaseTemplate(): Template
    {
        return self::$baseTemplate;
    }

    public static function setBaseTemplate(Template $baseTemplate): void
    {
        self::$baseTemplate = $baseTemplate;
    }
    
    public static function Init(string $templateFilename) : void
    {
        self::setBaseTemplate(Template::Load($templateFilename));
    }
    
    public static function FinalRender() : void
    {
        print(self::$baseTemplate->Render());
    }
}