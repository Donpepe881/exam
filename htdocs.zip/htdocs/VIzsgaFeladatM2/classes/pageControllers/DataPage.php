<?php

class DataPage
{


    public static function ChangeStatus(Template $template)
    {

        if (isset($_POST["id"])) {

            $id = filter_input(INPUT_POST, "id", FILTER_SANITIZE_NUMBER_INT);

            var_dump($id);

            if (isset($_POST["status"])) {
                $status = htmlspecialchars(trim($_POST["status"]));

                ModelDB::UpdateStatus($status, $id);
            }
        }
    }


    public static function ChangeColor($status): string
    {

        $color = "";
        if ($status == "Beérkezett") {
            $color = "lightblue";
        } elseif ($status == "Hibafeltárás") {
            $color = "red";
        } elseif ($status == "Alkatrész beszerzés alatt") {
            $color = "orange";
        } elseif ($status == "Javítás") {
            $color = "purple";
        } elseif ($status == "Kész") {
            $color = "green";
        }
        return $color;
    }




    public static function Run(): Template
    {

        $template = Template::Load("data.html");

        $productData = ModelDB::GetProductDatas();
        $productStatus = ModelDB::GetStatusDatas();

        self::ChangeStatus($template);



        foreach ($productData as $datas) {
            foreach ($productStatus as $status) {


                $template->AddData("DATAS", "
            
            <table class='table table-striped' >
            <thead>
                <tr>
                <th>Azonosító</th>
                <th>Szériaszám</th>
                <th>Gyártó</th>
                <th>Típus</th>
                <th>Leadás dátuma</th>
                <th>Státusz</th>
                <th>Utolsó státuszváltozás időpontja</th>
                <th>Státusz módosítás</th>
                </tr>
            </thead>
            <tbody>
                <tr style='background-color:;'>
                <td>{$datas['id']}</td>
                <td>{$datas['szériaszám']}</td>
                <td>{$datas['gyártó']}</td>
                <td>{$datas['típus']}</td>
                <td>{$datas['leadás']}</td>
                <td>{$datas['statusz']}</td>
                <td>{$datas['utolsó státuszváltozás időpontja']}</td>
                
                <td>
                <form method='post' id='statusInput'>
                <input type='hidden' value='int({$datas['id']})' name='id'>
                <select name='status' onchange=\"document.querySelector('#statusInput').submit();\">
                    
                        <option>{$status['Beérkezett']}</option>
                        <option>{$status['Hibafeltárás']}</option>
                        <option>{$status['Alkatrész beszerzés alatt']}</option>
                        <option>{$status['Javítás']}</option>
                        <option>{$status['Kész']}</option>
                    </select>
                </form>
                </td>
                </tr>
            </tbody>
            </table>
            
            ");
            }
        }

        return $template;
    }
}