<?php

class LogoutPage
{
    public static function Run() : Template
    {
        session_destroy();
        header("Location: index.php");
        return Template::Parse("");
    }
}
