<?php

class MainPage
{
    public static function Run() : Template
    {
        //View::getBaseTemplate()->AddData("ADDHEADER", "<style>body{color: red;}</style>");
        $template = Template::Load("main.html");
        $template->AddData("PAGECONTENT", "<h1>Főoldal</h1><p>Üdvözlünk az oldalunkon! Sikeresen beléptél!</p>");
        return $template;
    }
}
