<?php

class TransmissionPage
{


    public static function InsertDatas(Template $template)
    {

        if (isset($_POST["szeria"]) && isset($_POST["gyarto"]) && isset($_POST["tipus"]) && isset($_POST["nev"]) && isset($_POST["telefon"]) && isset($_POST["email"])) {

            $szeria = ($_POST["szeria"]);
            $gyarto = htmlspecialchars($_POST["gyarto"]);
            $tipus = htmlspecialchars($_POST["tipus"]);
            $nev = htmlspecialchars($_POST["nev"]);
            $telefon = htmlspecialchars($_POST["telefon"]);
            $email = htmlspecialchars($_POST["email"]);
            $statusz = "Beérkezett";

        }
        if (ModelDB::UploadDatas($szeria, $gyarto, $tipus, $nev, $telefon, $email, $statusz)) {
            $template->AddData("RESULT", "Sikeres adat feltöltés!");
            $template->AddData("RESULTCLASS", "success");
        } else {
            $template->AddData("RESULT", "Sikertelen adat feltöltés!");
            $template->AddData("RESULTCLASS", "false");
        }

    }

    public static function Run(): Template
    {

        $template = Template::Load("transmission.html");

        if (isset($_POST["update"])) {
            self::InsertDatas($template);
        }
        return $template;
    }
}