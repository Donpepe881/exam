<?php

class WelcomePage
{
    public static function Register(Template $template) : void
    {
        $writeback = true;
            if(isset($_POST["name"]) && filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL) && filter_input(INPUT_POST, "email2", FILTER_VALIDATE_EMAIL) && isset($_POST["pass"]) && isset($_POST["pass2"]))
            {
                $name = htmlspecialchars($_POST["name"]);
                $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
                $pass = htmlspecialchars($_POST["pass"]);
                if($email == filter_input(INPUT_POST, "email2", FILTER_SANITIZE_EMAIL))
                {
                    if($pass == htmlspecialchars($_POST["pass2"]))
                    {
                        if(preg_match("/[0-9]+/", $pass) && strtolower($pass) != $pass && strtoupper($pass) != $pass && mb_strlen($pass) >= 8)
                        {
                            Model::WriteCSV("users", array(array($name, $email, hash("sha256", $pass))), ";", true);
                            $template->AddData("RESULT", "Sikeres regisztráció!");
                            $template->AddData("RESULTCLASS", "success");
                            $writeback = false;
                        }
                        else
                        {
                            $template->AddData("RESULT", "Gyenge jelszó! A jelszónak legalább 8 karakteresnek kell lennie, melyben kis-nagy betű és szám is szerepel!");
                            $template->AddData("RESULTCLASS", "fail");
                        }
                    }
                    else
                    {
                        $template->AddData("RESULT", "Nem egyező jelszavak!");
                        $template->AddData("RESULTCLASS", "fail");
                    }
                }
                else
                {
                    $template->AddData("RESULT", "Nem egyező email címek!");
                    $template->AddData("RESULTCLASS", "fail");
                }
            }
            else
            {
                $template->AddData("RESULT", "Hiányos adatok!");
                $template->AddData("RESULTCLASS", "fail");
            }
            if($writeback) //logikai értékeket nem kell külön kiértékelni
            {
                $template->AddData("RNAME", $_POST["name"]);
                $template->AddData("REMAIL", $_POST["email"]);
                $template->AddData("REMAILK", $_POST["email2"]);
            }
    }
    
    private static function Login(Template $template)
    {
        if(filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL) && isset($_POST["password"]))
            {
                $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
                $pass = hash("sha256", htmlspecialchars($_POST["password"]));
                $logins = Model::ReadCSV("users");
                $login = false;
                foreach ($logins["data"] as $row)
                {
                    if(trim($row[1]) == trim($email) && trim($row[2]) == trim($pass))
                    {
                        $login = true;
                        $_SESSION["name"] = $row[0];
                        break;
                    }
                }
                if($login)
                {
                    $template->AddData("RESULT", "Sikeres belépés!");
                    $template->AddData("RESULTCLASS", "success");
                    $_SESSION["auth"] = true;
                    header("Location: index.php");
                }
                else
                {
                    $template->AddData("RESULT", "Hibás felhasználónév / jelszó!");
                    $template->AddData("RESULTCLASS", "fail");
                    $template->AddData("LEMAIL", $email);
                    session_destroy();
                }
            }
            else
            {
                $template->AddData("RESULT", "Hiányos adatok!");
                $template->AddData("RESULTCLASS", "fail");
                session_destroy();
            }
    }
    
    public static function Run() : Template
    {
        View::getBaseTemplate()->AddData("ADDHEADER", "<script src=\"templates/welcomeScript.js\"></script>");
        $template = Template::Load("welcome.html");
        if(isset($_POST["register"]))
        {
            self::Register($template);
        }
        elseif(isset($_POST["login"]))
        {
            self::Login($template);
        }
        return $template;
    }
}
