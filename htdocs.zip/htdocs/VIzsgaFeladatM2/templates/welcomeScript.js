function ViewRegister()
{
    document.getElementById("register").style = "display: block;";
    document.getElementById("login").style = "display: none;";
}

function ViewLogin()
{
    document.getElementById("register").style = "display: none;";
    document.getElementById("login").style = "display: block;";
}