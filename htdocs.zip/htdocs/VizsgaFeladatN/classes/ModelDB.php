<?php

abstract class ModelDB
{
    private static PDO $pdo;

    public static function Init()
    {
        self::$pdo = new PDO("mysql:host=localhost:3307;dbname=basicmvcn", "pedro", "123456aA");
        self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public static function GetPage(string $key): bool|array
    {
        try {
            $result = self::$pdo->query("SELECT * FROM `pages` WHERE `key` = " . self::$pdo->quote($key));
            if ($result->rowCount() == 1) {
                $data = $result->fetchAll(PDO::FETCH_DEFAULT)[0];
                $result->closeCursor();
                return $data;
            }
            return false;
        } catch (Exception $ex) {

        }
    }

    public static function Register(string $email, string $pass, string $name, string $birthplace, string $date): bool
    {
        try {
            $prep = self::$pdo->prepare("INSERT INTO `users` VALUES (NULL, :email, :pass, :name, :birthplace, :date)");
            $prep->bindParam(":email", $email, PDO::PARAM_STR);
            $prep->bindParam(":pass", $pass, PDO::PARAM_STR);
            $prep->bindParam(":name", $name, PDO::PARAM_STR);
            $prep->bindParam(":birthplace", $birthplace, PDO::PARAM_STR);
            $prep->bindParam(":date", $date, PDO::PARAM_STR);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen regisztráció!", $ex);
        }
    }

    public static function Login(): array
    {
        $prep = self::$pdo->query("SELECT `email`, `password` FROM `users`");
        $data = $prep->fetchAll(PDO::FETCH_BOTH);
        $prep->closeCursor();
        return $data;
    }

    public static function DataFirst(int $id, string $name, string $birthplace, string $date, string $national, string $intro, string $hobbies, string $phone): bool
    {
        try {
            $prep = self::$pdo->prepare("INSERT INTO `datafirst` VALUES (:id, :name, :birthplace, :date, :national, :intro, :hobbies, :phone)");
            $prep->bindParam(":id", $id, PDO::PARAM_INT);
            $prep->bindParam(":name", $name, PDO::PARAM_STR);
            $prep->bindParam(":birthplace", $birthplace, PDO::PARAM_STR);
            $prep->bindParam(":date", $date, PDO::PARAM_STR);
            $prep->bindParam(":national", $national, PDO::PARAM_STR);
            $prep->bindParam(":intro", $intro, PDO::PARAM_STR);
            $prep->bindParam(":hobbies", $hobbies, PDO::PARAM_STR);
            $prep->bindParam(":phone", $phone, PDO::PARAM_STR);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen adatfeltöltés!", $ex);
        }
    }

    public static function DataSecond(int $id, string $schoolnev, string $schoolname, string $firstdate, string $lastdate, string $position): bool
    {
        try {
            $prep = self::$pdo->prepare("INSERT INTO `school` VALUES (:id, :schoolnev, :schoolname, :firstdate, :lastdate, :position)");
            $prep->bindParam(":id", $id, PDO::PARAM_INT);
            $prep->bindParam(":schoolnev", $schoolnev, PDO::PARAM_STR);
            $prep->bindParam(":schoolname", $schoolname, PDO::PARAM_STR);
            $prep->bindParam(":firstdate", $firstdate, PDO::PARAM_STR);
            $prep->bindParam(":lastdate", $lastdate, PDO::PARAM_STR);
            $prep->bindParam(":position", $position, PDO::PARAM_STR);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen adatfeltöltés!", $ex);
        }
    }

    public static function GetId(): array
    {
        $prep = self::$pdo->query("SELECT `name`, `id` FROM `users`");
        $data = $prep->fetchAll(PDO::FETCH_BOTH);
        $prep->closeCursor();
        return $data;
    }


    public static function DataPicture(string $imageSource, string $imageName, string $imageProfile): bool
    {
        try {
            $prep = self::$pdo->prepare("INSERT INTO `pictures` VALUES (:imageSource, :imageName, :imageProfile) LIMIT 3");
            $prep->bindParam(":imageSource", $imageSource, PDO::PARAM_STR);
            $prep->bindParam(":imageName", $imageName, PDO::PARAM_STR);
            $prep->bindParam(":imageProfile", $imageProfile, PDO::PARAM_STR);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen adatfeltöltés!", $ex);
        }
    }


    public static function GetUserId(string $email): array
    {
        try {
            $result = self::$pdo->query("SELECT `id` FROM `users` WHERE `email` = " . self::$pdo->quote($email));
            if ($result->rowCount() == 1) {
                $data = $result->fetchAll(PDO::FETCH_ASSOC)[0];
                $result->closeCursor();
                return $data;
            }
        } catch (Exception $ex) {
            throw new DBException("Sikertelen adategyeztetés!", $ex);
        }
    }

    public static function GetFirstDatas(): array
    {
        $result = self::$pdo->query("SELECT * FROM `datafirst` ");
        $datas = $result->fetchAll(PDO::FETCH_ASSOC);
        $result->closeCursor();
        return $datas;
    }

    public static function GetSchoolDatas(): array
    {
        $result = self::$pdo->query("SELECT * FROM `school` ");
        $datas = $result->fetchAll(PDO::FETCH_ASSOC);
        $result->closeCursor();
        return $datas;
    }

    public static function GetPicturesDatas(): array
    {
        $result = self::$pdo->query("SELECT `imageSource`, `imageName` FROM `pictures` LIMIT 3");
        $datas = $result->fetchAll(PDO::FETCH_BOTH);
        $result->closeCursor();
        return $datas;
    }

    public static function FirstUpdate(int $id, string $name, string $birthplace, string $date, string $national, string $intro, string $hobbies, string $phone): bool
    {
        try {
            $prep = self::$pdo->prepare("UPDATE `datafirst` SET `name` = :name, `birthplace` = :birthplace, `date` = :date, `national` = :national, `intro` = :intro, `hobbies` = :hobbies, `phone` = :phone WHERE `id` = :id ");
            $prep->bindParam(":id", $id, PDO::PARAM_INT);
            $prep->bindParam(":name", $name, PDO::PARAM_STR);
            $prep->bindParam(":birthplace", $birthplace, PDO::PARAM_STR);
            $prep->bindParam(":date", $date, PDO::PARAM_STR);
            $prep->bindParam(":national", $national, PDO::PARAM_STR);
            $prep->bindParam(":intro", $intro, PDO::PARAM_STR);
            $prep->bindParam(":hobbies", $hobbies, PDO::PARAM_STR);
            $prep->bindParam(":phone", $phone, PDO::PARAM_STR);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen adatfeltöltés!", $ex);
        }
    }


    public static function SecondUpdate(int $id, string $schoolnev, string $schoolname, string $firstdate, string $lastdate, string $position): bool
    {
        try {
            $prep = self::$pdo->prepare("UPDATE `school` SET `schoolnev` = :schoolnev, `schoolname` = :schoolname, `firstdate` = :firstdate, `lastdate` = :lastdate, `position` = :position WHERE `id` = :id");
            $prep->bindParam(":id", $id, PDO::PARAM_INT);
            $prep->bindParam(":schoolnev", $schoolnev, PDO::PARAM_STR);
            $prep->bindParam(":schoolname", $schoolname, PDO::PARAM_STR);
            $prep->bindParam(":firstdate", $firstdate, PDO::PARAM_STR);
            $prep->bindParam(":lastdate", $lastdate, PDO::PARAM_STR);
            $prep->bindParam(":position", $position, PDO::PARAM_STR);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen adatmódosítás!", $ex);
        }
    }
    /* public static function UpdateStatus(string $statusData, int $id): bool
    {
        try {
            $prep = self::$pdo->prepare("UPDATE `products` SET `Státusz` = :statusData WHERE `products`.`id` = :id");
            $prep->bindParam(":statusData", $statusData, PDO::PARAM_STR);
            $prep->bindParam(":id", $id, PDO::PARAM_INT);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen Státusz módosítás!", $ex);
        }
    } */

}