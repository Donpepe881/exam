<?php

use function PHPSTORM_META\type;

class ProfilePage
{

    public static function DataFirst(Template $template)
    {
        if (isset($_POST["name"]) && isset($_POST["birthplace"]) && isset($_POST["date"]) && isset($_POST["national"]) && isset($_POST["intro"]) && isset($_POST["hobbies"]) && isset($_POST["phone"])) {

            $name = htmlspecialchars($_POST["name"]);
            $birthplace = htmlspecialchars($_POST["birthplace"]);
            $date = htmlspecialchars($_POST["date"]);
            $national = htmlspecialchars($_POST["national"]);
            $intro = htmlspecialchars($_POST["intro"]);
            $hobbies = htmlspecialchars($_POST["hobbies"]);
            $phone = htmlspecialchars($_POST["phone"]);

            $getUserId = ModelDB::GetId();
            foreach ($getUserId as $datas) {
                if ($name == $datas[0]) {
                    $id = $datas[1];
                }
            }

            if (ModelDB::DataFirst($id, $name, $birthplace, $date, $national, $intro, $hobbies, $phone)) {
                $template->AddData("RESULT", "Sikeres adat feltöltés!");
                $template->AddData("RESULTCLASS", "success");
            } else {
                $template->AddData("RESULT", "Sikertelen adat feltöltés!");
                $template->AddData("RESULTCLASS", "false");
            }
        }
    }


    public static function DataFirstUpdate(Template $template)
    {
        if (isset($_POST["name"]) && isset($_POST["birthplace"]) && isset($_POST["date"]) && isset($_POST["national"]) && isset($_POST["intro"]) && isset($_POST["hobbies"]) && isset($_POST["phone"])) {

            $name = htmlspecialchars($_POST["name"]);
            $birthplace = htmlspecialchars($_POST["birthplace"]);
            $date = htmlspecialchars($_POST["date"]);
            $national = htmlspecialchars($_POST["national"]);
            $intro = htmlspecialchars($_POST["intro"]);
            $hobbies = htmlspecialchars($_POST["hobbies"]);
            $phone = htmlspecialchars($_POST["phone"]);

            $getUserId = ModelDB::GetId();
            foreach ($getUserId as $datas) {
                if ($name == $datas[0]) {
                    $id = $datas[1];
                }
            }

            var_dump($id);

            if (ModelDB::FirstUpdate($id, $name, $birthplace, $date, $national, $intro, $hobbies, $phone)) {
                $template->AddData("RESULT", "Sikeres adat módosítás!");
                $template->AddData("RESULTCLASS", "success");
            } else {
                $template->AddData("RESULT", "Sikertelen adat módosítás!");
                $template->AddData("RESULTCLASS", "false");
            }
        }
    }



    public static function DataSecond(Template $template)
    {
        if (isset($_POST["schoolnev"]) && isset($_POST["schoolname"]) && isset($_POST["firstdate"]) && isset($_POST["lastdate"]) && isset($_POST["position"])) {

            $schoolnev = htmlspecialchars($_POST["schoolnev"]);
            $schoolname = htmlspecialchars($_POST["schoolname"]);
            $firstdate = htmlspecialchars($_POST["firstdate"]);
            $lastdate = htmlspecialchars($_POST["lastdate"]);
            $position = htmlspecialchars($_POST["position"]);

            $getUserId = ModelDB::GetId();
            foreach ($getUserId as $datas) {
                if ($schoolnev == $datas[0]) {
                    $id = $datas[1];
                }
            }

            if (ModelDB::DataSecond($id, $schoolnev, $schoolname, $firstdate, $lastdate, $position)) {
                $template->AddData("RESULT", "Sikeres adat feltöltés!");
                $template->AddData("RESULTCLASS", "success");
            } else {
                $template->AddData("RESULT", "Sikertelen adat feltöltés!");
                $template->AddData("RESULTCLASS", "false");
            }
        }
    }


    public static function DataSecondUpdate(Template $template)
    {
        if (isset($_POST["schoolnev"]) && isset($_POST["schoolname"]) && isset($_POST["firstdate"]) && isset($_POST["lastdate"]) && isset($_POST["position"])) {

            $schoolnev = htmlspecialchars($_POST["schoolnev"]);
            $schoolname = htmlspecialchars($_POST["schoolname"]);
            $firstdate = htmlspecialchars($_POST["firstdate"]);
            $lastdate = htmlspecialchars($_POST["lastdate"]);
            $position = htmlspecialchars($_POST["position"]);

            $getUserId = ModelDB::GetId();
            foreach ($getUserId as $datas) {
                if ($schoolnev == $datas[0]) {
                    $id = $datas[1];
                }
            }
            var_dump($id);

            if (ModelDB::SecondUpdate($id, $schoolnev, $schoolname, $firstdate, $lastdate, $position)) {
                $template->AddData("RESULT", "Sikeres adat módosítás!");
                $template->AddData("RESULTCLASS", "success");
            } else {
                $template->AddData("RESULT", "Sikertelen adat módosítás!");
                $template->AddData("RESULTCLASS", "false");
            }
        }
    }



    public static function UploadPictures(Template $template)
    {
        define("MAXWIDTH", 600);
        define("MAXHEIGHT", 600);

        if (isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {

            $mime = finfo_file(finfo_open(FILEINFO_MIME_TYPE), $_FILES["image"]["tmp_name"]);
            if ($mime == "image/jpeg") {

                if (move_uploaded_file($_FILES["image"]["tmp_name"], "tmp.jpg")) {
                    $kep = imagecreatefromjpeg("tmp.jpg");
                    $arany = imagesx($kep) / imagesy($kep);

                    if (imagesx($kep) > MAXWIDTH) {
                        $meretezett = imagecreatetruecolor(MAXWIDTH, intval(MAXWIDTH / $arany));
                        imagecopyresampled($meretezett, $kep, 0, 0, 0, 0, MAXWIDTH, intval(MAXWIDTH / $arany), imagesx($kep), imagesy($kep));
                        $kep = $meretezett;
                    }

                    if (imagesy($kep) > MAXHEIGHT) {
                        $meretezett = imagecreatetruecolor(intval(MAXHEIGHT * $arany), MAXHEIGHT);
                        imagecopyresampled($meretezett, $kep, 0, 0, 0, 0, intval(MAXHEIGHT * $arany), MAXHEIGHT, imagesx($kep), imagesy($kep));
                        $kep = $meretezett;
                    }

                    $logo = imagecreatefrompng("kepek\logo.png");
                    $logoSize = intval(imagesx($kep) / 4);

                    imagecopyresampled($kep, $logo, 15, 15, 0, 0, $logoSize, $logoSize, imagesx($logo), imagesy($logo));

                    imagepng($kep, "kepek/" . basename($_FILES["image"]["name"]) . ".png");
                    unlink("tmp.jpg");

                    $response["info"] = "Sikeres konverzió!";
                    $response["image"] = "kepek/" . basename($_FILES["image"]["name"]) . ".png";

                    $imageSource = htmlspecialchars($response["image"]);
                    $imageName = htmlspecialchars(substr($imageSource, strrpos($imageSource, "/") + 1));
                    $imageProfile = "false";


                    $template->AddData("RESPONSE", "<h2>Sikeres konverzió!</h2><br>");
                    $template->AddData("PICTURE", "<img src=\"{$response["image"]}\" title=\"{$imageName}\" alt=\"{$imageName}\">");

                    $counter = 0;
                    if (ModelDB::DataPicture($imageSource, $imageName, $imageProfile)) {
                        $template->AddData("PICTURERESPONSE", "Sikeres kép feltöltés!");
                        $counter++;
                    } else {
                        $template->AddData("PICTURERESPONSE", "Sikertelen kép feltöltés!");
                    }
                    if ($counter == 3) {
                        $template->AddData("PICTURERESPONSE", "Háromnál több képet nem lehet feltölteni!");
                    }



                } else {
                    $response["info"] = "A feltöltés sikertelen! Egyéb hiba!";
                    $template->AddData("RESPONSE", "<h2>A feltöltés sikertelen! Egyéb hiba!</h2><br>");
                }

            } else {
                $response["info"] = "Nem támogatott formátum!";
                $template->AddData("RESPONSE", "<h2>Nem támogatott formátum!</h2><br>");
            }

        } else {
            $response["info"] = "A feltöltés meghiúsult!";
            $template->AddData("RESPONSE", "<h2>A feltöltés meghiúsult!</h2><br>");
        }
    }



    public static function Run(): Template
    {
        $template = Template::Load("profile.html");


        $id = ModelDB::GetUserId($_SESSION["name"]);
        //var_dump($id);
        foreach ($id as $userID) {
            if ($id == $_SESSION["name"]) {
                $userID = $id;
            }
        }

        if (isset($_GET["id"])) {
            if ($userID == filter_input(INPUT_GET, "id", FILTER_SANITIZE_NUMBER_INT)) {
                $template = Template::Load("data.html");
                dataPage::DataMap($template);
                dataPage::SchoolMap($template);
                dataPage::PicturesData($template);
            }

            if (isset($_POST["updateRedirectTo"])) {
                header("Location: index.php");
            }

            return $template;
        }


        $template->AddData("PAGECONTENT", "<h1>Üdvözlünk a profil szerkesztő oldalon!</h1>");
        $template->AddData("USERID", "{$userID}");
        $template->AddData("PAGECONTENTS", "<h2>Iskolai/munkahelyi tapasztalatok</h2><br>");
        $template->AddData("PICTURES", "<h2>Képek feltöltése:</h2><br>");

        if (isset($_POST["data1"])) {
            self::DataFirst($template);
        }

        if (isset($_POST["data2"])) {
            self::DataSecond($template);
        }

        if (isset($_POST["feltolt"])) {
            self::UploadPictures($template);
        }

        if (isset($_POST["update"])) {
            self::DataFirstUpdate($template);
        }

        if (isset($_POST["updateSecond"])) {
            self::DataSecondUpdate($template);
        }

        return $template;
    }
}