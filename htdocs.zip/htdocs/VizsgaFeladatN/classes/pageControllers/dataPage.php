<?php

class dataPage
{

    public static function DataMap(Template $template)
    {

        $firstData = ModelDB::GetFirstDatas();

        foreach ($firstData as $datas) {
            $template->AddData("FIRSTDATAS", "<table class='table table-striped table-light'><thead><tr>
            <th>Teljes név:</th><th>Születési hely:</th><th>Születési dátum:</th><th>Állampolgárság:</th><th>Bemutatkozás:</th><th>Hobbik:</th><th>Telefonszámok:</th>
            </tr></thead>
            <tbody><tr>
            <td>{$datas["name"]}</td><td>{$datas["birthplace"]}</td><td>{$datas["date"]}</td><td>{$datas["national"]}</td><td>{$datas["intro"]}</td><td>{$datas["hobbies"]}</td><td>{$datas["phone"]}</td><form method='post'><td>
            <input type='submit' name='updateRedirectTo' value='Adatok frissítése'
            class='form-control btn btn-dark input-group'></td></form></tr></tbody>
            </table>");
        }
        return $template;
    }


    public static function SchoolMap(Template $template)
    {

        $secondData = ModelDB::GetSchoolDatas();

        foreach ($secondData as $datas) {
            $template->AddData("FIRSTDATAS", "<h1>Iskolai végzettségek:</h1><table class='table table-striped table-dark'><thead><tr>
            <th>Teljes név:</th><th>Cég/Intézmény neve:</th><th>Tanulmányok, vagy munkavégzés kezdeti dátuma:</th><th>Tanulmányok, vagy munkavégzés vég dátuma:</th><th>Munkakör / tanulmányok megnevezése:</th>
            </tr></thead>
            <tbody><tr>
            <td>{$datas["schoolnev"]}</td><td>{$datas["schoolname"]}</td><td>{$datas["firstdate"]}</td><td>{$datas["lastdate"]}</td><td>{$datas["position"]}</td>
            </tr></tbody>
            </table>");
        }
        return $template;
    }


    public static function PicturesData(Template $template)
    {
        $imageData = ModelDB::GetPicturesDatas();




        foreach ($imageData as $data) {
            $template->AddData("IMAGES", "
            <div class='row'>
            <div class='column'>
            <img src='$data[imageSource]'  alt='$data[imageName]' title='$data[imageName]' width='300px' onclick='myFunction(this);'>
            </div>
            </div>

            <div class='container'>
                <span onclick=\"this.parentElement.style.display='none'\" class='closebtn'>&times;</span>

                <img id='expandedImg' style='width:100%'>

            <div id='imgtext'></div>
</div>
            ");
        }


        return $template;
    }


    public static function Run(): Template
    {
        //View::getBaseTemplate()->AddData("ADDHEADER", "<style>body{color: red;}</style>");
        $template = Template::Load("data.html");
        $template->AddData("PAGECONTENT", "<h1>Adatok összesítése</h1>");

        $id = ModelDB::GetUserId($_SESSION["name"]);
        var_dump($id);
        foreach ($id as $userID) {
            if ($id == $_SESSION["name"]) {
                $userID = $id;
            }
        }



        return $template;
    }
}