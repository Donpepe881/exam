<?php

class registerPage
{
    public static function Register(Template $template): void
    {
        $writeback = true;
        if (filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL) && isset($_POST["pass"]) && isset($_POST["name"]) && isset($_POST["birthplace"]) && isset($_POST["date"])) {

            $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
            $pass = htmlspecialchars($_POST["pass"]);
            $name = htmlspecialchars($_POST["name"]);
            $birthplace = htmlspecialchars($_POST["birthplace"]);
            $date = htmlspecialchars($_POST["date"]);
            $login = false;
            if (preg_match("/[0-9]+/", $pass) && strtolower($pass) != $pass && strtoupper($pass) != $pass && mb_strlen($pass) >= 8) {
                ModelDB::Register($email, hash("sha256", $pass), $name, $birthplace, $date);
                $template->AddData("RESULT", "Sikeres regisztráció!");
                $template->AddData("RESULTCLASS", "success");
                $writeback = false;
                $login = true;
                $_SESSION["name"] = $email;

                if ($login) {
                    $template->AddData("RESULT", "Sikeres belépés!");
                    $template->AddData("RESULTCLASS", "success");
                    $_SESSION["auth"] = true;
                    header("Location: index.php");
                }
            } else {
                $template->AddData("RESULT", "Gyenge jelszó! A jelszónak legalább 8 karakteresnek kell lennie, melyben kis-nagy betű és szám is szerepel!");
                $template->AddData("RESULTCLASS", "fail");
            }
        } else {
            $template->AddData("RESULT", "Hiányos adatok!");
            $template->AddData("RESULTCLASS", "fail");
        }
        if ($writeback) //logikai értékeket nem kell külön kiértékelni
        {
            $template->AddData("RNAME", $_POST["name"]);
            $template->AddData("REMAIL", $_POST["email"]);
        }
    }

    public static function Run(): Template
    {
        $template = Template::Load("register.html");
        $template->AddData("PAGECONTENT", "<h1>Regisztrációs oldal</h1>");

        if (isset($_POST["register"])) {
            self::Register($template);
        }
        return $template;
    }
}