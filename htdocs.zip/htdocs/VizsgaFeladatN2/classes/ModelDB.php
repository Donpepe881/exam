<?php

abstract class ModelDB
{
    private static PDO $pdo;

    public static function Init()
    {
        self::$pdo = new PDO("mysql:host=localhost:3307;dbname=vizsgan", "pedro", "123456aA");
        self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public static function GetPage(string $key): bool|array
    {
        try {
            $result = self::$pdo->query("SELECT * FROM `pages` WHERE `key` = " . self::$pdo->quote($key));
            if ($result->rowCount() == 1) {
                $data = $result->fetchAll(PDO::FETCH_DEFAULT)[0];
                $result->closeCursor();
                return $data;
            }
            return false;
        } catch (Exception $ex) {

        }
    }

    public static function RegisterData($name, $email, $pass)
    {
        try {
            $prep = self::$pdo->prepare("INSERT INTO `users` VALUES (:name, :email, :pass)");
            $prep->bindParam(":name", $name, PDO::PARAM_STR);
            $prep->bindParam(":email", $email, PDO::PARAM_STR);
            $prep->bindParam(":pass", $pass, PDO::PARAM_STR);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen regisztráció!", $ex);
        }
    }

    public static function Login(): array
    {
        $result = self::$pdo->query("SELECT `email`, `password` FROM `users`");
        $datas = $result->fetchAll(PDO::FETCH_BOTH);
        $result->closeCursor();
        return $datas;
    }
}
