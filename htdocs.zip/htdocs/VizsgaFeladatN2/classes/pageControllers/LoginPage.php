<?php

class LoginPage
{

    private static function Login(Template $template)
    {
        if (filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL) && isset($_POST["password"])) {
            $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
            $pass = hash("sha256", htmlspecialchars($_POST["password"]));
            $logins = ModelDB::Login();
            $login = false;
            foreach ($logins as $row) {

                if (trim($row[0]) == trim($email) && trim($row[1]) == trim($pass)) {
                    $login = true;
                    $_SESSION["name"] = $row[0];
                    break;
                }
            }
            if ($login) {
                $template->AddData("RESULT", "Sikeres belépés!");
                $template->AddData("RESULTCLASS", "success");
                $_SESSION["auth"] = true;
                header("Location: index.php");
            } else {
                $template->AddData("RESULT", "Hibás felhasználónév / jelszó!");
                $template->AddData("RESULTCLASS", "fail");
                $template->AddData("LEMAIL", $email);
                session_destroy();
            }
        } else {
            $template->AddData("RESULT", "Hiányos adatok!");
            $template->AddData("RESULTCLASS", "fail");
            session_destroy();
        }
    }

    public static function Run(): Template
    {

        $template = Template::Load("login.html");

        if (isset($_POST["login"])) {
            self::Login($template);
        }


        return $template;
    }
}