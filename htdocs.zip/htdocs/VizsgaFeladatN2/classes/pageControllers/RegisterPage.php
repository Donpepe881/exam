<?php
class RegisterPage
{

    public static function Register(Template $template): void
    {
        $writeback = true;
        if (isset($_POST["name"]) && filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL) && isset($_POST["pass"])) {

            $name = htmlspecialchars($_POST["name"]);
            $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
            $pass = htmlspecialchars($_POST["pass"]);

            if (preg_match("/[0-9]+/", $pass) && strtolower($pass) != $pass && strtoupper($pass) != $pass && mb_strlen($pass) >= 8) {


                ModelDB::RegisterData($name, $email, hash("sha256", $pass));

                $template->AddData("RESULT", "Sikeres regisztráció!");
                $template->AddData("RESULTCLASS", "success");
                $writeback = false;
            } else {
                $template->AddData("RESULT", "Gyenge jelszó! A jelszónak legalább 8 karakteresnek kell lennie, melyben kis-nagy betű és szám is szerepel!");
                $template->AddData("RESULTCLASS", "fail");
            }

        } else {
            $template->AddData("RESULT", "Hiányos adatok!");
            $template->AddData("RESULTCLASS", "fail");
        }
        if ($writeback) //logikai értékeket nem kell külön kiértékelni
        {
            $template->AddData("RNAME", $_POST["name"]);
            $template->AddData("REMAIL", $_POST["email"]);
            $template->AddData("REMAILK", $_POST["email2"]);
        }
    }


    public static function Run(): Template
    {

        $template = Template::Load("register.html");

        if (isset($_POST["register"])) {
            self::Register($template);
        }

        return $template;
    }
}