<?php

abstract class Controller
{
    private static array $pages;


    public static function Init()
    {
        View::setBaseTemplate(Template::Load("Templates/index.html"));
        self::$pages = array("index", "add");
    }
    
    public static function Router() : void
    {
        $page = self::$pages[0];
        if(isset($_GET["page"]) && trim($_GET["page"]) != "")
        {
            $page = htmlspecialchars($_GET["page"]);
        }
        switch ($page)
        {
            case "index":
                self::IndexController();
                break;
            case "add":
                self::AddController();
                break;
            default :
                self::NotFoundController();
                break;
        }
    }
    
    private static function IndexController()
    {
        $template = Template::Load("Templates/main.html");
        try
        {
            if(isset($_POST["id"]) && filter_input(INPUT_POST, "id", FILTER_VALIDATE_INT) && isset($_POST["newStatus"]) && filter_input(INPUT_POST, "newStatus", FILTER_VALIDATE_INT))
            {
                try
                {
                    $id = $_POST["id"];
                    Model::ModStatus($id, TermekStatusz::from($_POST["newStatus"]));
                    $info = Model::GetItem($id);
                    mail($info["email"], "Termék státusz változás", "Kedves {$info["vezeteknev"]} {$info["keresztnev"]}!\n\nA szervizelt terméke ({$info["szeriaszam"]}) státusza megváltozott --> ".TermekStatusz::from($info["statusz"])->name."!\n\nÜdv, Záródolgozat!", array("From"=>"zaro@dolgozat.hu"));
                    $template->AddData("RESULT", "Sikeres módosítás!");
                    $template->AddData("RESCLASS", "success");
                }
                catch (Exception $ex)
                {
                    $template->AddData("RESULT", $ex->getMessage());
                    $template->AddData("RESCLASS", "error");
                }    
            }
            $data = Model::GetItems();
            foreach ($data as $row)
            {
                $rowTemplate = Template::Load("Templates/item.html");
                switch (TermekStatusz::from($row["statusz"]))
                {
                    case TermekStatusz::Beerkezett:
                        $rowTemplate->AddData("COLOR", "#67b8ff");
                        break;
                    case TermekStatusz::Hibafeltaras:
                        $rowTemplate->AddData("COLOR", "#ff8267");
                        break;
                    case TermekStatusz::AlkatreszBeszerzes:
                        $rowTemplate->AddData("COLOR", "#ffc867");
                        break;
                    case TermekStatusz::Javitas:
                        $rowTemplate->AddData("COLOR", "#d867ff");
                        break;
                    case TermekStatusz::Kesz:
                        $rowTemplate->AddData("COLOR", "#67ff7c");
                        break;
                }
                $rowTemplate->AddData("ID", $row["id"]);
                $contact = Template::Load("Templates/contact.html");
                $contact->AddData("SZERIA", $row["szeriaszam"]);
                $contact->AddData("ID", "CONTACT".$row["id"]);
                $contact->AddData("NEV", $row["vezeteknev"]." ");
                $contact->AddData("NEV", $row["keresztnev"]);
                $contact->AddData("TELEFON", $row["telefon"]);
                $contact->AddData("EMAIL", $row["email"]);
                $rowTemplate->AddData("ID", $contact);
                $rowTemplate->AddData("CID", "CONTACT".$row["id"]);
                $rowTemplate->AddData("SZERIA", $row["szeriaszam"]);
                $rowTemplate->AddData("GYARTO", $row["gyarto"]);
                $rowTemplate->AddData("TIPUS", $row["tipus"]);
                $rowTemplate->AddData("BEERKEZES", $row["leadasDatum"]);
                $rowTemplate->AddData("STATUSZVALTAS", $row["utolsoValtozasDatum"]);
                $stat = Template::Load("Templates/select.html");
                $stat->AddData("ID", $row["id"]);
                $stat->AddData(strtoupper(TermekStatusz::from($row["statusz"])->name), "selected");
                $rowTemplate->AddData("STATUSZ", $stat);
                $template->AddData("ITEMS", $rowTemplate);
            }
        }
        catch (Exception $ex) 
        {

        }
        View::getBaseTemplate()->AddData("CONTENT", $template);
    }
    
    private static function AddController()
    {
        $template = Template::Load("Templates/add.html");
        if(isset($_POST["ok"]))
        {
            $keys = array("szeriaszam", "gyarto", "tipus", "vezeteknev", "keresztnev", "telefon", "email");
            $data = array();
            foreach($keys as $k)
            {
                $data[$k] = htmlspecialchars($_POST[$k]);
            }
            try
            {
                Model::NewItem($data);
                $template->AddData("RESULT", "Sikeres felvitel!");
                $template->AddData("RESCLASS", "success");
            }
            catch (Exception $ex)
            {
                $template->AddData("RESULT", $ex->getMessage());
                $template->AddData("RESCLASS", "error");
            }
        }
        View::getBaseTemplate()->AddData("CONTENT", $template);
    }
    
    private static function NotFoundController()
    {
        View::setBaseTemplate(Template::Load("Templates/404.html"));
    }
}
