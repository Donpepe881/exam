<?php

abstract class Model
{
    private static PDO $pdo;

    public static function getPdo(): PDO
    {
        return self::$pdo;
    }

    public static function Connect(): void
    {
        try {
            self::$pdo = new PDO("mysql:host=localhost;dbname=zarovizsgamegoldas;port=3307", "pedro", "123456aA");
            self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (Exception $ex) {
            throw new DBException("Sikertelen csatlakozás az adatbázishoz!", $ex);
        }
    }

    public static function GetItem(int $id): array
    {
        try {
            $stmt = self::$pdo->query("SELECT * FROM `szerviztermek` INNER JOIN `kapcsolat` ON `szerviztermek`.`id` = `kapcsolat`.`termekId` WHERE `szerviztermek`.`id` = $id");
            if ($stmt->rowCount() > 0) {
                $result = $stmt->fetchAll(PDO::FETCH_ASSOC)[0];
                $stmt->closeCursor();
                return $result;
            }
            $stmt->closeCursor();
            return array();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen lekérdezés!", $ex);
        }
    }

    public static function GetItems(): array
    {
        try {
            $stmt = self::$pdo->query("SELECT * FROM `szerviztermek` INNER JOIN `kapcsolat` ON `szerviztermek`.`id` = `kapcsolat`.`termekId` WHERE `statusz` <> " . TermekStatusz::Kesz->value . " OR cast(`utolsoValtozasDatum` as DATE) = CURDATE() ORDER BY `statusz`");
            if ($stmt->rowCount() > 0) {
                $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $stmt->closeCursor();
                return $result;
            }
            $stmt->closeCursor();
            return array();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen lekérdezés!", $ex);
        }
    }

    public static function ModStatus(int $id, TermekStatusz $newStatus): void
    {
        try {
            self::$pdo->query("UPDATE `szerviztermek` SET `statusz` = " . $newStatus->value . ", `utolsoValtozasDatum` = CURRENT_TIMESTAMP WHERE `id` = $id");
        } catch (Exception $ex) {
            throw new DBException("Sikertelen státusz módosítás!", $ex);
        }
    }

    public static function NewItem(array $data)
    {
        self::$pdo->beginTransaction();
        try {
            $stmt = self::$pdo->prepare("INSERT INTO `szerviztermek`(`szeriaszam`, `gyarto`, `tipus`) VALUES (:szeria, :gyarto, :tipus)");
            $stmt->bindParam(":szeria", $data["szeriaszam"]);
            $stmt->bindParam(":gyarto", $data["gyarto"]);
            $stmt->bindParam(":tipus", $data["tipus"]);
            $stmt->execute();
            $termekId = self::$pdo->lastInsertId();
            $stmt = self::$pdo->prepare("INSERT INTO `kapcsolat`(`vezeteknev`, `keresztnev`, `telefon`, `email`, `termekId`) VALUES (:vezeteknev, :keresztnev, :telefon, :email, :termekId)");
            $stmt->bindParam(":vezeteknev", $data["vezeteknev"]);
            $stmt->bindParam(":keresztnev", $data["keresztnev"]);
            $stmt->bindParam(":telefon", $data["telefon"]);
            $stmt->bindParam(":email", $data["email"]);
            $stmt->bindParam(":termekId", $termekId);
            $stmt->execute();
            self::$pdo->commit();
        } catch (Exception $ex) {
            try {
                self::$pdo->rollBack();
            } catch (Exception $ex2) {
                throw new DBException("Végzetes hiba a felvitel során!", $ex2);
            }
            throw new DBException("Hiba a felvitel során!", $ex);
        }
    }
}
