<?php

/*
Beolvasni Template fájlt ✅
Azonosítani benne flag-eket ✅
Flag-ek lekérdezhetősége ✅
Késői kötés megoldása --> egy flag-et később is ki lehessen tölteni ✅
Flag-hez tartozó adatok törlése ✅
Flag-hez több adat hozzárendelhetősége ✅
Optimalizáljuk ki a rendszert --> csak akkor csinálja meg újra a kész template-et, ha még nem csinálta meg - local cache ✅

*/

class Template
{
    private bool $modified;
    private string $rawTemplate, $renderedTemplate;
    private array $flags; //több dimenziós tömb lesz
    
    private function __construct(string $templateString)
    {
        $this->rawTemplate = $templateString;
        $this->flags = array();
        $this->renderedTemplate = "";
        $this->modified = true;
        $matches = array();
        if(preg_match_all("/%![A-Z]+!%/", $this->rawTemplate, $matches) !== false)
        {
            if(count($matches[0]) > 0)
            {
                foreach($matches[0] as $match)
                {
                    $flagData = array();
                    if(preg_match("/[A-Z]+/", $match, $flagData) !== false)
                    {
                        $this->flags[$flagData[0]] = array();
                    }
                }
            }
        }
    }
    
    public function GetAllFlags() : array
    {
        return array_keys($this->flags);
    }
    
    public function AddData(string $flag, string|Template $data) : bool
    {
        if(array_key_exists($flag, $this->flags))
        {
            $this->flags[$flag][] = $data;
            $this->modified = true;
            return true;
        }
        return false;
    }
    
    public function ClearFlag(string $flag) : bool
    {
        if(array_key_exists($flag, $this->flags))
        {
            $this->flags[$flag] = array();
            $this->modified = true;
            return true;
        }
        return false;
    }
    
    public function GetAllFlagData(string $flag) : bool|array
    {
        if(array_key_exists($flag, $this->flags))
        {
            return $this->flags[$flag];
        }
        return false;
    }
    
    public function GetIndexFlagData(string $flag, int $index) : bool|string|Template
    {
        $allFlagData = $this->GetAllFlagData($flag);
        if($allFlagData !== false && count($allFlagData) > $index)
        {
            return $allFlagData[$index];
        }
        return false;
    }
    
    public function Render() : string
    {
        if($this->modified)
        {
            $this->renderedTemplate = $this->rawTemplate;
            foreach ($this->flags as $flag=>$flagData)
            {
                //$this->renderedTemplate = str_replace("%!$flag!%", implode("", $flagData), $this->renderedTemplate);
                $content = "";
                foreach ($flagData as $data)
                {
                    if(is_a($data, "Template"))
                    {
                        $content .= $data->Render();
                    }
                    else
                    {
                        $content .= $data;
                    }
                }
                $this->renderedTemplate = str_replace("%!$flag!%", $content, $this->renderedTemplate);
            }
            $this->modified = false;
        }
        return $this->renderedTemplate;
    }
    
    public static function Load(string $filename) : Template
    {
        return new Template(file_get_contents($filename));
    }
    
    public static function Parse(string $templateString) : Template
    {
        return new Template($templateString);
    }
}
