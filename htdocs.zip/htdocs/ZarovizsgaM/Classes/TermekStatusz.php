<?php

enum TermekStatusz : int
{
    case Beerkezett = 1;
    case Hibafeltaras = 2;
    case AlkatreszBeszerzes = 3;
    case Javitas = 4;
    case Kesz = 5;
}