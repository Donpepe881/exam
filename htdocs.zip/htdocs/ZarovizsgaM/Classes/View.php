<?php

abstract class View
{
    private static Template $baseTemplate;
    
    public static function getBaseTemplate(): Template
    {
        return self::$baseTemplate;
    }

    public static function setBaseTemplate(Template $baseTemplate): void
    {
        self::$baseTemplate = $baseTemplate;
    }
    
    public static function FinalRender() : void
    {
        print(self::$baseTemplate->Render());
    }
}
