<?php
spl_autoload_register(function (string $type)
{
   if(file_exists("Classes/$type.php"))
   {
       require_once("Classes/$type.php");
   }
});
Model::Connect();
Controller::Init();
Controller::Router();
View::FinalRender();