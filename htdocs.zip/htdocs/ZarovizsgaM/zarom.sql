-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2024. Feb 10. 16:45
-- Kiszolgáló verziója: 10.4.32-MariaDB
-- PHP verzió: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `zarom`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `kapcsolat`
--

CREATE TABLE `kapcsolat` (
  `id` int(11) NOT NULL,
  `vezeteknev` varchar(64) NOT NULL,
  `keresztnev` varchar(64) NOT NULL,
  `telefon` varchar(32) NOT NULL,
  `email` varchar(255) NOT NULL,
  `termekId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `kapcsolat`
--

INSERT INTO `kapcsolat` (`id`, `vezeteknev`, `keresztnev`, `telefon`, `email`, `termekId`) VALUES
(2, 'Gipsz', 'Jakab', '0123456789', 'g.jakab@asd.hu', 2);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `szerviztermek`
--

CREATE TABLE `szerviztermek` (
  `id` int(11) NOT NULL,
  `szeriaszam` varchar(128) NOT NULL,
  `gyarto` varchar(64) NOT NULL,
  `tipus` varchar(64) NOT NULL,
  `leadasDatum` timestamp NOT NULL DEFAULT current_timestamp(),
  `statusz` tinyint(1) NOT NULL DEFAULT 1,
  `utolsoValtozasDatum` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `szerviztermek`
--

INSERT INTO `szerviztermek` (`id`, `szeriaszam`, `gyarto`, `tipus`, `leadasDatum`, `statusz`, `utolsoValtozasDatum`) VALUES
(2, '123456ASDFG', 'ASUS', 'P01', '2024-02-10 14:56:38', 1, '2024-02-10 15:25:52');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `kapcsolat`
--
ALTER TABLE `kapcsolat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kapcsolat_szerviztermek_FK` (`termekId`);

--
-- A tábla indexei `szerviztermek`
--
ALTER TABLE `szerviztermek`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `kapcsolat`
--
ALTER TABLE `kapcsolat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `szerviztermek`
--
ALTER TABLE `szerviztermek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `kapcsolat`
--
ALTER TABLE `kapcsolat`
  ADD CONSTRAINT `kapcsolat_szerviztermek_FK` FOREIGN KEY (`termekId`) REFERENCES `szerviztermek` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
