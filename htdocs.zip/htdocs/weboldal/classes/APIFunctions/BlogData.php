<?php

class BlogData implements IHTTPGET, IHTTPDELETE
{


    public function DELETE(): void
    {

        if (isset ($_GET["id"]) && filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT)) {
            $id = filter_input(INPUT_GET, "id", FILTER_SANITIZE_NUMBER_INT);

            if ($data = ModelDB::DeleteData($id)) {

                echo "Sikeres bejegyzés törlés";
            } else {
                echo "A megadott bejegyzés nem található!";
            }
        } else {
            echo "Nem megfelelő, vagy hiányos azonosító!";
        }
    }


    public function GET(): void
    {

        View::Init("blogdata.html");

        $data = ModelDB::GetDatas();
        echo json_encode($data);
    }
}