<?php

class ContactPage implements IHTTPPOST, IHTTPGET
{

    public function POST(): void
    {

        View::Init("contact.html");
        $input = file_get_contents("php://input");
        $json = json_decode($input, true);

        if (is_array($json)) {

            if (isset($json["contactName"]) && isset($json["contactEmail"]) && isset($json["contactTextarea"]) && trim($json["contactName"]) != "" && trim($json["contactEmail"]) != "" && trim($json["contactTextarea"]) != "") {

                $contactname = htmlspecialchars(trim($json["contactName"]));
                $email = htmlspecialchars(trim($json["contactEmail"]));
                $contactText = htmlspecialchars(trim($json["contactTextarea"]));

                if (ModelDB::Contact($contactname, $email, $contactText)) {
                    http_response_code(200);
                    echo "Sikeres üzenetküldés!";

                } else {
                    http_response_code(401);
                    echo "Sikertelen üzenetküldés!";
                }
            } else {
                http_response_code(401);
                echo "Minden mező kitöltése szükséges!";
            }
        } else {

            echo "Nem értelmezhető bemenet!";
            http_response_code(401);
        }
        exit();
    }

    public function GET(): void
    {

        View::Init("contact.html");
    }
}