<?php

class IndexPage implements IHTTPGET
{

    public function GET(): void
    {


        View::Init("index.html");

        $blogDatas = ModelDB::GetDatas();
        $imagesDatas = ModelDB::GetPictures();

        foreach ($blogDatas as $data) {
            foreach ($imagesDatas as $image) {
                if ($data["id"] == $image["id"]) {
                    View::getBaseTemplate()->AddData("CONTENT", "

                    <div class='col'>
                    <div class='card mt-4 col-md6 bg-light'>
                        <div class='card-body' id='{$data['id']}'>
                            <div class='col-md-12 text-center'>
                            <img id='{$image['id']}' class='rounded-circle' src='{$image['imageSource']}' alt='{$image['imageName']}' title='{$image['imageName']}' style='width: 30vw;'>
                            <h5 class='text-center'>{$data['title']}</h5>
                            <h6 class='text-center mb-2 text-muted'>{$data['firstsubtitle']}</h6>
                            <p class='card-text-first'>{$data['firstpara']}</p>
                            <p class='card-text-second'>{$data['secondpara']}</p>
                            <p class='card-text-third'>{$data['thirdpara']}</p>
                            </div>
                        </div>
                    </div>
                    </div>
                ");
                }
            }
        }
    }
}