<?php

class LoginPage implements IHTTPGET, IHTTPPOST
{

    public function POST(): void
    {

        View::Init("login.html");
        $input = file_get_contents("php://input");
        $json = json_decode($input, true);
        if (is_array($json)) {

            if (isset ($json["email"]) && isset ($json["pass"]) && trim($json["email"]) != "" && trim($json["pass"]) != "") {
                $email = htmlspecialchars($json["email"]);
                $pass = hash("sha256", htmlspecialchars($json["pass"]));
                $logins = ModelDB::Login();
                $login = false;

                foreach ($logins as $row) {

                    if (trim($row[1]) == trim($email) && trim($row[2]) == trim($pass)) {
                        $login = true;
                        $_SESSION["name"] = $row[0];
                        $_SESSION["email"] = $row[1];
                        break;
                    }
                }

                if ($login) {
                    setcookie('user', $pass);
                    http_response_code(200);
                    echo 'Üdvözlünk ' . $_SESSION["name"];

                } else {
                    http_response_code(401);
                    echo "Hibás email vagy jelszó";
                }
            } else {
                http_response_code(401);
                echo "Hiányos adatok!";
            }
        } else {
            echo "Nem értelmezhető bemenet!";
            http_response_code(401);
        }
        exit();
    }

    public function GET(): void
    {
        View::Init("login.html");
    }
}



