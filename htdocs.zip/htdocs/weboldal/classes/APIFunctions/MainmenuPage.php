<?php

class MainMenuPage implements IHTTPGET
{

    public function GET(): void
    {
        View::Init("mainMenu.html");
    }

}