<?php

class MenuPage implements IHTTPGET
{

    public function GET(): void
    {
        View::Init("menu.html");
    }
}