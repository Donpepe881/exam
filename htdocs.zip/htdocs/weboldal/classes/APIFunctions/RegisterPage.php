<?php

class RegisterPage implements IHTTPPOST, IHTTPGET
{
    public function POST(): void
    {

        View::Init("register.html");
        $input = file_get_contents("php://input");
        $json = json_decode($input, true);

        var_dump($json);
        if (is_array($json)) {

            if (isset ($json["name"]) && isset ($json["name"]) && isset ($json["pass"])) {

                $name = htmlspecialchars(trim($json["name"]));
                $email = htmlspecialchars(trim($json["email"]));
                $pass = htmlspecialchars($json["pass"]);


                if (preg_match("/[0-9]+/", $pass) && strtolower($pass) != $pass && strtoupper($pass) != $pass && mb_strlen($pass) >= 8) {

                    ModelDB::Register($name, $email, hash("sha256", $pass));

                    http_response_code(200);
                    echo "Sikeres regisztráció";
                } else {
                    http_response_code(401);
                    echo "Gyenge jelszó! A jelszónak legalább 8 karakteresnek kell lennie, melyben kis-nagy betű és szám is szerepel!";
                    exit();
                }
            } else {
                http_response_code(401);
                echo "Hiányos adatok vagy nem értelmezhető bemenet!";
                exit();
            }
        } else {
            echo "Nem értelmezhető bemenet!";
            http_response_code(401);
        }
        exit();
    }

    public function GET(): void
    {
        View::Init("register.html");
    }
}