<?php

class WelcomePage implements IHTTPGET, IHTTPPOST, IHTTPPUT
{

    public function PUT(): void
    {

        View::Init("welcome.html");

        if (isset ($_GET["id"]) && filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT)) {
            $id = filter_input(INPUT_GET, "id", FILTER_SANITIZE_NUMBER_INT);
            $input = file_get_contents("php://input");
            $json = json_decode($input, true);

            if (is_array($json)) {

                if (isset ($json["blogname"]) && isset ($json["firstsubtitle"]) && isset ($json["firstparagraph"]) && isset ($json["secondparagraph"]) && isset ($json["thirdparagraph"])) {

                    if (ModelDB::UpdateBlogDatas($id, htmlspecialchars(trim($json["blogname"])), htmlspecialchars(trim($json["firstsubtitle"])), htmlspecialchars(trim($json["firstparagraph"])), htmlspecialchars(trim($json["secondparagraph"])), htmlspecialchars(trim($json["thirdparagraph"])))) {

                        echo "Success";
                    } else {
                        echo "Módosítási hiba!";
                    }
                } else {
                    echo "Hiányos adatok!";
                }
            } else {
                echo "Nem értelmezhető bemenet!";
            }
        } else {
            echo "Nem megfelelő, vagy hiányos azonosító!";

        }
    }

    public function POST(): void
    {
        View::Init("welcome.html");
        $input = file_get_contents("php://input");
        $json = json_decode($input, true);

        if (is_array($json)) {
            if (isset ($json["blogname"]) && isset ($json["firstsubtitle"]) && isset ($json["firstparagraph"]) && isset ($json["secondparagraph"]) && isset ($json["thirdparagraph"])) {

                $blogname = htmlspecialchars(trim($json["blogname"]));
                $firstsubtitle = htmlspecialchars(trim($json["firstsubtitle"]));
                $firstparagraph = htmlspecialchars(trim($json["firstparagraph"]));
                $secondparagraph = htmlspecialchars(trim($json["secondparagraph"]));
                $newparagraph = htmlspecialchars(trim($json["thirdparagraph"]));

                if (ModelDB::UploadBlogDatas($blogname, $firstsubtitle, $firstparagraph, $secondparagraph, $newparagraph)) {
                    http_response_code((200));
                    echo "Sikeres adat feltöltés!";

                } else {
                    http_response_code(401);
                    echo "Sikertelen feltöltés!";
                }
            } else {
                http_response_code(401);
                echo "Hiányzó szöveg!";
            }
        } else {
            http_response_code(401);
            echo "Nem értelmezhető bemenet!";
        }
        exit();
    }

    public static function UploadBlogDatas(): void
    {
        define("MAXWIDTH", 300);
        define("MAXHEIGHT", 300);

        if (isset ($_FILES["image"]) && $_FILES["image"]["error"] == 0) {

            $mime = finfo_file(finfo_open(FILEINFO_MIME_TYPE), $_FILES["image"]["tmp_name"]);
            if ($mime == "image/jpeg") {

                if (move_uploaded_file($_FILES["image"]["tmp_name"], "tmp.jpg")) {
                    $kep = imagecreatefromjpeg("tmp.jpg");
                    $arany = imagesx($kep) / imagesy($kep);

                    if (imagesx($kep) > MAXWIDTH) {
                        $meretezett = imagecreatetruecolor(MAXWIDTH, intval(MAXWIDTH / $arany));
                        imagecopyresampled($meretezett, $kep, 0, 0, 0, 0, MAXWIDTH, intval(MAXWIDTH / $arany), imagesx($kep), imagesy($kep));
                        $kep = $meretezett;
                    }

                    if (imagesy($kep) > MAXHEIGHT) {
                        $meretezett = imagecreatetruecolor(intval(MAXHEIGHT * $arany), MAXHEIGHT);
                        imagecopyresampled($meretezett, $kep, 0, 0, 0, 0, intval(MAXHEIGHT * $arany), MAXHEIGHT, imagesx($kep), imagesy($kep));
                        $kep = $meretezett;
                    }

                    imagepng($kep, "kepek/" . basename($_FILES["image"]["name"]) . ".png");
                    unlink("tmp.jpg");

                    $response["info"] = "Sikeres konverzió!";
                    $response["image"] = "kepek/" . basename($_FILES["image"]["name"]) . ".png";

                    $imageSource = htmlspecialchars($response["image"]);
                    $imageName = htmlspecialchars(substr($imageSource, strrpos($imageSource, "/") + 1));


                    if (ModelDB::UploadBlogPictures($imageSource, $imageName)) {
                        echo "<div class='alert alert-success alert-dismissible'>
                        <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                        <strong>Sikeres kép feltöltés !</strong></div>";
                    } else {
                        echo "<div class='alert alert-success alert-dismissible'>
                        <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                        <strong>Sikertelen kép feltöltés !</strong></div>";
                    }
                } else {
                    $response["info"] = "A feltöltés sikertelen! Egyéb hiba!";
                    echo "<div class='alert alert-success alert-dismissible'>
                        <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                        <strong>A feltöltés sikertelen! Egyéb hiba!</strong></div>";
                }
            } else {
                $response["info"] = "Nem támogatott formátum!";
                echo "<div class='alert alert-success alert-dismissible'>
                        <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                        <strong>Nem támogatott formátum!</strong></div>";
            }
        } else {
            $response["info"] = "A feltöltés meghiúsult!";
            echo "<div class='alert alert-success alert-dismissible'>
                        <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                        <strong>A feltöltés meghiúsult!</strong></div>";
        }
    }


    public function GET(): void
    {

        if (!isset ($_COOKIE['user'])) {

            http_response_code(403);
            echo ("<h3 style='text-align: center;'>Az oldal megtekintéséhez előbb jelentkezz be!</h3>");
        } else {

            View::Init("welcome.html");
            $username = $_SESSION["name"];

            View::getBaseTemplate()->AddData("USERNAME", $username . "!");
        }
    }
}