<?php
abstract class Controller
{

    public static function Init(): void
    {
        ModelDB::Connect();
        View::Init("index.html");
    }

    public static function DoCall(): void
    {
        global $conf;
        if (isset ($_GET[$conf["methodParam"]])) {
            $class = htmlspecialchars($_GET[$conf["methodParam"]]);
            if (class_exists($class, true)) {

                $method = $_SERVER["REQUEST_METHOD"];
                $interfaces = class_implements($class, true);

                if (isset ($_POST["feltolt"])) {
                    WelcomePage::UploadBlogDatas();

                } elseif (isset ($_POST["delete-image"])) {
                    SelfknowledgePage::DeleteBlogDatas();

                } elseif (isset ($_POST["delete-message"])) {
                    SelfknowledgePage::DeleteMessage();
                } elseif ($interfaces !== false && in_array("IHTTP" . $method, $interfaces)) {
                    $obj = new $class();
                    $obj->$method();
                } else {
                    View::Init("error.html");
                    View::getBaseTemplate()->AddData("RESULT", "A hívott szolgáltatás létezik, de ezen a metodikán nem szolgál ki!");
                }
            } else {
                View::Init("error.html");
                View::getBaseTemplate()->AddData("RESULT", "A hívott szolgáltatás ($class) nem létezik!");
            }
        } else {
            View::Init("error.html");
            View::getBaseTemplate()->AddData("RESULT", "Nincs kijelölt szolgáltatás!");
        }
    }
}
