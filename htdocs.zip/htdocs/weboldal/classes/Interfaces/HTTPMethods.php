<?php
interface IHTTPGET
{
    function GET(): void;
}

interface IHTTPPOST
{
    function POST(): void;
}

interface IHTTPPUT
{
    function PUT(): void;
}

interface IHTTPDELETE
{
    function DELETE(): void;
}

interface IHTTPPATCH
{
    function PATCH(): void;
}