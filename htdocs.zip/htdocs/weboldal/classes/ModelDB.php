<?php

abstract class ModelDB
{
    private static PDO $pdo;

    public static function Connect(): void
    {
        global $conf;
        try {
            self::$pdo = new PDO("mysql:host={$conf["DBHost"]};dbname={$conf["DBName"]};port={$conf["DBPort"]}", $conf["DBUser"], $conf["DBPass"]);
            self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (Exception $ex) {
            throw new DBException("Az adatbázis kapcsolódás sikertelen!", $ex);
        }
    }

    public static function Login(): array
    {
        $result = self::$pdo->query("SELECT `name`,`email`, `pass` FROM `users`");
        $datas = $result->fetchAll(PDO::FETCH_BOTH);
        $result->closeCursor();
        return $datas;
    }

    public static function Register(string $name, string $email, string $pass): bool
    {
        try {
            $prep = self::$pdo->prepare("INSERT INTO `users` VALUES (:name, :email, :pass)");
            $prep->bindParam(":name", $name, PDO::PARAM_STR);
            $prep->bindParam(":email", $email, PDO::PARAM_STR);
            $prep->bindParam(":pass", $pass, PDO::PARAM_STR);

            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen regisztráció!", $ex);
        }
    }

    public static function Contact(string $contactName, string $contactEmail, string $contactTextarea): bool
    {
        try {
            $prep = self::$pdo->prepare("INSERT INTO `contact` VALUES (NULL, :contactName, :contactEmail, :contactTextarea)");
            $prep->bindParam(":contactName", $contactName, PDO::PARAM_STR);
            $prep->bindParam(":contactEmail", $contactEmail, PDO::PARAM_STR);
            $prep->bindParam(":contactTextarea", $contactTextarea, PDO::PARAM_STR);

            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen üzenetküldés", $ex);
        }
    }


    public static function UploadBlogPictures(string $imageSource, string $imageName): bool
    {
        try {
            $prep = self::$pdo->prepare("INSERT INTO `blogimages` VALUES (NULL, :imageSource, :imageName) ");
            $prep->bindParam(":imageSource", $imageSource, PDO::PARAM_STR);
            $prep->bindParam(":imageName", $imageName, PDO::PARAM_STR);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen adatfeltöltés!", $ex);
        }
    }


    public static function UploadBlogDatas(string $title, string $firstsubtitle, string $firstpara, string $secondpara, string $newpara): bool
    {
        try {
            $prep = self::$pdo->prepare("INSERT INTO `blogdata` VALUES (NULL, :title, :firstsubtitle, :firstpara, :secondpara, :thirdpara) ");
            $prep->bindParam(":title", $title, PDO::PARAM_STR);
            $prep->bindParam(":firstsubtitle", $firstsubtitle, PDO::PARAM_STR);
            $prep->bindParam(":firstpara", $firstpara, PDO::PARAM_STR);
            $prep->bindParam(":secondpara", $secondpara, PDO::PARAM_STR);
            $prep->bindParam(":thirdpara", $newpara, PDO::PARAM_STR);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen blog bejegyzés feltöltés!", $ex);
        }
    }


    public static function GetDatas(): array
    {
        try {
            $prep = self::$pdo->query("SELECT * FROM `blogdata`");
            $userInfo = $prep->fetchAll(PDO::FETCH_ASSOC);
            $prep->closeCursor();
            return $userInfo;
        } catch (Exception $ex) {
            throw new DBException("Sikertelen blog bejegyzés lekérdezés!", $ex);
        }
    }

    public static function DeleteData(int $id): bool
    {
        try {
            $prep = self::$pdo->prepare("DELETE FROM `blogdata` WHERE `id` = :id");
            $prep->bindParam(":id", $id, PDO::PARAM_INT);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen felhasználó törlés!", $ex);
        }
    }


    public static function UpdateBlogDatas(int $id, string $blogname, string $firstsubtitle, string $firstparagraph, string $secondparagraph, string $thirdparagraph): bool
    {

        try {
            $prep = self::$pdo->prepare("UPDATE `blogdata` SET `title` = :blogname, `firstsubtitle` = :firstsubtitle, `firstpara` = :firstparagraph, `secondpara` = :secondparagraph, `thirdpara` = :thirdparagraph  WHERE `id` = :id");
            $prep->bindParam(":blogname", $blogname, PDO::PARAM_STR);
            $prep->bindParam(":firstsubtitle", $firstsubtitle, PDO::PARAM_STR);
            $prep->bindParam(":firstparagraph", $firstparagraph, PDO::PARAM_STR);
            $prep->bindParam(":secondparagraph", $secondparagraph, PDO::PARAM_STR);
            $prep->bindParam(":thirdparagraph", $thirdparagraph, PDO::PARAM_STR);
            $prep->bindParam(":id", $id, PDO::PARAM_INT);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen blog módosítás!", $ex);
        }
    }

    public static function GetPictures(): array
    {
        try {
            $prep = self::$pdo->query("SELECT * FROM `blogimages`");
            $userInfo = $prep->fetchAll(PDO::FETCH_ASSOC);
            $prep->closeCursor();
            return $userInfo;
        } catch (Exception $ex) {
            throw new DBException("Sikertelen kép lekérdezés!", $ex);
        }
    }


    public static function DeleteBlogData(int $blogid): bool
    {
        try {
            $prep = self::$pdo->prepare("DELETE FROM `blogdata` WHERE `id` = :id");
            $prep->bindParam(":id", $blogid, PDO::PARAM_INT);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen blog bejegyzés törlés", $ex);
        }
    }

    public static function DeleteBlogPictures(int $imageid): bool
    {
        try {
            $prep = self::$pdo->prepare("DELETE FROM `blogimages` WHERE `id` = :id");
            $prep->bindParam(":id", $imageid, PDO::PARAM_INT);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen blog bejegyzés törlés", $ex);
        }
    }

    public static function GetMessages(): array
    {
        try {
            $prep = self::$pdo->query("SELECT * FROM `contact`");
            $userInfo = $prep->fetchAll(PDO::FETCH_ASSOC);
            $prep->closeCursor();
            return $userInfo;
        } catch (Exception $ex) {
            throw new DBException("Sikertelen üzenet lekérdezés!", $ex);
        }
    }


    public static function DeleteMessageById(int $messageid): bool
    {
        try {
            $prep = self::$pdo->prepare("DELETE FROM `contact` WHERE `id` = :id");
            $prep->bindParam(":id", $messageid, PDO::PARAM_INT);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen üzenet törlés", $ex);
        }
    }

    public static function SendedMessage(string $selfemail, string $address, string $subject, string $sendtext): bool
    {
        try {
            $prep = self::$pdo->prepare("INSERT INTO `sendedmessage` VALUES (NULL, :selfemail, :address, :subject, :sendtext)");
            $prep->bindParam(":selfemail", $selfemail, PDO::PARAM_STR);
            $prep->bindParam(":address", $address, PDO::PARAM_STR);
            $prep->bindParam(":subject", $subject, PDO::PARAM_STR);
            $prep->bindParam(":sendtext", $sendtext, PDO::PARAM_STR);

            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen válasz küldés", $ex);
        }
    }
}