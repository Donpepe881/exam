function NewRegistry() {
    document.getElementById("registry").style = "display: block;"
}

function GetBlogDatas() {
    document.getElementById("blogDatas").style = "display: block;"
}