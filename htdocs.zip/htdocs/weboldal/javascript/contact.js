const contact = document.getElementById('DoCall')
contact.addEventListener('click', () => {
    var status
    fetch('http://localhost/Weboldal/index.php?method=CONTACTPAGE', {
        'method': "POST",
        headers:
        {
            "Content-type": "application/json",
        },
        body: JSON.stringify({
            "contactName": document.getElementById("contactName").value,
            "contactEmail": document.getElementById("contactEmail").value,
            "contactTextarea": document.getElementById("contactTextarea").value
        }),
        mode: 'cors',
        credentials: 'include'
    })
        .then(res => {
            status = res.status
            return res.text()
        })
        .then(data => {
            console.log(data);
            alert(data)
        })
        .catch(err => {
            console.log(err)
        })
})