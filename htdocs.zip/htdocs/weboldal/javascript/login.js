const login = document.getElementById('DoCall')
login.addEventListener('click', () => {
    var status
    fetch('http://localhost/Weboldal/index.php?method=LOGINPAGE', {
        'method': 'POST',
        headers:
        {
            "Content-type": "application/json",
        },
        body: JSON.stringify({
            "email": document.getElementById("email").value,
            "pass": document.getElementById("pass").value
        }),
        mode: 'cors',
        credentials: 'include'
    })
        .then(res => {
            status = res.status
            return res.text()
        })
        .then(data => {

            alert(data)
            if (status == 200)
                location.href = "/Weboldal/index.php?method=WELCOMEPAGE"
        })
        .catch(err => {

            console.log(err)
        })
})