const message = document.getElementById('sendMessage')
message.addEventListener('click', () => {
    var status
    fetch('http://localhost/Weboldal/index.php?method=SELFKNOWLEDGEPAGE', {
        'method': "POST",
        headers:
        {
            "Content-type": "application/json",
        },
        body: JSON.stringify({
            "address": document.getElementById("address").value,
            "subject": document.getElementById("subject").value,
            "sendtext": document.getElementById("sendtext").value
        }),
        mode: 'cors',
        credentials: 'include'
    })
        .then(res => {
            status = res.status
            return res.text()
        })
        .then(data => {
            console.log(data);
            alert(data)
        })
        .catch(err => {
            console.log(err)
        })
})