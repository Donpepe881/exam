-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: localhost:3307
-- Létrehozás ideje: 2024. Már 19. 23:49
-- Kiszolgáló verziója: 10.4.32-MariaDB
-- PHP verzió: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `szstrudi`
--
CREATE DATABASE `szstrudi`;
-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `blogdata`
--

CREATE TABLE `blogdata` (
  `id` int(128) NOT NULL,
  `title` varchar(512) NOT NULL,
  `firstsubtitle` varchar(512) NOT NULL,
  `firstpara` varchar(2048) NOT NULL,
  `secondpara` varchar(2048) NOT NULL,
  `thirdpara` varchar(2048) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `blogdata`
--

INSERT INTO `blogdata` (`id`, `title`, `firstsubtitle`, `firstpara`, `secondpara`, `thirdpara`) VALUES
(1, 'Ha túl sokat költesz...', 'Próba bejegyzés', '1. Iratkozz le a hírlevelekről!\nEgészen addig nem jutott eszedbe, hogy nincsen tökéletes aranyszínű szemhéjpúdered és az új áfonya illatú parfüm sem virít a polcodon, amíg rá nem kattintottál a kedvenc webshopod legújabb akcióira? Sajnos máris behúztak a csőbe. A hírlevelek ugyanis el szeretnék hitetni veled, hogy tudatos vásárló vagy, hiszen az akciók miatt érdekelnek az e-mailjeik, tehát te tulajdonképpen Te csak spórolni szeretnél.\n\nMégis újra és újra olyan termékek megvásárlására fognak ösztönözni, ami egyáltalán nem szerepelt a sem terveidben, sem a költségvetésedben. Azt az érzést keltik benned, hogy ha ezt az akciót nem kapod el, akkor vissza-nem-térő lehetőségről maradsz le, ami sosem jön vissza. De hidd el, a hírlevelek nem érted vannak, hanem a reklámozott vállalatért.\n\nA legokosabb dolog amit tehetsz, hogy leiratkozol ezekről a levelekről és ragaszkodsz az előre meghatározott bevásárlólistádhoz és költségkeretedhez.', '2. Fedezd fel a gardóbodat!\nHa egyébként jellemző rád, hogy folyamatosan vásárolod az újabbnál újabb ruhákat, kiegészítőket vagy sminktermékeket, akkor mostanra már nagyon sok olyan darabod lehet, amire már nem is emlékszel. Ennek ellenére valószínűleg hétről hétre a gardróbodnak ugyanazt a 20-30%-át használod. Ez egy teljesen normális dolog, hiszen sok időt és energiát venne igénybe mindennap, ha nem a megszokott, forgatókönyvszerű dolgokat választanád.\n\nViszont, ha legközelebb elfog a vásárlási kényszer, először tegyél egy utazást a saját gardóbodban! Egyébként is időként ráfér a ruhatáradra, hogy rendesen átnézd és megszabadulj néhány darabtól. De most más szemmel közelíts: keress olyan darabokat, amik továbbra is jó állapotban vannak, de ezer éve nem voltak rajtad (esetleg a címke is rajtuk van még...? Ajj... :))\n\nKülönítsd el ezeket a kiválasztott elemeket, - teheted akár külön polcra is - és amikor vásárolni támad kedved, inkább válassz egyet a saját ruháid közül és alkoss egy olyan szettet, amit még sosem hordtál. Ez érvényes nem csak a ruháidra, de ékszereidre, szépségápolási termékeidre is.\n\nTipp: Fogd fel egy játékként az egészet. Én általában egy színes kiegészítőt szoktam kiválasztani, ami lehet egy nyaklánc, fülbevaló vagy egy régen használt öv. Aztán saját kihívást csinálok belőle, hogy egy sosem használt szettet alkossak, aminek a kiválasztott darab a &#039;főszereplője&#039;.', '3. Fogalmazd meg magadnak, mi számít valódi értéknek\nOlyan világban élünk, ahol azt sulykolják beléd, hogy akkor lehetsz értékes, ha nálad a legújabb mobiltelefon, szuper autóból szállsz ki és a kabátodon ott virít egy drága márka logója. A probléma akkor kezdődik, ha te is csak ettől érzed magad értékesnek.\n\nGondold át, hogy neked is vannak-e ilyen motivációd. Ha a válaszod igen, érdemes újra értelmezned, hogy mi számít valódi értéknek. Klisének tűnik, de az igazi boldogságot hozó dolgok általában ingyen vannak. Ilyenek az igaz barátok, a hűséges házastárs, időtöltés a családdal vagy a háziállatoddal, egy ölelés, egy játékkal vagy pihenéssel teli nap. Fogalmazd meg magadnak, hogy neked mi okoz igazi örömet. Legközelebb, ha úgy látod, csak azért szeretnél vásárolgatni, hogy értékesebbnek tűnj a környezeted számára – fókuszálj azokra a dolgokra, amik valóban boldogsággal töltenek el.\nBár a környezetünket okolni a nehéz helyzet miatt mindig az egyszerűbb út – és persze nem ezektől a tippektől lesz kacsalábon forgó kastélyunk – ha szembenézel a költekezési szokásaiddal és megtanulsz egy kis önuralmat gyakorolni, azért meg tudod könnyíteni a saját helyzetedet. Ne felejtsd, a változás nem egy éjszaka alatt történik, de ha kitartó vagy, bármilyen célodhoz közelebb kerülhetsz.\nTrudi'),
(2, 'Tarts detox-napot!', '2. Próba bejegyzés', 'Miért tarts detox-napot?\n\nEbben az esetben a válasz is egy kérdés: miért ne tartanál? Az egész életed körülveszi az állandó rohanás és stressz, miközben próbálsz egyensúlyozni a szerepeid között, hogy jó anya, tökéletes munkaerő, szuper feleség, kívánatos feleség, barátnő...stb. legyél. A sor nagyon hosszú, néha egyik-másik helyen sikerül helyt állnod, de akkor is egy másik terület kárára.\n\nÉs jön az önostorozás, hogy miért nem sikerül, amikor minden idegszáladdal koncentrálsz. Nos, sokszor pont azért, mert minden idegszálad be van már vetve. Ahogy fáradsz úgy leszel egyre türelmetlenebb magaddal és másokkal is, megborul a jól felépített diétád is, ami újabb önostorozáshoz vezet, és máris az ördögi körben vagy, ahol sikeresen szét is cincáltad az önbizalmad.\n\nHa már ennél a fázisnál jársz, vagy most döntötted el, hogy nem szeretnél eddig eljutni, a legjobb módszer, amit választhatsz, ha teljes detox-napot tartasz. Szándékosan nem méregtelenítőt írtam, hogy ne csak egy kis citromos vízre vagy zöld löttyre gondolj.\n\nHatározd el, hogy időnként (de legalább havonta egyszer) saját magadra, a testedre és a lelkedre szánsz egy napot – vagy egy felet – amikor egy kicsit elhatárolódsz a külvilágtól és magaddal foglalkozol. Ezek legyenek a te &quot;töltő-napjaid&quot;, aminek a végére garantáltan jobb színben fogod látni a világot, és a saját magadba vetett hited is visszatér.', 'Hogyan csináld?\n0. szabály: Tedd el a telefonod\nAz egész napnak az a célja, hogy magaddal tölts egy kis időt, hogy ki tudd adni a benned lévő frusztrációt és egy kicsit megnyugodj. Ha közben minden érkező e-mailt és értesítést elolvasol, akkor csak beenged az összes stresszt és azon fogod kapni magad, hogy megint 20 perce az Instát pörgeted és a Messenger-üzeneteidre válaszolsz. Nehéz lesz (én is függő vagyok), de ha hatásos napot szeretnél, akkor erre az időre meg kell feledkezned a telefonodról.', '1. Készülj fel egy jó alvással!\nOlyan napot igyekezz választani, ami előtt előre tudod, hogy fogsz tudni legalább 7-8 órát pihentetően aludni. Ha húzós estéből szeretnél a felemelő napodba csapódni, annak csak szenvedés és önmagad vonszolása lesz a vége – ráadásul fáradtabban a rossz szénhidrátokban gazdag ételeket is jobban kívánosd – és most éppen a lelkiismeretedet szeretnéd helyrepofozni.\n\nAmennyire tudsz sötétítsd be a szobád, ha úgy könnyebb akkor használj alvást segítő készítményeket pl. párnára fújható levendula spray-t. Készítsd egy pohár vizet az ágyad mellé és ez legyen az első, amit ébredés után megiszol.\nA fent tippeket keverheted, halmozhatod, de kedved szerint fel is cserélheted. Én mindig azt tapasztalom, hogyha egyszerre vetem be ezeket a módszereket, akkor másnap tényleg, mintha kicseréltek volna testileg és lelkileg is. Remélem Neked is hasznosak lesznek és legalább egy kis időre le tudod tenni a terheket, amiket cipelsz.\n\nTrudi');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `blogimages`
--

CREATE TABLE `blogimages` (
  `id` int(11) NOT NULL,
  `imageSource` varchar(256) NOT NULL,
  `imageName` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `blogimages`
--

INSERT INTO `blogimages` (`id`, `imageSource`, `imageName`) VALUES
(1, 'kepek/Ha túl sokat költesz.jpg.png', 'Ha túl sokat költesz.jpg.png'),
(2, 'kepek/Detox_fedlap.jpg.png', 'Detox_fedlap.jpg.png');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `contact`
--

CREATE TABLE `contact` (
  `id` int(20) NOT NULL,
  `contactName` varchar(128) NOT NULL,
  `contactEmail` varchar(128) NOT NULL,
  `contactTextarea` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `contact`
--

INSERT INTO `contact` (`id`, `contactName`, `contactEmail`, `contactTextarea`) VALUES
(1, 'Joó Péter', 'joope45@gmail.com', 'Próba email!');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `sendedmessage`
--

CREATE TABLE `sendedmessage` (
  `id` int(128) NOT NULL,
  `selfemail` varchar(256) NOT NULL,
  `address` varchar(256) NOT NULL,
  `subject` varchar(512) NOT NULL,
  `sendtext` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `name` varchar(512) NOT NULL,
  `email` varchar(512) NOT NULL,
  `pass` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`name`, `email`, `pass`) VALUES
('Joó Péter', 'joope45@gmail.com', '4760e26131ce7f07384adda2861ab5b56407854b35bfaca0ac63f793085c1264');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `blogdata`
--
ALTER TABLE `blogdata`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `blogimages`
--
ALTER TABLE `blogimages`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `sendedmessage`
--
ALTER TABLE `sendedmessage`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `blogdata`
--
ALTER TABLE `blogdata`
  MODIFY `id` int(128) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `blogimages`
--
ALTER TABLE `blogimages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT a táblához `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT a táblához `sendedmessage`
--
ALTER TABLE `sendedmessage`
  MODIFY `id` int(128) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
