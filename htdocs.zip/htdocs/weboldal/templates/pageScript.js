async function Index() {
    fetch("http://localhost/Weboldal/index.php?method=INDEXPAGE",
        {
            method: "GET",

        })
        .then(response => response.text);
}

async function Welcome() {
    fetch("http://localhost/Weboldal/index.php?method=WELCOMEPAGE",
        {
            method: "GET",

        })
        .then(response => response.text()).then(data => {
            console.log(data);
            alert(data);
        })
}

async function MainMenu() {
    fetch("http://localhost/Weboldal/index.php?method=MAINMENUPAGE",
        {
            method: "GET",

        })
        .then(response => response.text()).
        then(textHtml => document.getElementById("menu").innerHTML += textHtml);
}



async function Menu() {
    fetch("http://localhost/Weboldal/index.php?method=MENUPAGE",
        {
            method: "GET",
        })
        .then(response => response.text()).
        then(textHtml => document.getElementById("menu").innerHTML += textHtml);
}


async function Footer() {
    fetch("http://localhost/Weboldal/index.php?method=FOOTERPAGE",
        {
            method: "GET",

        })
        .then(response => response.text()).
        then(textHtml => document.getElementById("footer").innerHTML += textHtml);
}

