<?php

abstract class ModelDB
{
    private static PDO $pdo;

    public static function Init()
    {
        self::$pdo = new PDO("mysql:host=localhost:3307;dbname=zarovizsga", "pedro", "123456aA");
        self::$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public static function GetPage(string $key): bool|array
    {
        try {
            $result = self::$pdo->query("SELECT * FROM `pages` WHERE `key` = " . self::$pdo->quote($key));
            if ($result->rowCount() == 1) {
                $data = $result->fetchAll(PDO::FETCH_DEFAULT)[0];
                $result->closeCursor();
                return $data;
            }
            return false;
        } catch (Exception $ex) {

        }
    }

    public static function termekTipusLista(): array
    {
        $result = self::$pdo->query("SELECT * FROM `tipus`");
        $datas = $result->fetchAll(PDO::FETCH_ASSOC);
        $result->closeCursor();
        return $datas;
    }



    public static function TermekFeltoltes(string $gyarto, string $megnevezes, int $netto, int $brutto, string $tipus, int $darabSzam): bool
    {
        try {
            $prep = self::$pdo->prepare("INSERT INTO `termekek` VALUES (NULL, :gyarto, :megnevezes, :netto, :brutto, :tipus, :darabSzam)");
            $prep->bindParam(":gyarto", $gyarto, PDO::PARAM_STR);
            $prep->bindParam(":megnevezes", $megnevezes, PDO::PARAM_STR);
            $prep->bindParam(":netto", $netto, PDO::PARAM_INT);
            $prep->bindParam(":brutto", $brutto, PDO::PARAM_INT);
            $prep->bindParam(":tipus", $tipus, PDO::PARAM_STR);
            $prep->bindParam(":darabSzam", $darabSzam, PDO::PARAM_INT);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen termékbevitel!", $ex);
        }
    }

    public static function termekLista(): array
    {

        $result = self::$pdo->query("SELECT * FROM `termekek`");
        $datas = $result->fetchAll(PDO::FETCH_ASSOC);
        $result->closeCursor();
        return $datas;
    }

    public static function BeszerzesFeltoltes(string $azonosito, string $beszerzes, int $ar, int $darabSzam): bool
    {
        try {
            $prep = self::$pdo->prepare("INSERT INTO `beszerzes` VALUES (:azonosito, :beszerzes, :ar, :darabSzam)");
            $prep->bindParam(":azonosito", $azonosito, PDO::PARAM_STR);
            $prep->bindParam(":beszerzes", $beszerzes, PDO::PARAM_STR);
            $prep->bindParam(":ar", $ar, PDO::PARAM_INT);
            $prep->bindParam(":darabSzam", $darabSzam, PDO::PARAM_INT);
            return $prep->execute();
        } catch (Exception $ex) {
            throw new DBException("Sikertelen beszerzés!", $ex);
        }
    }

    public static function beszerzesDarabSzam(string $megnevezes): bool|array
    {
        try {
            $result = self::$pdo->query("SELECT * FROM `beszerzes` WHERE `azonosito` = " . self::$pdo->quote($megnevezes));
            if ($result->rowCount() == 1) {
                $datas = $result->fetchAll(PDO::FETCH_DEFAULT)[0];
                $result->closeCursor();
                return $datas;
            }
            return false;
        } catch (Exception $ex) {
            throw new DBException("Sikertelen darabszám lekérdezés!", $ex);
        }
    }



    public static function beszerzesLista(): array
    {
        $result = self::$pdo->query("SELECT * FROM `beszerzes`");
        $datas = $result->fetchAll(PDO::FETCH_ASSOC);
        $result->closeCursor();
        return $datas;
    }

    public static function beszerzesListaAdatok(): array
    {
        $result = self::$pdo->query("SELECT * FROM `beszerzes`");

        $datas = $result->fetchAll(PDO::FETCH_ASSOC);
        $result->closeCursor();

        return $datas;
    }

    public static function beszerzesListaAdat(string $azonosito): array
    {
        $result = self::$pdo->query("SELECT * FROM `beszerzes` WHERE `azonosito` = " . self::$pdo->quote($azonosito));

        $datas = $result->fetchAll(PDO::FETCH_ASSOC);
        $result->closeCursor();

        return $datas;
    }

}




