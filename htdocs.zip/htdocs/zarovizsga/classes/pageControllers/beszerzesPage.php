<?php

class BeszerzesPage
{


    public static function Run(): Template
    {

        $template = Template::Load("beszerzes.html");

        $darabszam = ModelDB::beszerzesListaAdatok();


        foreach ($darabszam as $darab) {

            if (!$darab["darabSzam"] == 0) {
                $template->AddData("BESZERZESEK", "
                    <tr'>
                        <td>{$darab['azonosito']}</td>
                        <td>{$darab['beszerzes']}</td>
                        <td>{$darab['ar']}</td>
                        <td>{$darab['darabSzam']}</td>
                    </tr>
                ");
            }
        }

        return $template;
    }
}