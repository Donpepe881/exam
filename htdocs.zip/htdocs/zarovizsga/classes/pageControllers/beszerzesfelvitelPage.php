<?php

class BeszerzesfelvitelPage
{



    public static function BeszerzesFeltoltese(Template $template)
    {

        if (isset($_POST["azonosito"]) && isset($_POST["beszerzes"]) && isset($_POST["ar"]) && isset($_POST["darab"])) {

            $azonosito = htmlspecialchars($_POST["azonosito"]);
            $beszerzes = htmlspecialchars($_POST["beszerzes"]);
            $ar = intval($_POST["ar"]);
            $darabSzam = intval($_POST["darab"]);


        }
        if (ModelDB::BeszerzesFeltoltes($azonosito, $beszerzes, $ar, $darabSzam)) {
            $template->AddData("RESULT", "Sikeres beszerzés!");
            $template->AddData("RESULTCLASS", "success");
        } else {
            $template->AddData("RESULT", "Sikertelen beszerzés!");
            $template->AddData("RESULTCLASS", "false");
        }

    }

    public static function termekLista(Template $template)
    {

        $termekek = ModelDB::termekLista();

        foreach ($termekek as $termek) {
            $template->AddData("SELECT", "
                    <option>{$termek['megnevezes']}</option>
                ");
        }
    }

    public static function Run(): Template
    {

        $template = Template::Load("beszerzesfelvitel.html");

        self::termekLista($template);

        if (isset($_POST["rendeles"])) {
            self::BeszerzesFeltoltese($template);
        }

        return $template;
    }
}