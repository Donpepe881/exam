<?php
class TermekPage
{



    public static function TermekElfogyott($termekDarabSzam): string
    {
        $nullaDarab = "";

        if ($termekDarabSzam == 0) {
            $nullaDarab = "red";
        }

        return $nullaDarab;
    }


    public static function Run(): Template
    {
        $template = Template::Load("termek.html");

        $adatok = ModelDB::termekLista();
        $darabszam = ModelDB::beszerzesLista();

        /* foreach ($adatok as $adat) {
            $darabszam = ModelDB::beszerzesDarabSzam($adat["megnevezes"]);
        } */

        foreach ($adatok as $adat) {
            foreach ($darabszam as $darab) {

                $trColor = self::TermekElfogyott($darab["darabSzam"]);

                $template->AddData("ADATOK", "
                    <tr style='background-color:{$trColor};'>
                        <td>{$adat['id']}</td>
                        <td>{$adat['gyarto']}</td>
                        <td onClick=\"header('Location: index.php?page=beszerzes');\">{$adat['megnevezes']}</td>
                        <td>{$adat['netto']}</td>
                        <td>{$adat['brutto']}</td>
                        <td>{$adat['tipus']}</td>
                        <td>{$darab['darabSzam']}</td>
                    </tr>
                ");
            }
        }

        return $template;
    }
}