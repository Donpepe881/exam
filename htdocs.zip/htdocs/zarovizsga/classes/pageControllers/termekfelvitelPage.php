<?php
class TermekfelvitelPage
{


    public static function TermekekFeltoltese(Template $template)
    {

        if (isset($_POST["gyarto"]) && isset($_POST["megnevezes"]) && isset($_POST["netto"]) && isset($_POST["tipus"])) {
            $gyarto = htmlspecialchars($_POST["gyarto"]);
            $megnevezes = htmlspecialchars($_POST["megnevezes"]);
            $netto = intval($_POST["netto"]);
            $brutto = $netto * 1.27;
            $tipus = htmlspecialchars($_POST["tipus"]);
            $darabSzam = 1;

        }
        if (ModelDB::TermekFeltoltes($gyarto, $megnevezes, $netto, $brutto, $tipus, $darabSzam)) {
            $template->AddData("RESULT", "Sikeres termék feltöltés!");
            $template->AddData("RESULTCLASS", "success");
        } else {
            $template->AddData("RESULT", "Sikertelen termék feltöltés!");
            $template->AddData("RESULTCLASS", "false");
        }

    }

    public static function tipusLista(Template $template)
    {

        $termekTipusok = ModelDB::termekTipusLista();


        foreach ($termekTipusok as $tipusok) {
            $template->AddData("TIPUS", "
        <select name='tipus'>
            <option>{$tipusok['élelmiszer']}</option>
            <option>{$tipusok['vegyszer']}</option>
            <option>{$tipusok['elektronikai cikk']}</option>
            <option>{$tipusok['háztartási eszköz']}</option>
            <option>{$tipusok['egyéb']}</option>
        </select>");
        }
    }



    public static function Run(): Template
    {

        $template = Template::Load("termekfelvitel.html");

        self::tipusLista($template);

        if (isset($_POST["felvitel"])) {
            self::TermekekFeltoltese($template);
        }


        return $template;
    }
}