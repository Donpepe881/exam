-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: localhost:3307
-- Létrehozás ideje: 2024. Feb 10. 16:51
-- Kiszolgáló verziója: 10.4.32-MariaDB
-- PHP verzió: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `zarovizsga`
--
CREATE DATABASE zarovizsga;
-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `beszerzes`
--

CREATE TABLE `beszerzes` (
  `azonosito` varchar(512) NOT NULL,
  `beszerzes` varchar(512) NOT NULL,
  `ar` int(255) NOT NULL,
  `darabSzam` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `beszerzes`
--

INSERT INTO `beszerzes` (`azonosito`, `beszerzes`, `ar`, `darabSzam`) VALUES
('alma', '2024.02.08.', 50, 10),
('alma', '2024.02.08.', 50, 10),
('alma', '2024.02.08.', 50, 10),
('sütő', '2024.02.06.', 400, 3),
('alma', '2024.02.05.', 60, 0);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pages`
--

CREATE TABLE `pages` (
  `key` varchar(32) NOT NULL,
  `name` varchar(128) NOT NULL,
  `parent` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `pages`
--

INSERT INTO `pages` (`key`, `name`, `parent`) VALUES
('beszerzes', 'Beszerzések', 'false'),
('beszerzesfelvitel', 'Beszerzés felviteli oldal', 'false'),
('logout', 'Kijelentkezés', 'false'),
('main', 'Főoldal', 'false'),
('notAllowed', 'Hozzáférés megtagadva!', 'false'),
('termek', 'Termékek', 'false'),
('termekfelvitel', 'Termék felviteli oldal', 'false'),
('users', 'Felhasználók', 'main'),
('vedett1', 'Védett oldal', 'main'),
('welcome', 'Üdvözlőlap', 'false');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `termekek`
--

CREATE TABLE `termekek` (
  `id` int(255) NOT NULL,
  `gyarto` varchar(512) NOT NULL,
  `megnevezes` varchar(512) NOT NULL,
  `netto` int(255) NOT NULL,
  `brutto` int(255) NOT NULL,
  `tipus` varchar(512) NOT NULL,
  `darabszam` int(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `termekek`
--

INSERT INTO `termekek` (`id`, `gyarto`, `megnevezes`, `netto`, `brutto`, `tipus`, `darabszam`) VALUES
(1, 'Idared', 'alma', 200, 254, 'élelmiszer', 1),
(2, 'Hansa', 'sütő', 300, 381, 'elektronikai cikk', 1),
(3, 'Hansa', 'sütő', 300, 381, 'elektronikai cikk', 1);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `tipus`
--

CREATE TABLE `tipus` (
  `élelmiszer` varchar(128) NOT NULL,
  `vegyszer` varchar(128) NOT NULL,
  `elektronikai cikk` varchar(128) NOT NULL,
  `háztartási eszköz` varchar(128) NOT NULL,
  `egyéb` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `tipus`
--

INSERT INTO `tipus` (`élelmiszer`, `vegyszer`, `elektronikai cikk`, `háztartási eszköz`, `egyéb`) VALUES
('élelmiszer', 'vegyszer', 'elektronikai cikk', 'háztartási eszköz', 'egyéb');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `email` varchar(255) NOT NULL,
  `name` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`key`);

--
-- A tábla indexei `termekek`
--
ALTER TABLE `termekek`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`email`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `termekek`
--
ALTER TABLE `termekek`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
