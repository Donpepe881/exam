<?php
$t[] = "Helló!";
$t[] = true;
$t[] = 3.14;
$t[3] = 5;
$t[0] = "Világ";
$t[] = array("Helló", true, 3.14, 5);
print_r($t);

$at["elso"] = "Helló világ!";
$at["masodik"] = false;
$at["harmadik"] = 2.72;
$at["altomb"] = array("Helló", true, 3.14, 5);
$at["asszocAlTomb"] = array("a" => 10, "b" => "Szöveg");
$at["asszocAlTomb"]["b"] = "Másik szöveg";
$at[] = "Valami...";
var_dump($at);