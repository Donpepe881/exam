<?php
$res *= 3;