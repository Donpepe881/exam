<?php
if(isset($_POST["feltolt"]))
{
    if(isset($_FILES["img"]) && is_array($_FILES["img"]))
    {
        if($_FILES["img"]["error"] === 0)
        {
            if($_FILES["img"]["size"] <= 2*1024*1024)
            {
                $mimeFilter = finfo_open(FILEINFO_MIME_TYPE);
                $mime = finfo_file($mimeFilter, $_FILES["img"]["tmp_name"]);
                if($mime == "image/jpeg" || $mime == "image/png")
                {
                    move_uploaded_file($_FILES["img"]["tmp_name"], basename($_FILES["img"]["name"]));
                    if(file_exists(basename($_FILES["img"]["name"])))
                    {
                        $result["success"] = true;
                        $result["details"] = "Sikeres feltöltés!";
                        $result["image"] = basename($_FILES["img"]["name"]);
                    }
                    else
                    {
                        $result["success"] = false;
                        $result["details"] = "A kép végleges mozgatása nem sikerült! Ismeretlen hiba!";
                    }
                }
                else
                {
                    $result["success"] = false;
                    $result["details"] = "Ismeretlen képformátum! ($mime)";
                }
            }
            else
            {
                $result["success"] = false;
                $result["details"] = "Túl nagy fájl! Max 2 MB tölthető fel!";
            }
        }
        else
        {
            $result["success"] = false;
            $result["details"] = "A feltöltés meghiúsult!";
        }
    }
    else
    {
        $result["success"] = false;
        $result["details"] = "Nem került kép feltöltésre!";
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <style>
            .success, .error
            {
                font-weight: bold;
                font-size: 26pt;
            }

            .success
            {
                color: green;
            }

            .error
            {
                color: red;
            }
        </style>
    </head>
    <body>
        <form method="post" enctype="multipart/form-data">
            <label for="kep">Kép fájl</label>
            <input type="file" name="img" id="kep" accept="image/jpeg, image/png"><br>
            <input type="submit" name="feltolt" value="Feltöltés">
        </form>
        <?php
        if(isset($result) && is_array($result))
        {
            if($result["success"])
            {
                print("<p class=\"success\">{$result["details"]}</p>");
                print("<img src=\"{$result["image"]}\" title=\"Feltöltött kép\">");
            }
            else
            {
                print("<p class=\"error\">{$result["details"]}</p>");
            }
        }
        ?>
    </body>
</html>
