<?php
require_once("functions.php");
if(isset($_POST["ok"]))
{
    if(FajlFeltoltes("fajl", array("text/plain", "text/csv"), "upload/alap.csv"))
    {
        $result = CSVFeldolgzo("upload/alap.csv", ";", false);
        //print_r($result);
    }
    else
    {
        $result = "A feltöltés meghiúsult!";
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form method="post" enctype="multipart/form-data">
            <label for="fajl">CSV fájl</label>
            <input type="file" name="fajl" id="fajl" accept="text/plain, text/csv"><br>
            <input type="submit" name="ok" value="Feltölt">
        </form>
        <?php
        if(isset($result) && is_array($result))
        {
            print("<table>");
            $first = true;
            foreach($result as $sor)
            {
                if($first && !array_is_list($sor))
                {
                    print("<tr>");
                    foreach (array_keys($sor) as $key)
                    {
                        print("<th>$key</th>");
                    }
                    print("</tr>");
                }
                print("<tr>");
                foreach($sor as $cella)
                {
                    print("<td>$cella</td>");
                }
                print("</tr>");
                $first = false;
            }
            print("</table>");
        }
        elseif(isset($result))
        {
            print("<h2 style=\"color: red;\">$result</h2>");
        }
        ?>
    </body>
</html>
