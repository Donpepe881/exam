<?php
function ASD()
{
    ASD();
}

ASD();