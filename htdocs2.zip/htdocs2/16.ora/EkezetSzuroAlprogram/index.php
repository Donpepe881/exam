<?php
require_once("functions.php");
if(isset($_POST["ok"]))
{
    if(isset($_POST["szoveg"]) && trim($_POST["szoveg"]) != "")
    {
        $result["success"] = true;
        $result["result"] = EkezetTisztito(htmlspecialchars($_POST["szoveg"]));
    }
    else
    {
        $result["success"] = false;
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        if(isset($result))
        {
            if($result["success"])
            {
                print("<h2 style=\"color: green;\">{$result["result"]}</h2>");
            }
            else
            {
                print("<h2 style=\"color: red;\">Hiányzó szöveg!</h2>");
            }
        }
        ?>
        <form method="post">
            <label for="szoveg">Ékezetmentesítendő szöveg:</label>
            <input type="text" name="szoveg" id="szoveg" placeholder="Ékezetmentesítendő szöveg"><br>
            <input type="submit" name="ok" value="Konvertál">
        </form>
    </body>
</html>
