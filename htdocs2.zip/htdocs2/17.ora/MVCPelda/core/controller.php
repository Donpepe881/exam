<?php
function ParseIndex():void
{
    //TODO: CSV-ből betölteni! --> Modell!!!
    $menus = array(array("Főoldal","index.php"), array("Galéria", "?page=gallery"));
    $result = "";
    foreach($menus as $menu)
    {
        $result .= LoadTemplate("menuitem", array("NAME" => $menu[0], "URL" => $menu[1]));
    }
    $result = LoadTemplate("menubase", array("MENUITEMS" => $result));
    $result = LoadTemplate("index", array("MENU" => $result));
    print($result);
}