<?php
require_once("core/view.php");
require_once("core/controller.php");
//print(LoadTemplate("index", array("TITLE" => "Első MVC oldalunk!", "HEADER" => "HURRÁ!", "FOOTER" => "ok")));
ParseIndex();
