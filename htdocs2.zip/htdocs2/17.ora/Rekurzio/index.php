<?php
require_once("functions.php");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $faktor = 8;
        print("<p>A $faktor faktoriálisa:<br>");
        print("Rekurzióval: ".Faktorialis($faktor)."<br>");
        print("Ciklussal: ".FaktorialisCiklus($faktor)."</p>");
        $fib = 10;
        print("<p>A $fib. fibonacci szám:<br>");
        print("Rekurzióval: ". Fibonacci($fib)."<br>");
        print("Ciklussal: ". FibonacciCiklus($fib)."</p>");
        ?>
    </body>
</html>
