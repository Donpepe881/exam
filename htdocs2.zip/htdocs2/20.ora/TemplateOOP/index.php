<?php
require_once("Template.php");
require_once("View.php");
/*$template = new Template("pelda.html");
//print_r($template->getFlags());
$template->AddData("CONTENT", "Működik!");
$template->AddData("CONTENT", "<h1>Működik!</h1>");
$template->AddData("TITLE", "Egy példa template...");
$template->AddData("CONTENT", "<h1>Még mindig működik!</h1>");
//$template->InsertData("CONTENT", 1, "<h2>Ez egy beszúrt elem...</h2>");
//$template->DeleteExactData("CONTENT", 1);
//$template->DeleteData("CONTENT");
print($template->Render());*/
$view = new View("pelda.html");
$view->getBaseTemplate()->AddData("TITLE", "Egy példa template...");
$view->getBaseTemplate()->AddData("CONTENT", "<h1>Még mindig működik!</h1>");
$content = new Template("section.html");
$content->AddData("HEADING", "Ez a tartalom címe");
$content->AddData("CONTENT", "Ez pedig maga a tartalom...");
$view->getBaseTemplate()->AddData("CONTENT", $content->Render());
$view->FinalRender();