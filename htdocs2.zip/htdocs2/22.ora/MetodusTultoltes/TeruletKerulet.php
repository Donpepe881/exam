<?php
class TeruletKerulet
{
    private static function NegyzetKerulet(int $a) : int
    {
        return $a * 4;
    }
    
    private static function TeglalapKerulet(int $a, int $b) : int
    {
        return ($a + $b) * 2;
    }
    
    private static function HaromszogKerulet(int $a, int $b, int $c)
    {
        return $a + $b + $c;
    }
    
    private static function KorKerulet(float $r) : float
    {
        return 2 * $r * pi();
    }
    
    public static function __callStatic($name, $arguments)
    {
        if($name == "Kerulet")
        {
            if(count($arguments) == 1)
            {
                if(is_float($arguments[0]))
                {
                    return self::KorKerulet($arguments[0]);
                }
                elseif(is_int($arguments[0]))
                {
                    return self::NegyzetKerulet($arguments[0]);
                }
            }
            elseif(count($arguments) == 2)
            {
                return self::TeglalapKerulet($arguments[0], $arguments[1]);
            }
            elseif(count($arguments) == 3)
            {
                return self::HaromszogKerulet($arguments[0], $arguments[1], $arguments[2]);
            }
        }
    }
}
