<?php

class Controller
{
    //private View $view;
    //private Model $model;
    
    /*public function getView(): View {
        return $this->view;
    }*/

    /*public function getModel(): Model {
        return $this->model;
    }*/

    /*public function __construct()
    {
        //$this->model = new Model();
        //$this->view = new View("index.html");
        View::Init("index.html");
    }*/
    
    public static function Init() : void
    {
        View::Init("index.html");
    }
        
    public static function Route()
    {
        $page = isset($_GET["page"]) ? htmlspecialchars($_GET["page"]) : "index";
        $pages = Model::ReadCSV("pages");
        $pageData = "";
        foreach($pages["data"] as $pageRow)
        {
            if($pageRow[0] == $page)
            {
                $pageData = $pageRow;
                break;
            }
        }
        if($pageData != "")
        {
            //call_user_func_array(array($this, ucfirst($page)."Controller"), array()); //pl.: index --> $this->IndexController()
            call_user_func(array("Controller", ucfirst($page)."Controller"));
        }
        else
        {
            self::Error404Controller();
        }
    }
    
    private static function IndexController() : void
    {
        //$content = new Template("main.html");
        $content = Template::Load("main.html");
        //$content->AddData("TITLE", "Főoldal");
        $content->TITLE = "Főoldal";
        //$content->AddData("WELCOME", "Üdvözöllek az oldalamon!");
        $content->WELCOME = "Üdvözöllek az oldalamon!";
        //unset($content->WELCOME);
        $prompt = Template::Parse("<h2>Ez egy hozzáadott, prompt létrehozott template, belső adat: §PELDA§</h2>");
        $prompt->AddData("PELDA", "Ez a helyőrző adata...");
        $content->AddData("WELCOME", $prompt->Render());
        View::getBaseTemplate()->AddData("CONTENT", $content->Render());
        View::getBaseTemplate()->AddData("TITLE", "Az MVC oldalunk főoldala");
    }
    
    private static function RegisterController() : void
    {
        $registerForm = Template::Load("register.html");
        $registerForm->AddData("TITLE", "Regisztráció");
        if(isset($_POST["ok"]))
        {
            $writeback = true;
            if(isset($_POST["name"]) && filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL) && filter_input(INPUT_POST, "email2", FILTER_VALIDATE_EMAIL) && isset($_POST["pass"]) && isset($_POST["pass2"]))
            {
                $name = htmlspecialchars($_POST["name"]);
                $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
                $pass = htmlspecialchars($_POST["pass"]);
                if($email == filter_input(INPUT_POST, "email2", FILTER_SANITIZE_EMAIL))
                {
                    if($pass == htmlspecialchars($_POST["pass2"]))
                    {
                        if(preg_match("/[0-9]+/", $pass) && strtolower($pass) != $pass && strtoupper($pass) != $pass && mb_strlen($pass) >= 8)
                        {
                            Model::WriteCSV("users", array(array($name, $email, hash("sha256", $pass))), ";", true);
                            $registerForm->AddData("RESULT", "Sikeres regisztráció!");
                            $registerForm->AddData("RESULTCLASS", "success");
                            $writeback = false;
                        }
                        else
                        {
                            $registerForm->AddData("RESULT", "Gyenge jelszó! A jelszónak legalább 8 karakteresnek kell lennie, melyben kis-nagy betű és szám is szerepel!");
                            $registerForm->AddData("RESULTCLASS", "fail");
                        }
                    }
                    else
                    {
                        $registerForm->AddData("RESULT", "Nem egyező jelszavak!");
                        $registerForm->AddData("RESULTCLASS", "fail");
                    }
                }
                else
                {
                    $registerForm->AddData("RESULT", "Nem egyező email címek!");
                    $registerForm->AddData("RESULTCLASS", "fail");
                }
            }
            else
            {
                $registerForm->AddData("RESULT", "Hiányos adatok!");
                $registerForm->AddData("RESULTCLASS", "fail");
            }
            if($writeback) //logikai értékeket nem kell külön kiértékelni
            {
                $registerForm->AddData("NAME", $_POST["name"]);
                $registerForm->AddData("EMAIL", $_POST["email"]);
                $registerForm->AddData("EMAILK", $_POST["email2"]);
                /*$registerForm->AddData("PASS", $_POST["pass"]);
                $registerForm->AddData("PASSK", $_POST["pass2"]);*/
            }
        }
        View::getBaseTemplate()->AddData("CONTENT", $registerForm->Render());
        View::getBaseTemplate()->AddData("TITLE", "Az MVC oldalunk regisztrációs oldala");
    }
    
    private static function LoginController() : void
    {
        $loginForm = Template::Load("login.html");
        $loginForm->AddData("TITLE", "Belépés");
        if(isset($_POST["ok"]))
        {
            if(filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL) && isset($_POST["pass"]))
            {
                $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
                $pass = hash("sha256", htmlspecialchars($_POST["pass"]));
                $logins = Model::ReadCSV("users");
                $login = false;
                foreach ($logins["data"] as $row)
                {
                    if(trim($row[1]) == trim($email) && trim($row[2]) == trim($pass))
                    {
                        $login = true;
                        break;
                    }
                }
                if($login)
                {
                    $loginForm->AddData("RESULT", "Sikeres belépés!");
                    $loginForm->AddData("RESULTCLASS", "success");
                }
                else
                {
                    $loginForm->AddData("RESULT", "Hibás felhasználónév / jelszó!");
                    $loginForm->AddData("RESULTCLASS", "fail");
                }
            }
            else
            {
                $loginForm->AddData("RESULT", "Hiányos adatok!");
                $loginForm->AddData("RESULTCLASS", "fail");
            }
        }
        View::getBaseTemplate()->AddData("CONTENT", $loginForm->Render());
        View::getBaseTemplate()->AddData("TITLE", "Az MVC oldalunk belépés oldala");
    }
    
    private static function Error404Controller() : void
    {
        View::getBaseTemplate()->AddData("CONTENT", Template::Load("404.html")->Render());
        View::getBaseTemplate()->AddData("TITLE", "A megadott oldal nem található!");
    }
}
