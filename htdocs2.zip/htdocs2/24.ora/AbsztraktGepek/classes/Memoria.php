<?php

class Memoria extends GepAlkatresz
{
    private MemoriaTipus $tipus;
    private float $frekvencia;
    private int $kesleltetes;
    
    public function getTipus(): MemoriaTipus {
        return $this->tipus;
    }

    public function getFrekvencia(): float {
        return $this->frekvencia;
    }

    public function getKesleltetes(): int {
        return $this->kesleltetes;
    }

    private function setTipus(MemoriaTipus $tipus): void 
    {
        $this->tipus = $tipus;
    }

    private function setFrekvencia(float $frekvencia): void 
    {
        $this->frekvencia = $frekvencia;
    }

    private function setKesleltetes(int $kesleltetes): void 
    {
        if($kesleltetes >= 1 && $kesleltetes <= 40)
        {
            $this->kesleltetes = $kesleltetes;
        }
        else
        {
            //hiba dobása...
            $this->kesleltetes = -1;
        }
    }

    public function __construct(string $megnevezes, string $szeriaszam, int $ar, int $szel, int $hossz, MemoriaTipus $tipus, float $frekvencia, int $kesleltetes)
    {
        parent::__construct($megnevezes, $szeriaszam, $ar, $szel, $hossz);
        $this->setTipus($tipus);
        $this->setFrekvencia($frekvencia);
        $this->setKesleltetes($kesleltetes);
    }

    
    public function AlapanyagAr(): int
    {
        //15g / cm2 --> a szél / hossz cm-ben megadva és feltétlezve, hogy 3000 ft. egy gramm alapanyag / nemesfém
        return $this->getSzel() * $this->getHossz() * 15 * 3000;
    }
}
