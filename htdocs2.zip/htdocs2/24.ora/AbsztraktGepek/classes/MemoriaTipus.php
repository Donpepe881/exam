<?php
enum MemoriaTipus : int
{
    case SDRAM = 0;
    case DDR1 = 1;
    case DDR2 = 2;
    case DDR3 = 3;
    case DDR4 = 4;
    case DDR5 = 5;
}

