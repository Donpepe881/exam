<?php
abstract class GepAlkatresz implements JsonSerializable
{
    private string $megnevezes, $szeriaszam;
    private int $ar, $szel, $hossz;
    
    public function getMegnevezes(): string {
        return $this->megnevezes;
    }

    public function getSzeriaszam(): string {
        return $this->szeriaszam;
    }

    public function getAr(): int {
        return $this->ar;
    }

    public function getSzel(): int {
        return $this->szel;
    }

    public function getHossz(): int {
        return $this->hossz;
    }

    protected function setMegnevezes(string $megnevezes): void
    {
        $this->megnevezes = $megnevezes;
    }

    protected function setSzeriaszam(string $szeriaszam): void
    {
        $this->szeriaszam = $szeriaszam;
    }

    public function setAr(int $ar): void
    {
        $this->ar = $ar;
    }

    protected function setSzel(int $szel): void
    {
        $this->szel = $szel;
    }

    protected function setHossz(int $hossz): void
    {
        $this->hossz = $hossz;
    }
    
    protected function __construct(string $megnevezes, string $szeriaszam, int $ar, int $szel, int $hossz)
    {
        $this->setMegnevezes($megnevezes);
        $this->setSzeriaszam($szeriaszam);
        $this->setAr($ar);
        $this->setSzel($szel);
        $this->setHossz($hossz);
    }
    
    public function __toString()
    {
        return "[{$this->szeriaszam}] - {$this->megnevezes}";
    }
    
    public abstract function AlapanyagAr() : int;
    
    public function ToXML() : SimpleXMLElement
    {
        $xml = new SimpleXMLElement("<GepAlkatresz></GepAlkatresz>");
        $xml->AddAttribute("megnevezes", $this->megnevezes);
        $xml->AddAttribute("szeriaszam", $this->szeriaszam);
        $xml->AddAttribute("ar", $this->ar);
        $xml->addAttribute("szelesseg", $this->szel);
        $xml->addAttribute("hosszusag", $this->hossz);
        return $xml;
    }
    
    public function AttachToXMLDocument(SimpleXMLElement $xmldoc) : SimpleXMLElement
    {
        $xml = $xmldoc->addChild("GepAlkatresz");
        $xml->AddAttribute("megnevezes", $this->megnevezes);
        $xml->AddAttribute("szeriaszam", $this->szeriaszam);
        $xml->AddAttribute("ar", $this->ar);
        $xml->addAttribute("szelesseg", $this->szel);
        $xml->addAttribute("hosszusag", $this->hossz);
        return $xml;
    }
    
    public function jsonSerialize(): mixed
    {
        return array("megnevezes" => $this->megnevezes, "szeriaszam" => $this->szeriaszam, "ar" => $this->ar, "szelesseg" => $this->szel, "hosszusag" => $this->hossz);
    }
    
    public static function DeserializeJson(array $jsonDataArray) : GepAlkatresz
    {
        if(array_key_exists("gepAlkatresz", $jsonDataArray))
        {
            switch ($jsonDataArray["gepAlkatresz"])
            {
                case "alaplap":
                    return new Alaplap($jsonDataArray["megnevezes"], $jsonDataArray["szeriaszam"], intval($jsonDataArray["ar"]), intval($jsonDataArray["szelesseg"]), intval($jsonDataArray["hosszusag"]), $jsonDataArray["chipset"], MemoriaTipus::from(intval($jsonDataArray["tipus"])));
                case "memória":
                    return new Memoria($jsonDataArray["megnevezes"], $jsonDataArray["szeriaszam"], intval($jsonDataArray["ar"]), intval($jsonDataArray["szelesseg"]), intval($jsonDataArray["hosszusag"]), MemoriaTipus::from(intval($jsonDataArray["tipus"])), floatval($jsonDataArray["frekvencia"]), intval($jsonDataArray["kesleltetes"]));
                case "processzor":
                    return new Processzor($jsonDataArray["megnevezes"], $jsonDataArray["szeriaszam"], intval($jsonDataArray["ar"]), intval($jsonDataArray["szelesseg"]), intval($jsonDataArray["hosszusag"]), $jsonDataArray["tokozas"], $jsonDataArray["architektura"], floatval($jsonDataArray["orajel"]));
                default :
                    throw new InvalidArgumentException("A megadott JSON adat szerkezetileg egyik Gép alkatrésznek sem felel meg!");
            }
        }
        else
        {
            throw new InvalidArgumentException("A bejövő JSON adat nem értelmezhető Gép alkatrészként!");
        }
    }
}
