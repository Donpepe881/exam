<?php
define("MAXWIDTH", 800);
define("MAXHEIGHT", 600);
if(isset($_POST["ok"]))
{
    if(isset($_FILES["image"]) && $_FILES["image"]["error"] == 0)
    {
        $mime = finfo_file(finfo_open(FILEINFO_MIME_TYPE), $_FILES["image"]["tmp_name"]);
        if($mime == "image/jpeg")
        {
            if(move_uploaded_file($_FILES["image"]["tmp_name"], "tmp.jpg"))
            {
                $kep = imagecreatefromjpeg("tmp.jpg");
                $arany = imagesx($kep) / imagesy($kep);
                if(imagesx($kep) > MAXWIDTH)
                {
                    $meretezett = imagecreatetruecolor(MAXWIDTH, intval(MAXWIDTH / $arany));
                    imagecopyresampled($meretezett, $kep, 0, 0, 0, 0, MAXWIDTH, intval(MAXWIDTH / $arany), imagesx($kep), imagesy($kep));
                    $kep = $meretezett;
                }
                if(imagesy($kep) > MAXHEIGHT)
                {
                    $meretezett = imagecreatetruecolor(intval(MAXHEIGHT * $arany), MAXHEIGHT);
                    imagecopyresampled($meretezett, $kep, 0, 0, 0, 0, intval(MAXHEIGHT * $arany), MAXHEIGHT, imagesx($kep), imagesy($kep));
                    $kep = $meretezett;
                }
                $logo = imagecreatefrompng("logo.png");
                $logoSize = intval(imagesx($kep) / 4);
                imagecopyresampled($kep, $logo, imagesx($kep) - $logoSize, imagesy($kep) - $logoSize, 0, 0, $logoSize, $logoSize, imagesx($logo), imagesy($logo));
                imagepng($kep, "kepek/".basename($_FILES["image"]["name"]).".png");
                unlink("tmp.jpg");
                $response["info"] = "Sikeres konverzió!";
                $response["image"] = "kepek/".basename($_FILES["image"]["name"]).".png";
            }
            else
            {
                $response["info"] = "A feltöltés sikertelen! Egyéb hiba!";
            }
        }
        else
        {
            $response["info"] = "Nem támogatott formátum!";
        }
    }
    else
    {
        $response["info"] = "A feltöltés meghiúsult!";
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        if(isset($response))
        {
            print("<h2>{$response["info"]}</h2>");
            if(isset($response["image"]))
            {
                print("<img src=\"{$response["image"]}\" title=\"konvertált kép\" alt=\"konvertált kép\">");
            }
        }
        ?>
        <form method="post" enctype="multipart/form-data">
            <label for="image">Kép</label>
            <input type="file" name="image" id="image" accept="image/jpeg"><br>
            <input type="submit" name="ok" value="Feltöltés">
        </form>
    </body>
</html>
