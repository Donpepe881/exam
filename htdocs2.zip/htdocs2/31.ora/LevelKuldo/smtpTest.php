<?php
require_once("autloader.php");
$mailer = new PHPMailer\PHPMailer\PHPMailer(true);
$mailer->setFrom("kcsweb@ruander.eu");
$mailer->addAddress("kis.balazs@ruander.hu");
$mailer->Subject = "Próba levél SMTP";
$mailer->Body = "Ez SMTP-n ment keresztül";
$mailer->CharSet = "utf-8";
$mailer->isSMTP();
$mailer->Host = "mail.ruander.eu";
$mailer->SMTPAuth = true;
$mailer->Username = "kcsweb@ruander.eu";
$mailer->Password = "kCsWeb123..";
$mailer->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
$mailer->Port = 465;
$mailer->send();

