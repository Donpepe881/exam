<!DOCTYPE html>
<html>
  <head>
	<meta charset="utf-8">
	<title>Számok százig</title>
  </head>
  <body>
    <ul>
	<?php
	for($i = 1; $i <= 100; $i++)
	{
		print("<li style=\"".($i % 3 == 0 ? "color: red;" : "")."\">$i</li>\n");
	}
	?>
	</ul>
  </body>
</html>