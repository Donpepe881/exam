<?php
$res *= 3;