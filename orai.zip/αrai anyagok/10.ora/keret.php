<!DOCTYPE html>
<html>
  <head>
	<meta charset="utf-8">
	<title>Moduláris példa</title>
  </head>
  <body>
    <?php
	$res = 10;
	require("func.php");
	print("<h1>$res</h1>");
	require("func.php");
	print("<h1>$res</h1>");
	require("func.php");
	print("<h1>$res</h1>");
	?>
  </body>
</html>