<?php
$algok = hash_algos();
foreach($algok as $algo)
{
	print($algo."<br>");
}
?>