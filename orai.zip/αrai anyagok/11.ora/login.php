<?php
if (isset ($_POST["ok"])) {
	if (isset ($_POST["fnev"]) && isset ($_POST["jelszo"])) {
		$fnev = htmlspecialchars($_POST["fnev"]);
		$jelszo = hash("sha256", $_POST["jelszo"]);
		if ($fnev == "admin" && $jelszo == "86a53dd33aa2112aa01a03ed488a794cfbbfe92607678827e25b7b1f52dad8a2") {
			/*$eredmeny = "<h1>Sikeres belépés</h1> Az oldal hamarosan továbbítja a belső oldalra...<script>window.setTimeout(function()
					 {
						 window.location.href='https://www.google.com';
					 }, 3000);</script>";*/
			header("Location: https://www.google.com");
		} else {
			$eredmeny = "<h1>Hibás felhasználónév / jelszó!</h1>";
		}
	} else {
		$eredmeny = "<h1>Hiányos adatok!</h1>";
	}
}
?>
<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<title>Login rendszer</title>
</head>

<body>
	<?php
	if (isset ($eredmeny)) {
		print ("$eredmeny");
	}
	?>
	<form method="post">
		<label for="fnev">Felhasználónév</label>
		<input type="text" name="fnev" id="fnev" placeholder="Felhasználónév"><br>
		<label for="jelszo">Jelszó</label>
		<input type="password" name="jelszo" id="jelszo" placeholder="Jelszó"><br>
		<input type="submit" name="ok" value="Belépés">
	</form>
</body>

</html>