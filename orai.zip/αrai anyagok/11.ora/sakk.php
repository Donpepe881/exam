<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<title>Sakktábla</title>
	<style>
		td {
			width: 30px;
			height: 30px;
			margin: 0;
			padding: 0;
		}

		table {
			border: 4px solid black;
			padding: 0;
		}

		.feher {
			background-color: white;
		}

		.fekete {
			background-color: black;
		}
	</style>
</head>

<body>
	<?php
	if (isset ($_GET["x"]) && isset ($_GET["y"]) && filter_input(INPUT_GET, "x", FILTER_VALIDATE_INT) && filter_input(INPUT_GET, "y", FILTER_VALIDATE_INT)) {
		$x = filter_input(INPUT_GET, "x", FILTER_SANITIZE_NUMBER_INT);
		$y = filter_input(INPUT_GET, "y", FILTER_SANITIZE_NUMBER_INT);
		if ($x > 0 && $y > 0) {
			print ("<table>");
			for ($i = 0; $i < $y; $i++) {
				print ("<tr>");
				for ($j = 0; $j < $x; $j++) {
					print ("<td class=\"" . (($i + $j) % 2 == 0 ? "fekete" : "feher") . "\">&nbsp;</td>");
				}
				print ("</tr>");
			}
			print ("</table>");
		} else {
			print ("<h1>Az X és Y értéke nagyobb kell legyen mint 0!</h1>");
		}
	} else {
		print ("<h1>Az X és Y értéke nem értelmezhető egész számként!</h1>");
	}
	?>
</body>

</html>