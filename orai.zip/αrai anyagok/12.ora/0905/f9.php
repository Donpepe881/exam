<?php
//print_r($_SERVER);
print("A te IP címed: ".$_SERVER["REMOTE_ADDR"]."<br>");
print("A böngésződ adatai: ".$_SERVER["HTTP_USER_AGENT"]);
?>