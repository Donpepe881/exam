<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Profil oldalunk</title>
        <link href="style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <section id="container">
            <header>
                <nav>
                    <ul>
                        <li><a href="index.php" title="Főoldal">Főoldal</a></li>
                        <li><a href="?page=experience" title="Tapasztalatok">Tapasztalatok</a></li>
                        <li><a href="?page=hobbies" title="Hobbik">Hobbik</a></li>
                    </ul>
                </nav>
            </header>
            <section id="mainContent">
                <?php
                  if(isset($_GET["page"]))
                  {
                      $page = htmlspecialchars($_GET["page"]);
                      if($page == "experience" || $page == "hobbies")
                      {
                          require("pages/$page.inc.php");
                      }
                      else
                      {
                          require("pages/404.inc.php");
                      }
                  }
                  else
                  {
                      require("pages/main.inc.php");
                  }
                ?>
            </section>
            <footer>
                Copyright 2023
            </footer>
        </section>
    </body>
</html>
