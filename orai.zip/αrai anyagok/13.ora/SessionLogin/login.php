<?php
session_start();
if(isset($_POST["ok"]))
{
    if(isset($_POST["username"]) && isset($_POST["password"]))
    {
        $user = htmlspecialchars($_POST["username"]);
        $pass = htmlspecialchars($_POST["password"]);
        if($user == "admin" && hash("sha256", $pass) == "86a53dd33aa2112aa01a03ed488a794cfbbfe92607678827e25b7b1f52dad8a2")
        {
            $_SESSION["login"] = true;
            header("Location: index.php");
        }
        else
        {
            session_destroy();
            $result["success"] = false;
            $result["details"] = "Hibás felhasználónév / jelszó!";
        }
    }
    else
    {
        session_destroy();
        $result["success"] = false;
        $result["details"] = "Hiányos adatok!";
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Belépés</title>
        <link href="style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <section id="container">
            <section id="mainContent" style="text-align: center;">
                <?php
                if(isset($result) && is_array($result))
                {
                    print("<p class=\"".($result["success"]?"success":"error")."\">{$result["details"]}</p>");
                }
                ?>
                <h1>Belépés</h1>
                <form method="post">
                    <label for="user">Felhasználónév</label><br>
                    <input type="text" name="username" id="user" placeholder="Felhasználónév"><br>
                    <label for="pass">Jelszó</label><br>
                    <input type="password" name="password" id="pass" placeholder="Jelszó"><br>
                    <input type="submit" name="ok" value="Belépés">
                </form>
            </section>
        </section>
    </body>
</html>
