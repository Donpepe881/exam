<?php
session_start();
if(isset($_POST["ok"]))
{
    $pattern = "/#[0-9A-Fa-f]{3,6}/";
    if(preg_match($pattern, $_POST["eloter"]) !== false && preg_match($pattern, $_POST["hatter"]) !== false)
    {
        $_SESSION["eloter"] = $_POST["eloter"];
        $_SESSION["hatter"] = $_POST["hatter"];
        $result["success"] = true;
        $result["details"] = "Sikeres színkombináció mentés!";
    }
    else
    {
        $result["success"] = false;
        $result["details"] = "A mentendő színek formátuma ismeretlen!";
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Szín beállító oldal</title>
        <script>
        function setColor(eloter)
        {
            if(eloter)
            {
                var color = document.getElementById("eloter").value;
                document.body.style.color = color;
            }
            else
            {
                var color = document.getElementById("hatter").value;
                document.body.style.backgroundColor = color;
            }
        }
        </script>
        <link href="style.php" rel="stylesheet" type="text/css">
    </head>
    <body>
        <?php
        if(isset($result) && is_array($result))
        {
            print("<p class=\"".($result["success"]?"success":"error")."\">{$result["details"]}</p>");
        }
        ?>
        <form method="post">
            <label for="eloter">Előtérszín</label>
            <input type="color" id="eloter" name="eloter" value="<?php print(isset($_SESSION["eloter"]) ? $_SESSION["eloter"] : "#000000"); ?>" onchange="setColor(true);"><br>
            <label for="hatter">Háttérszín</label>
            <input type="color" id="hatter" name="hatter" value="<?php print(isset($_SESSION["hatter"]) ? $_SESSION["hatter"] : "#ffffff"); ?>" onchange="setColor(false);"><br>
            <input type="submit" name="ok" value="Beállít">
        </form>
        <p>
            <a href="text.html" target="_blank">Lorem ipsum szöveg oldal</a>
        </p>
    </body>
</html>
