<?php
session_start();
header("Content-type: text/css");
?>
.success, .error
{
    font-weight: bold;
    font-size: 26pt;
}

.success
{
    color: green;
}

.error
{
    color: red;
}

body
{
    color: <?php print(isset($_SESSION["eloter"]) ? $_SESSION["eloter"] : "#000000"); ?>;
    background-color: <?php print(isset($_SESSION["hatter"]) ? $_SESSION["hatter"] : "#ffffff"); ?>;
}