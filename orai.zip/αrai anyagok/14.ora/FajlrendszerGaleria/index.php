<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        if(isset($_GET["gal"]))
        {
            $galeria = htmlspecialchars($_GET["gal"]);
            if(is_dir("galeriak/$galeria"))
            {
                $kepek = scandir("galeriak/$galeria");
                if(count($kepek) - 2 > 0)
                {
                    print("<table><tr>");
                    $i = 0;
                    foreach($kepek as $kep)
                    {
                        if($kep != "." && $kep != "..")
                        {
                            $i++;
                            print("<td><a href=\"galeriak/$galeria/$kep\" target=\"_blank\"><img width=\"150\" src=\"galeriak/$galeria/$kep\"></a></td>");
                            if($i % 3 == 0)
                            {
                                print("</tr><tr>");
                            }
                        }
                    }
                    print("</tr></table>");
                }
                else
                {
                    print("<h1>A galériában nem található kép!</h1>");
                }
            }
            else
            {
                print("<h1>Nem létező galéria!</h1>");
            }
        }
        else
        {
            print("<a href=\"upload.php\">Galéria létrehozás / képek feltöltése</a>");
            $galeriak = scandir("galeriak");
            if(count($galeriak) - 2 > 0)
            {
                print("<table><tr>");
                $i = 0;
                foreach($galeriak as $gal)
                {
                    if($gal != "." && $gal != "..")
                    {
                        $i++;
                        print("<td><a href=\"?gal=$gal\"><img width=\"150\" src=\"gallery.png\"><br>$gal</a></td>");
                        if($i % 3 == 0)
                        {
                            print("</tr><tr>");
                        }
                    }
                }
                print("</tr></table>");
            }
            else
            {
                print("<h1>Még nincs létrehozott galéria!</h1>");
            }
        }
        ?>
    </body>
</html>
