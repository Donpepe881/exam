<?php
if(isset($_POST["newgal"]))
{
    if(isset($_POST["galeria"]) && trim($_POST["galeria"]) != "")
    {
        $galeria = htmlspecialchars($_POST["galeria"]);
        if(!is_dir("galeria/$galeria"))
        {
            mkdir("galeriak/$galeria");
            $res["success"] = true;
            $res["info"] = "Sikeres galéria létrehozás!";
        }
        else
        {
            $res["success"] = false;
            $res["info"] = "Azonos nevű galéria már létezik!";
        }
    }
    else
    {
        $res["success"] = false;
        $res["info"] = "Nem érkezett galérianév!";
    }
}
if(isset($_POST["upload"]))
{
    if(isset($_FILES["kepek"]))
    {
        $fajlokSzama = count($_FILES["kepek"]["error"]);
        if($fajlokSzama > 0)
        {
            if(isset($_POST["galeria"]))
            {
                $galeria = htmlspecialchars($_POST["galeria"]);
                if(is_dir("galeriak/$galeria"))
                {
                    for($i = 0; $i < $fajlokSzama; $i++)
                    {
                        if($_FILES["kepek"]["error"][$i] == 0)
                        {
                            $mime = finfo_file(finfo_open(FILEINFO_MIME_TYPE), $_FILES["kepek"]["tmp_name"][$i]);
                            if($mime == "image/jpeg" || $mime == "image/png" || $mime == "image/webp")
                            {
                                move_uploaded_file($_FILES["kepek"]["tmp_name"][$i], "galeriak/$galeria/".basename($_FILES["kepek"]["name"][$i]));
                                if(file_exists("galeriak/$galeria/".basename($_FILES["kepek"]["name"][$i])))
                                {
                                    $res["files"][$i]["success"] = true;
                                    $res["files"][$i]["info"] = "A(z) ".basename($_FILES["kepek"]["name"][$i])." kép feltöltése sikeres!";
                                }
                                else
                                {
                                    $res["files"][$i]["success"] = false;
                                    $res["files"][$i]["info"] = "A(z) ".basename($_FILES["kepek"]["name"][$i])." kép feltöltése ismeretlen okból sikertelen!";
                                }
                            }
                            else
                            {
                                $res["files"][$i]["success"] = false;
                                $res["files"][$i]["info"] = "A(z) ".basename($_FILES["kepek"]["name"][$i])." kép nem megfelelő formátumú!";
                            }
                        }
                        else
                        {
                            $res["files"][$i]["success"] = false;
                            $res["files"][$i]["info"] = "A(z) ".basename($_FILES["kepek"]["name"][$i])." kép feltöltése meghiúsult!";
                        }
                    }
                }
                else
                {
                    $res["success"] = false;
                    $res["info"] = "Nem létező galéria!";
                }
            }
            else
            {
                $res["success"] = false;
                $res["info"] = "Nem érkezett galérianév!";
            }
        }
        else
        {
            $res["success"] = false;
            $res["info"] = "Nem érkezett egyetlen fájl sem!";
        }
    }
    else
    {
        $res["success"] = false;
        $res["info"] = "Nem került feltöltésre egyetlen fájl sem!";
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <style>
            .success, .error
            {
                font-weight: bold;
                font-size: 12pt;
            }
            
            .success
            {
                color: green;
            }
            
            .error
            {
                color: red;
            }
            </style>
    </head>
    <body>
        <?php
        if(isset($res))
        {
            if(isset($res["success"]))
            {
                print("<p class=\"".($res["success"]?"success":"error")."\">{$res["info"]}</p>");
            }
            elseif(is_array($res["files"]))
            {
                print("<ul>");
                foreach($res["files"] as $file)
                {
                    print("<li class=\"".($file["success"]?"success":"error")."\">{$file["info"]}</li>");
                }
                print("</ul>");
            }
        }
        ?>
        <h1>Új galéria létrehozása</h1>
        <form method="post">
            <label for="galeria">Galéria megnevezése:</label>
            <input type="text" name="galeria" id="galeria" placeholder="Galéria megnevezése" required><br>
            <input type="submit" name="newgal" value="Létrehoz">
        </form>
        <hr>
        <h1>Képek feltöltése galériába</h1>
        <form method="post" enctype="multipart/form-data">
            <label for="kepek">Képek:</label>
            <input type="file" name="kepek[]" id="kepek" accept="image/jpeg, image/png, image/webp" multiple><br>
            <label for="valasztott">Választott galeria:</label>
            <select name="galeria" id="valasztott">
                <?php
                $galeriak = scandir("galeriak");
                foreach($galeriak as $galeria)
                {
                    if(is_dir("galeriak/".$galeria) && $galeria != "." && $galeria != "..")
                    {
                        print("<option value=\"$galeria\">$galeria</option>");
                    }
                }
                ?>
            </select><br>
            <input type="submit" name="upload" value="Feltölt">
        </form>
    </body>
</html>
