<?php
$oldalak = array();
$menu = fopen("menu.txt", "r");
while(!feof(($menu)))
{
    $sor = explode(",", fgets($menu));
    $oldalak[] = array("nev"=>$sor[0], "param"=>$sor[1], "file"=>$sor[2], "show"=>$sor[3]);
}
fclose($menu);
//print_r($oldalak);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>HTML aloldalak fájlból</title>
    </head>
    <body>
        <section id="content">
            <header>
                <nav>
                    <ul>
                        <?php
                        /*$mappa = scandir("html");
                        foreach($mappa as $fajl)
                        {
                            if($fajl != "." && $fajl != "..")
                            {
                                $fajl = explode(".", $fajl);
                                print("<li><a href=\"?p={$fajl[0]}\">{$fajl[0]}</a></li>");
                            }
                        }*/
                     foreach ($oldalak as $oldal)
                     {
                         if($oldal["show"] == 1)
                         {
                             print("<li><a href=\"?p={$oldal["param"]}\">{$oldal["nev"]}</a></li>");
                         }
                     }
                        ?>
                    </ul>
                </nav>
            </header>
            <section>
                <?php
                /*if(isset($_GET["p"]))
                {
                    $page = htmlspecialchars($_GET["p"]);
                    if(file_exists("html/$page.html"))
                    {
                        print(file_get_contents("html/$page.html"));
                    }
                    else
                    {
                        print(file_get_contents("html/404.html"));
                    }
                }
                else
                {
                    print(file_get_contents("html/index.html"));
                }*/
                if(isset($_GET["p"]))
                {
                    $page = htmlspecialchars($_GET["p"]);
                    $talalt = false;
                    for($i = 0; $i < count($oldalak) && !$talalt; $i++)
                    {
                        if($oldalak[$i]["param"] == $page)
                        {
                            $talalt = true;
                        }
                    }
                    $i--;
                    if($talalt)
                    {
                        print(file_get_contents("html/{$oldalak[$i]["file"]}"));
                    }
                    else
                    {
                        print(file_get_contents("html/404.html"));
                    }
                }
                else
                {
                    print(file_get_contents("html/index.html"));
                }
                ?>
            </section>
            <footer>
                Készült 2023-ban...
            </footer>
        </section>
    </body>
</html>
