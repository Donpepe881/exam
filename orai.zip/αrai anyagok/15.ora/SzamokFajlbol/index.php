<?php
if(isset($_POST["ok"]))
{
    if(isset($_FILES["fajl"]) && $_FILES["fajl"]["error"] == 0)
    {
        $mime = finfo_file(finfo_open(FILEINFO_MIME_TYPE), $_FILES["fajl"]["tmp_name"]);
        if($mime == "text/plain")
        {
            if(file_exists("source.txt"))
            {
                unlink("source.txt");
            }
            move_uploaded_file($_FILES["fajl"]["tmp_name"], "source.txt");
            if(file_exists("source.txt"))
            {
                $sorok = file("source.txt");
                $osszeg = 0;
                $szorzat = 1;
                foreach ($sorok as $sor)
                {
                    $osszeg += floatval($sor);
                    $szorzat *= floatval($sor);
                }
                file_put_contents("result.txt", "A megadott számok összege: $osszeg\nA megadott számok szorzata: $szorzat");
                $result["success"] = true;
                $result["msg"] = "Sikeres feltöltés és feldolgozás!";
            }
            else
            {
                $result["success"] = false;
                $result["msg"] = "A feltöltés meghiúsult!";
            }
        }
        else
        {
            $result["success"] = false;
            $result["msg"] = "Nem szöveges fájl került feltöltésre!";
        }
    }
    else
    {
        $result["success"] = false;
        $result["msg"] = "Nem érkezett fájl, vagy a feltöltés megszakadt!";
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form method="post" enctype="multipart/form-data">
            <label for="fajl">Adja meg a számokkal feltöltött fájlt:</label>
            <input type="file" name="fajl" id="fajl" accept="text/plain"><br>
            <input type="submit" name="ok" value="Feltölt">
        </form>
        <hr>
        <?php
        if(isset($result))
        {
            print("<h2>{$result["msg"]}</h2>");
            if($result["success"])
            {
                print("<a href=\"result.txt\" download>Az eredmény letölétse</a>");
            }
        }
        ?>
    </body>
</html>
