<?php
if(isset($_GET["ok"]))
{
    if(isset($_GET["szoveg"]) && isset($_GET["funkcio"]) && trim($_GET["szoveg"]) != "" && trim($_GET["funkcio"]) != "")
    {
        $szoveg = htmlspecialchars($_GET["szoveg"]);
        $func = htmlspecialchars($_GET["funkcio"]);
        switch($func)
        {
            case "r":
                $result = strrev($szoveg);
                break;
            case "u":
                $result = strtoupper($szoveg);
                break;
            case "l":
                $result = strtolower($szoveg);
                break;
            case "e":
                if(isset($_GET["karakterek"]) && $_GET["karakterek"] != "")
                {
                    $result = explode($_GET["karakterek"], $szoveg);
                }
                else
                {
                    $result = "Hiányzó megadott karakterek!";
                }
                break;
            default:
                $result = "Ismeretlen funkció!";
                break;
        }
    }
    else
    {
        $result = "Hiányos adatok!";
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form>
            <label for="szoveg">Átalakítandó szöveg:</label>
            <input type="text" name="szoveg" id="szoveg" placeholder="Átalakítandó szöveg"><br>
            <label for="funkcio">Funkció:</label>
            <select name="funkcio" id="funkcio">
                <option value="r">Megfordítás</option>
                <option value="u">Nagybetűsítés</option>
                <option value="l">Kisbetűsítés</option>
                <option value="e">Bontás (megadott karakter(ek) alapján)</option>
            </select><br>
            <label for="karakterek">Megadott karakterek:</label>
            <input type="text" name="karakterek" id="karakterek" placeholder="Megadott karakterek"><br>
            <input type="submit" name="ok" value="Átalakít">
        </form>
        <?php
        if(isset($result))
        {
            if(!is_array($result))
            {
                print("<h2>$result</h2>");
            }
            else
            {
                print("<ul>");
                foreach($result as $item)
                {
                    print("<li>$item</li>");
                }
                print("</ul>");
            }
        }
        ?>
    </body>
</html>
