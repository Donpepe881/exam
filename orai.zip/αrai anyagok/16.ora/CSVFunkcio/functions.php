<?php
function CSVFeldolgzo(string $fajlnev, string $szeparator = ";", bool $fejlec = false) : array
{
    $result = array();
    $header = array();
    $i = 0;
    $csv = fopen($fajlnev, "r");
    while (!feof($csv))
    {
        if($i == 0 && $fejlec)
        {
            $header = fgetcsv($csv, null, $szeparator);
            $i++;
            continue;
        }
        $tmp = fgetcsv($csv, null, $szeparator);
        if(is_array($tmp))
        {
            if(count($header) > 0)
            {
                $assoc = array();
                for($j = 0; $j < count($header);$j++)
                {
                    $assoc[$header[$j]] = $tmp[$j];
                }
                $result[] = $assoc;
            }
            else
            {
                $result[] = $tmp;
            }
        }
    }
    fclose($csv);
    return $result;
}

function FajlFeltoltes(string $fajlkulcs, array $tipusok, string $fajlnev = "") : bool
{
    if(isset($_FILES[$fajlkulcs]) && $_FILES[$fajlkulcs]["error"] == 0)
    {
        $mime = finfo_file(finfo_open(FILEINFO_MIME_TYPE), $_FILES[$fajlkulcs]["tmp_name"]);
        if(in_array($mime, $tipusok))
        {
            $fajlneve = basename($_FILES[$fajlkulcs]["name"]);
            if($fajlnev != "" && !is_dir($fajlnev))
            {
                $fajlneve = $fajlnev;
            }
            elseif($fajlnev != "" && is_dir($fajlnev))
            {
                $fajlneve = $fajlnev."/".basename($_FILES[$fajlkulcs]["name"]); 
            }
            move_uploaded_file($_FILES[$fajlkulcs]["tmp_name"], $fajlneve);
            if(file_exists($fajlneve))
            {
                return true;
            }
        }
    }
    return false;
}
