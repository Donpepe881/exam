<?php
if(isset($_POST["ok"]))
{
    if(isset($_POST["user"]) && isset($_POST["pass"]) && trim($_POST["user"]) != "" && trim($_POST["pass"]) != "")
    {
        if(file_exists("users.csv"))
        {
            $file = fopen("users.csv", "r");
            $user = htmlspecialchars($_POST["user"]);
            $pass = hash("sha256", $_POST["pass"]);
            $result["success"] = false;
            while(!feof($file) && !$result["success"])
            {
                $csvSor = fgetcsv($file, null, ";"); //false lesz, ha az adott sor nem értelmezhető CSV formában
                //user;pass;target
                if(is_array($csvSor) && $user == trim($csvSor[0]) && $pass == trim($csvSor[1]))
                {
                    $result["success"] = true;
                    $result["targetUrl"] = trim($csvSor[2]);
                }
            }
            fclose($file);
            if($result["success"])
            {
                $result["info"] = "A belépés sikeres!";
            }
            else
            {
                $result["info"] = "Hibás felhasználónév és/vagy jelszó!";
            }
        }
        else
        {
            $result["success"] = false;
            $result["info"] = "Hiányzó beléptetési adatok! Rendszerhiba!";
        }
    }
    else
    {
        $result["success"] = false;
        $result["info"] = "Hiányzó belépési adatok!";
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>CSV beléptető</title>
        <style>
            .success
            {
                color: green;
            }
            
            .error
            {
                color: red;
            }
        </style>
    </head>
    <body>
        <?php
        if(isset($result))
        {
            if($result["success"])
            {
                print("<p class=\"success\">{$result["info"]}</p>");
                print("<script>window.setTimeout(function(){window.location.href = '{$result["targetUrl"]}';}, 3000);</script>");
            }
            else
            {
                print("<p class=\"error\">{$result["info"]}</p>");
            }
        }
        ?>
        <form method="post">
            <label for="user">Felhasználónév</label>
            <input type="text" name="user" id="user" placeholder="Felhasználónév"><br>
            <label for="pass">Jelszó</label>
            <input type="password" name="pass" id="pass" placeholder="Jelszó"><br>
            <input type="submit" name="ok" value="Belépés">
        </form>
    </body>
</html>
