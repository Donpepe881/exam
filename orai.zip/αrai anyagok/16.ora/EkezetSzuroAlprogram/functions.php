<?php
function EkezetTisztito(string $szoveg): string
{
    $ekezetek = "öüóőúéáűí";
    $csere = "ouooueaui";
    //$csere[0] --> ez egy karakter hivatkozás - azonban ez bájt hivatkozásként jelenik meg
    for($i = 0; $i < count(mb_str_split($ekezetek)); $i++)
    {
        $szoveg = str_replace(mb_str_split($ekezetek)[$i], mb_str_split($csere)[$i], $szoveg);
        $szoveg = str_replace(mb_strtoupper(mb_str_split($ekezetek)[$i]), mb_strtoupper(mb_str_split($csere)[$i]), $szoveg);
    }
    return $szoveg;
}

//print(EkezetTisztito("Általános"));