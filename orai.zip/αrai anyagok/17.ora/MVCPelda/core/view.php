<?php
function LoadTemplate(string $template, array $markers):string
{
    $data = file_get_contents("templates/".$template.".html");
    if(preg_match_all("/§[A-Z]+§/", $data, $matches))
    {
        foreach($matches[0] as $flag)
        {
            if(array_key_exists(trim(mb_substr($flag, 1, mb_strlen($flag) - 2)), $markers))
            {
                $data = str_replace($flag, $markers[trim(mb_substr($flag, 1, mb_strlen($flag) - 2))], $data);
            }
            else
            {
                $data = str_replace($flag, "", $data);
            }
        }
    }
    return $data;
}