<?php
function Faktorialis(int $hanyadik):int
{
    //return $hanyadik <= 1 ? 1 : $hanyadik * Faktorialis($hanyadik - 1);
    if($hanyadik <= 1)
    {
        return 1;
    }
    return $hanyadik * Faktorialis($hanyadik - 1);
}

function FaktorialisCiklus(int $hanyadik):int
{
    $eredmeny = 1;
    for(;$hanyadik >= 1; $hanyadik--)
    {
        $eredmeny *= $hanyadik;
    }
    return $eredmeny;
}

function Fibonacci(int $hanyadik):int
{
    if($hanyadik <= 2)
    {
        return 1;
    }
    return Fibonacci($hanyadik - 1) + Fibonacci($hanyadik - 2);
}

function FibonacciCiklus(int $hanyadik):int
{
    $elso = 1;
    $masodik = 1;
    $jelenlegi = 1;
    for($i = 3; $i <= $hanyadik; $i++)
    {
        $jelenlegi = $elso + $masodik;
        $elso = $masodik;
        $masodik = $jelenlegi;
    }
    return $jelenlegi;
}