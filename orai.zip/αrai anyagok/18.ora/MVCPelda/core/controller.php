<?php
function ParsePage():void
{
    $content = "";
    if(isset($_GET["page"]) && trim($_GET["page"]) != "")
    {
        $page = htmlspecialchars(trim($_GET["page"]));
        $menus = ReadCSV("menus", ";", false);
        $found = false;
        foreach($menus["data"] as $menu)
        {
            if(str_ends_with($menu[1], $page)) //Megvizsgáltuk, hogy egy amúgy létező oldalt keresnek-e
            {
                $content = call_user_func("Parse".ucfirst($page)); //pl.: ?page=gallery --> ParseGallery
                $found = true;
                break;
            }
        }
        if(!$found)
        {
            $content = LoadTemplate("404", array());
        }
    }
    else
    {
        $content = ParseIndex();
    }
    $result = LoadTemplate("index", array("MENU" => CreateMenu(), "FOOTER" => LoadTemplate("footer", array()), "TITLE" => "Első MVC oldalunk", "CONTENT" => $content));
    print($result);
}

function CreateMenu() : string
{
    $menus = ReadCSV("menus", ";", false);
    $result = "";
    foreach($menus["data"] as $menu)
    {
        $result .= LoadTemplate("menuitem", array("NAME" => $menu[0], "URL" => $menu[1]));
    }
    return LoadTemplate("menubase", array("MENUITEMS" => $result));
}

function ParseIndex() : string
{
    $content = ReadCSV("main", ";", false);
    $flags = array("TITLE" => "Főoldal");
    foreach($content["data"] as $data)
    {
        $flags[strtoupper($data[0])] = $data[1];
    }
    return LoadTemplate("main", $flags);
}

function ParseGallery() : string
{
    $images = ReadCSV("images", ";", false);
    $imgs = "";
    $rows = "";
    $counter = 0;
    foreach ($images["data"] as $img)
    {
        $imgs .= LoadTemplate("image", array("IMAGE" => "images/".$img[0], "TITLE" => $img[1], "WIDTH" => 250));
        $counter++;
        if($counter == 3)
        {
            $counter = 0;
            $rows .= LoadTemplate("imageRow", array("IMAGESTD" => $imgs));
            $imgs = "";
        }
    }
    if($imgs != "")
    {
        $rows .= LoadTemplate("imageRow", array("IMAGESTD" => $imgs));
    }
    return LoadTemplate("gallery", array("TITLE" => "Galéria", "IMAGEROWS" => $rows));
}

function ParseEnquiry() : string
{
    if(isset($_POST["ok"]))
    {
        if(isset($_POST["email"]) && isset($_POST["message"]))
        {
            if(filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL) && trim($_POST["message"]) != "")
            {
                $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
                $message = htmlspecialchars($_POST["message"]);
                WriteText("enquiry_".date("Y-m-d_H-i-s").".txt", "Egy új érdeklődés érkezett: $email\nAz üzenet: $message");
                $result["RESULTCLASS"] = "success";
                $result["RESULTTEXT"] = "Köszönjük érdeklődését! Érdeklődését mentettük!";
            }
            else
            {
                $result["RESULTCLASS"] = "failed";
                $result["RESULTTEXT"] = "Hiányzó adatok, vagy hibás email!";
            }
        }
        else
        {
            $result["RESULTCLASS"] = "failed";
            $result["RESULTTEXT"] = "Hiányzó adatok!";
        }
    }
    $result["TITLE"] = "Érdeklődés";
    return LoadTemplate("enquiry", $result);
}