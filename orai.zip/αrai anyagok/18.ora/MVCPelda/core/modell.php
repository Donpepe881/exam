<?php
function ReadCSV(string $name, string $separator, bool $header) : array
{
    $data = fopen("data/$name.csv", "r");
    $result = array();
    if($header)
    {
        $result["header"] = fgetcsv($data, null, $separator);
    }
    while (!feof($data))
    {
        $result["data"][] = fgetcsv($data, null, $separator);
    }
    fclose($data);
    return $result;
}

function WriteText(string $file, string $content) : bool
{
    file_put_contents("generated/$file", $content);
    return file_exists("generated/$file");
}