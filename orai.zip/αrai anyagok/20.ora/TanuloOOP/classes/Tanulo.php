<?php

class Tanulo
{
    private string $nev;
    private string $szemSzam;
    private float $atlag;
    
    public function getNev(): string
    {
        return $this->nev;
    }

    public function getSzemSzam(): string
    {
        return strtoupper($this->szemSzam);
    }

    public function getAtlag(): float
    {
        return round($this->atlag, 2);
    }

    public function setNev(string $nev): void
    {
        if(trim($nev) != "")
        {
            $this->nev = $nev;
        }
        else
        {
            //Hiba dobása...
            $this->nev = "HIBÁS!"; //Ez nem a legjobb megoldás, de most ezt fogjuk egy ideig alkalmazni
        }
    }

    public function setSzemSzam(string $szemSzam): void
    {
        if(preg_match("/[0-9]{6}[A-Z]{2}/", $szemSzam) != false)
        {
            $this->szemSzam = $szemSzam;
        }
        else
        {
            //Hiba dobása...
            $this->szemSzam = "HIBÁS!";
        }
    }

    public function setAtlag(float $atlag): void
    {
        if($atlag >= 1 && $atlag <= 5)
        {
            $this->atlag = $atlag;
        }
        else
        {
            //hiba dobása..
            $this->atlag = -1;
        }
    }
    
    public function __construct(string $nev, string $szemSzam, float $atlag)
    {
        $this->setNev($nev);
        $this->setSzemSzam($szemSzam);
        $this->setAtlag($atlag);
    }
    
    //Jelenleg ide nem jön alprogram, de ide jöhetne...
}
