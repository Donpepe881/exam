<?php

class TanuloEntity
{
    public function ReadFromCSV(string $filename) :  array
    {
        $file = fopen($filename, "r");
        $data = array();
        while(!feof($file))
        {
            $row = fgetcsv($file, null, ";");
            $data[] = new Tanulo($row[0], $row[1], floatval($row[2]));
        }
        fclose($file);
        return $data;
    }
}
