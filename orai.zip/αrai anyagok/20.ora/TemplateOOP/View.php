<?php

class View
{
    private Template $baseTemplate;
    
    public function getBaseTemplate(): Template
    {
        return $this->baseTemplate;
    }

    public function setBaseTemplate(Template $baseTemplate): void
    {
        $this->baseTemplate = $baseTemplate;
    }
    
    public function __construct(string $templateFilename)
    {
        $this->setBaseTemplate(new Template($templateFilename));
    }
    
    public function FinalRender() : void
    {
        print($this->baseTemplate->Render());
    }
}
