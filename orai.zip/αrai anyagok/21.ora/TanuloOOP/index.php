<?php
require_once("classes/Tanulo.php");
require_once("classes/TanuloEntity.php");
$entity = new TanuloEntity();
$tanulok = $entity->ReadFromCSV("tanulok.csv");
$atlag = Tanulo::TanulokAtlaga($tanulok);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <table>
            <thead>
                <tr>
                    <th>Név</th>
                    <th>Személyigazolvány szám</th>
                    <th>Átlag</th>
                </tr>
            </thead>
            <tbody>
                <?php
                  foreach($tanulok as $tanulo)
                  {
                      print("<tr><td>{$tanulo->getNev()}</td><td>{$tanulo->getSzemSzam()}</td><td>{$tanulo->getAtlag()}</td></tr>");
                  }
                ?>
            </tbody>
        </table>
        <p>A tanulók összesített átlaga: <?php print($atlag); ?></p>
    </body>
</html>
