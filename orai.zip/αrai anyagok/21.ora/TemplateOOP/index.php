<?php
require_once("classes/Template.php");
require_once("classes/View.php");
require_once("classes/Model.php");
require_once("classes/Controller.php");
$controller = new Controller();
$controller->Route();
$controller->getView()->FinalRender();