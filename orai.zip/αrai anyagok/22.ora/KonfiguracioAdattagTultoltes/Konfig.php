<?php

class Konfig
{
    private static Konfig $singleton;
    
    private array $konfig;
    
    private function __construct(string $konfigCSV)
    {
        $file = fopen($konfigCSV, "r");
        while (!feof($file))
        {
            $sor = fgetcsv($file, null, ";");
            if($sor != false)
            {
                $this->konfig[$sor[0]] = $sor[1];
            }
        }
        fclose($file);
    }
    
    public function __get($name)
    {
        if(array_key_exists($name, $this->konfig))
        {
            return $this->konfig[$name];
        }
    }
    
    public function __set($name, $value)
    {
        $this->konfig[$name] = $value;
    }
    
    public function __isset($name)
    {
        return array_key_exists($name, $this->konfig);
    }
    
    public function __unset($name)
    {
        if(array_key_exists($name, $this->konfig))
        {
            unset($this->konfig[$name]);
        }
    }
    
    public static function Singleton(string $konfigCSV = "konf.csv") : Konfig
    {
        if(!isset(self::$singleton))
        {
            self::$singleton = new Konfig($konfigCSV);
        }
        return self::$singleton;
    }
}
