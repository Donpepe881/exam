<?php
require_once("Konfig.php");
//$k = new Konfig("konf.csv");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        print("A 'verzio' konfig értéke: ".Konfig::Singleton()->verzio."<br>");
        Konfig::Singleton()->verzio = "v1.1";
        print("A 'verzio' konfig új értéke: ".Konfig::Singleton()->verzio."<br>");
        if(isset(Konfig::Singleton()->szam))
        {
            print("A 'szam' változó létezik! Az értéke: ".Konfig::Singleton()->szam."<br>");
        }
        else
        {
            print("A 'szam' változó nem létezik!<br>");
        }
        unset(Konfig::Singleton()->szam);
        if(isset(Konfig::Singleton()->szam))
        {
            print("A 'szam' változó még létezik! Az értéke: ".Konfig::Singleton()->szam."<br>");
        }
        else
        {
            print("A 'szam' változó már nem létezik!<br>");
        }
        if(isset(Konfig::Singleton()->ujszam))
        {
            print("A 'ujszam' változó még létezik! Az értéke: ".Konfig::Singleton()->ujszam."<br>");
        }
        else
        {
            print("A 'ujszam' változó már nem létezik!<br>");
        }
        Konfig::Singleton()->ujszam = 55;
        if(isset(Konfig::Singleton()->ujszam))
        {
            print("A 'ujszam' változó még létezik! Az értéke: ".Konfig::Singleton()->ujszam."<br>");
        }
        else
        {
            print("A 'ujszam' változó már nem létezik!<br>");
        }
        ?>
    </body>
</html>
