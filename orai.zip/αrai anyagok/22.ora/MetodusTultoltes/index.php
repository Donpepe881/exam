<?php
require_once("TeruletKerulet.php");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        print("Egy 5 cm oldalú négyzet kerülete: ".TeruletKerulet::Kerulet(5)."<br>");
        print("Egy 5 és 2 cm oldalú téglalap kerülete: ".TeruletKerulet::Kerulet(5, 2)."<br>");
        print("Egy 4-5-6 cm oldalú háromszög kerülete: ".TeruletKerulet::Kerulet(4,5,6)."<br>");
        print("Egy 5,0 cm sugarú kör kerülete: ".TeruletKerulet::Kerulet(5.0)."<br>");
        ?>
    </body>
</html>
