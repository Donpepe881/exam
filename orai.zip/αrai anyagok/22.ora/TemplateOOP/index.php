<?php
require_once("classes/Template.php");
require_once("classes/View.php");
require_once("classes/Model.php");
require_once("classes/Controller.php");
Controller::Init();
Controller::Route();
View::FinalRender();