<?php
class Feladat
{
    private string $cim, $leiras;
    private DateTime $datum;
    
    public function getCim(): string {
        return $this->cim;
    }

    public function getLeiras(): string {
        return $this->leiras;
    }

    public function getDatum(): DateTime {
        return $this->datum;
    }

    protected function setCim(string $cim): void {
        $this->cim = $cim;
    }

    protected function setLeiras(string $leiras): void {
        $this->leiras = $leiras;
    }

    protected function setDatum(DateTime $datum): void {
        $this->datum = $datum;
    }
    
    public function __construct(string $cim, string $leiras, DateTime $datum)
    {
        $this->setCim($cim);
        $this->setLeiras($leiras);
        $this->setDatum($datum);
    }
    
    public function __toString() //A szöveges formátumát adja meg egy objektumnak
    {
        return "Cím: {$this->cim} | Dátum: {$this->datum->format("Y-m-d H:i:s")} | Leirás: {$this->leiras}";
    }
    
    public function CSVFormatum(string $szeparator) : string
    {
        return "{$this->cim}$szeparator{$this->leiras}$szeparator{$this->datum->format("Y-m-d H:i:s")}";
    }
    
    public static function CSVFeldolgozas(string $csvSor, string $szeparator) : Feladat
    {
        $elemek = explode($szeparator, $csvSor);
        if(count($elemek) == 3)
        {
            return new Feladat($elemek[0], $elemek[1], DateTime::createFromFormat("Y-m-d H:i:s", trim($elemek[2])));
        }
        else
        {
            return new PeriodikusFeladat($elemek[0], $elemek[1], DateTime::createFromFormat("Y-m-d H:i:s", trim($elemek[2])), intval($elemek[3]));
        }
    }
}
