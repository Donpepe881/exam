<?php
class PeriodikusFeladat extends Feladat
{
    private int $periodusOra;
    
    public function getPeriodusOra(): int
    {
        return $this->periodusOra;
    }
    
    public function __construct(string $cim, string $leiras, DateTime $datum, int $periodusOra)
    {
        parent::__construct($cim, $leiras, $datum);
        $this->periodusOra = $periodusOra;
    }
    
    public function KovetkezoPeriodus() : DateTime
    {
        if(new DateTime("now") < $this->getDatum())
        {
            $kovetkezo = $this->getDatum()->add(new DateInterval("PT{$this->periodusOra}H"));
            return $kovetkezo;
        }
        return $this->getDatum();
    }
    
    public function __toString()
    {
        return parent::__toString()." | Periódus óra: {$this->periodusOra}";
    }
    
    public function CSVFormatum(string $szeparator): string
    {
        return parent::CSVFormatum($szeparator).$szeparator.$this->periodusOra;
    }
}
