<?php
require_once("classes/Feladat.php");
require_once("classes/PeriodikusFeladat.php");
?>
<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /*$feladat = new Feladat("Példa", "Példa leírás...", new DateTime("now"));
        print($feladat->CSVFormatum(";")."<br>");
        $pfeladat = new PeriodikusFeladat("Példa periodikus feladat", "Egy újabb példa leírás", new DateTime("2023-10-17 20:00:00"), 5);
        print($pfeladat->CSVFormatum(";")."<br>");
        print("A periódikus feladat következő időpontja: ".$pfeladat->KovetkezoPeriodus()->format("Y-m-d H:i:s"));*/
        $feladatok = array();
        /*$feladatok[] = new Feladat("Példa", "Példa leírás...", new DateTime("now"));
        $feladatok[] = new Feladat("Példa2", "Példa2 leírás...", new DateTime("2023-11-11 12:00:00")); 
        $feladatok[] = new PeriodikusFeladat("Periodikus Példa", "Példa period... leírás...", new DateTime("2023-12-11 12:00:00"), 4);
        $feladatok[] = new Feladat("Példa3", "Példa3 leírás...", new DateTime("2024-05-03 12:00:00")); 
        $feladatok[] = new PeriodikusFeladat("Periodikus Példa 2", "Példa period... leírás... 2", new DateTime("2023-12-15 12:00:00"), 9);
        $feladatok[] = new Feladat("Példa4", "Példa4 leírás...", new DateTime("2024-01-01 12:00:00")); 
        
        $file = fopen("feladatok.csv", "w");
        foreach($feladatok as $feladat)
        {
            fputs($file, $feladat->CSVFormatum(';')."\n");
        }
        fclose($file);*/
        
        $file = fopen("feladatok.csv", "r");
        while(!feof($file))
        {
            $sor = fgets($file);
            if(trim($sor) != "")
            {
                $feladatok[] = Feladat::CSVFeldolgozas($sor, ";");
            }
        }
        foreach($feladatok as $feladat)
        {
            print($feladat->__toString()."<br>");
        }
        ?>
    </body>
</html>
