<?php
abstract class GepAlkatresz
{
    private string $megnevezes, $szeriaszam;
    private int $ar, $szel, $hossz;
    
    public function getMegnevezes(): string {
        return $this->megnevezes;
    }

    public function getSzeriaszam(): string {
        return $this->szeriaszam;
    }

    public function getAr(): int {
        return $this->ar;
    }

    public function getSzel(): int {
        return $this->szel;
    }

    public function getHossz(): int {
        return $this->hossz;
    }

    protected function setMegnevezes(string $megnevezes): void
    {
        $this->megnevezes = $megnevezes;
    }

    protected function setSzeriaszam(string $szeriaszam): void
    {
        $this->szeriaszam = $szeriaszam;
    }

    public function setAr(int $ar): void
    {
        $this->ar = $ar;
    }

    protected function setSzel(int $szel): void
    {
        $this->szel = $szel;
    }

    protected function setHossz(int $hossz): void
    {
        $this->hossz = $hossz;
    }
    
    protected function __construct(string $megnevezes, string $szeriaszam, int $ar, int $szel, int $hossz)
    {
        $this->setMegnevezes($megnevezes);
        $this->setSzeriaszam($szeriaszam);
        $this->setAr($ar);
        $this->setSzel($szel);
        $this->setHossz($hossz);
    }
    
    public function __toString()
    {
        return "[{$this->szeriaszam}] - {$this->megnevezes}";
    }
    
    public abstract function AlapanyagAr() : int;
}
