<?php

interface ICSVMentheto
{
    function CSVFormatum(string $szeparator = ";") : string;
    function TombFormatum() : array;
}
