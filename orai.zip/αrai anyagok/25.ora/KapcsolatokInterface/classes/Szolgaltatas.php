<?php

class Szolgaltatas implements ICSVMentheto
{
    private string $megnevezes;
    private int $ar;
    
    public function getMegnevezes(): string {
        return $this->megnevezes;
    }

    public function getAr(): int {
        return $this->ar;
    }

    public function setMegnevezes(string $megnevezes): void {
        $this->megnevezes = $megnevezes;
    }

    public function setAr(int $ar): void {
        $this->ar = $ar;
    }

    public function __construct(string $megnevezes, int $ar)
    {
        $this->setMegnevezes($megnevezes);
        $this->setAr($ar);
    }
    
    public function __toString()
    {
        return $this->megnevezes." - ".$this->ar;
    }


    public function CSVFormatum(string $szeparator = ";"): string
    {
        return implode($szeparator, $this->TombFormatum());
    }

    public function TombFormatum(): array
    {
        return array($this->megnevezes, $this->ar);
    }
}
