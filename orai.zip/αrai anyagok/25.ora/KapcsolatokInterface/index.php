<?php
require_once("classes/ICSVMentheto.php");
require_once("classes/Kapcsolat.php");
require_once("classes/Szolgaltatas.php");

function CSVFormatumLekerdezese(ICSVMentheto $obj)
{
    print($obj->CSVFormatum()."<br>");
}

$objs = array();
$objs[] = new Kapcsolat("Gipsz Jakab", "Budapest", "jakab@ruander.hu", "06301236547");
$objs[] = new Kapcsolat("Matr Ica", "Kecskemét", "ica@ruander.hu", "06201236547");
$objs[] = new Szolgaltatas("Telefon", 5000);
$objs[] = new Kapcsolat("Kovács Géza", "Debrecen", "geza@ruander.hu", "06701236547");
$objs[] = new Szolgaltatas("Parkolás", 20000);
$objs[] = new Kapcsolat("Ács Éva", "Győr", "eva@ruander.hu", "06501236547");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        foreach($objs as $obj)
        {
            CSVFormatumLekerdezese($obj);
        }
        ?>
    </body>
</html>
