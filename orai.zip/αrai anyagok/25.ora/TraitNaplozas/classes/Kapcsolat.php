<?php

class Kapcsolat implements ICSVMentheto
{
    use Naplozas;
    
    private string $nev, $cim, $email, $telefon;
    
    public function getNev(): string {
        return $this->nev;
    }

    public function getCim(): string {
        return $this->cim;
    }

    public function getEmail(): string {
        return $this->email;
    }

    public function getTelefon(): string {
        return $this->telefon;
    }

    public function setNev(string $nev): void {
        $this->nev = $nev;
    }

    public function setCim(string $cim): void {
        $this->cim = $cim;
    }

    public function setEmail(string $email): void {
        $this->email = $email;
    }

    public function setTelefon(string $telefon): void {
        $this->telefon = $telefon;
    }

    public function __construct(string $nev, string $cim, string $email, string $telefon) {
        $this->setNev($nev);
        $this->setCim($cim);
        $this->setEmail($email);
        $this->setTelefon($telefon);
        $this->NaploIrasa("Létrejött egy új kapcsolat ({$nev})");
    }
    
    public function __toString()
    {
        return $this->nev;
    }
    
    public function CSVFormatum(string $szeparator = ";"): string
    {
        return implode($szeparator, $this->TombFormatum());
    }

    public function TombFormatum(): array
    {
        return array($this->nev, $this->cim, $this->email, $this->telefon);
    }
}
