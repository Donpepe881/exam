<?php

trait Naplozas
{
    public function NaploIrasa(string $naploSzovege) : void
    {
        $naplo = fopen("naplo.log", "a");
        fputs($naplo, "[".(new DateTime("now"))->format("Y-m-d H:i:s")."] - ".$naploSzovege."\n");
        fclose($naplo);
    }
}
