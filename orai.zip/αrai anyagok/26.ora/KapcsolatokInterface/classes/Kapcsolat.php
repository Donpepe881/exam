<?php

class Kapcsolat implements ICSVMentheto
{
    private string $nev, $cim, $email, $telefon;
    
    public function getNev(): string {
        return $this->nev;
    }

    public function getCim(): string {
        return $this->cim;
    }

    public function getEmail(): string {
        return $this->email;
    }

    public function getTelefon(): string {
        return $this->telefon;
    }

    public function setNev(string $nev): void
    {
        if(trim($nev) != "")
        {
            $this->nev = $nev;
        }
        else
        {
            throw new UnexpectedValueException("A név nem lehet üres!");
        }
    }

    public function setCim(string $cim): void 
    {
        if(trim($cim) != "")
        {
            $this->cim = $cim;
        }
        else
        {
            throw new UnexpectedValueException("A cím nem lehet üres!");
        }
    }

    public function setEmail(string $email): void
    {
        //if(preg_match("/\b[\w\.-]+@[\w\.-]+\.\w{2,4}\b/", $email) !== false)
        if(strpos($email,"@") !== false)
        {
            $this->email = $email;
        }
        else
        {
            throw new UnexpectedValueException("A megadott email cím formátuma nem megfelelő!");
        }
    }

    public function setTelefon(string $telefon): void 
    {
        if(trim($telefon) != "")
        {
            $this->telefon = $telefon;
        }
        else
        {
            throw new UnexpectedValueException("A telefon nem lehet üres!");
        }
    }

    public function __construct(string $nev, string $cim, string $email, string $telefon) {
        $this->setNev($nev);
        $this->setCim($cim);
        $this->setEmail($email);
        $this->setTelefon($telefon);
    }
    
    public function __toString()
    {
        return $this->nev;
    }
    
    public function CSVFormatum(string $szeparator = ";"): string
    {
        return implode($szeparator, $this->TombFormatum());
    }

    public function TombFormatum(): array
    {
        return array($this->nev, $this->cim, $this->email, $this->telefon);
    }
}
