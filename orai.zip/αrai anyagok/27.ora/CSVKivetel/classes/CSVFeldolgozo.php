<?php

abstract class CSVFeldolgozo
{
    public static function CSVBeolvasas(string $fajlnev, string $szep = ";", int $startSor = -1, int $startOszlop = -1, int $endSor = -1, $endOszlop = -1) : array
    {
        if(file_exists($fajlnev))
        {
            $csv = fopen($fajlnev, "r");
            if($csv != false)
            {
                $csvData = array();
                $sorPoz = 0;
                //$oszlopPoz = 0;
                while(!feof($csv) && ($endSor > -1 && $sorPoz <= $endSor || $endSor == -1))
                {
                    $sor = fgetcsv($csv, null, $szep);
                    if($sor != false)
                    {
                        if($startSor > -1 && $sorPoz >= $startSor || $startSor == -1)
                        {
                            //print(count($sor));
                            if(count($sor) > $endOszlop - $startOszlop)
                            {
                                if($endOszlop != -1 && $startOszlop != -1)
                                {
                                    $csvData[] = array_slice($sor, $startOszlop, $endOszlop - $startOszlop);
                                }
                                else
                                {
                                    $csvData[] = $sor;
                                }
                            }
                            else
                            {
                                throw new CSVFormatException("A megadott sorban nagyobb a kiolvasandó oszloptartomány, mint az oszlopok száma!", $fajlnev);
                            }
                        }
                    }
                    else
                    {
                        throw new CSVFormatException("A megadott fájlban értelmezhetetlen sor található!", $fajlnev);
                    }
                    $sorPoz++;
                }
                return $csvData;
            }
            else
            {
                throw new IOException($fajlnev, "A megadott fájl megnyitása sikertelen!");
            }
        }
        else
        {
            throw new FileNotFoundException($fajlnev, "A megadott fájl nem található!");
        }
    }
}
