<?php

class CSVFormatException extends Exception
{
    private string $csvFile;
    
    public function getCSVFile(): string
    {
        return $this->$csvFile;
    }

        
    public function __construct(string $message = "", string $file = "")
    {
        parent::__construct($message);
        $this->csvFile = $file;
    }
}
