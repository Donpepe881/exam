<?php

class IOException extends Exception
{
    private string $targetFile;
    
    public function getTargetFile(): string
    {
        return $this->$targetFile;
    }

        
    public function __construct(string $file, string $message = "")
    {
        parent::__construct($message);
        $this->targetFile = $file;
    }
}
