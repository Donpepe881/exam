<?php
require_once("classes/CSVFormatException.php");
require_once("classes/IOException.php");
require_once("classes/FileNotFoundException.php");
require_once("classes/CSVFeldolgozo.php");

try
{
    $csv = CSVFeldolgozo::CSVBeolvasas("otos.csv", ";", 10, 20, 10, 60);
}
catch(IOException $ex)
{
    //... --> minden IOException
}
catch(FileNotFoundException $ex)
{
    //... --> Csak a FileNotFoundException-öket kapnánk el, de ide már egy sem fog megérkezni, hiszen az IOException az őse, azokat meg már elkaptuk
}