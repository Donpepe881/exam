<?php

class Halmaz
{
    private array $data;
    
    public function getData(): array
    {
        return $this->data;
    }
    
    public function __construct()
    {
        $this->data = array();
    }
    
    public function Add(mixed $item)
    {
        if(!in_array($item, $this->data))
        {
            $this->data[]= $item;
        }
        else
        {
            throw new ItemDuplicationException($item);
        }
    }
}
