<?php

class ItemDuplicationException extends Exception
{
    private mixed $duplicated;
    
    public function getDuplicated(): mixed
    {
        return $this->duplicated;
    }
    
    public function __construct(mixed $duplicated)
    {
        $this->duplicated = $duplicated;
        parent::__construct("A megadott elem ({$duplicated}) már szerepel a halmazban!");
    }
}
