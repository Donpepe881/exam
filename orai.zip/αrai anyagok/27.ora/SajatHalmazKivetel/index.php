<?php
require_once ("classes/Halmaz.php");
require_once ("classes/ItemDuplicationException.php");

$halmaz = new Halmaz();
try {
    $halmaz->Add(2);
    $halmaz->Add(5);
    $halmaz->Add("Szia");
    $halmaz->Add(5);
    $halmaz->Add(6);
    $halmaz->Add(7);

} catch (ItemDuplicationException $ex) {
    print ($ex->getMessage() . " tehát a duplikált elem: " . $ex->getDuplicated() . "<br>");
}
print_r($halmaz->getData());