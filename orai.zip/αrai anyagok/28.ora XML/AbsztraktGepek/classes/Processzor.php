<?php

class Processzor extends GepAlkatresz
{
    private string $tokozas, $archi;
    private float $orajel;
    
    public function getTokozas(): string {
        return $this->tokozas;
    }

    public function getArchi(): string {
        return $this->archi;
    }

    public function getOrajel(): float {
        return $this->orajel;
    }

    private function setTokozas(string $tokozas): void
    {
        $this->tokozas = $tokozas;
    }

    private function setArchi(string $archi): void
    {
        $this->archi = $archi;
    }

    private function setOrajel(float $orajel): void
    {
        $this->orajel = $orajel;
    }

    public function __construct(string $megnevezes, string $szeriaszam, int $ar, int $szel, int $hossz, string $tokozas, string $archi, float $orajel)
    {
        parent::__construct($megnevezes, $szeriaszam, $ar, $szel, $hossz);
        $this->setTokozas($tokozas);
        $this->setArchi($archi);
        $this->setOrajel($orajel);
    }
    
    public function AlapanyagAr(): int
    {
        //20g / cm2 --> a szél / hossz cm-ben megadva és feltétlezve, hogy 4000 ft. egy gramm alapanyag / nemesfém
        return $this->getSzel() * $this->getHossz() * 20 * 4000;
    }
    
    public function ToXML(): SimpleXMLElement
    {
        $xml = parent::ToXML();
        $procXML = $xml->addChild("Processzor");
        $procXML->addAttribute("tokozas", $this->tokozas);
        $procXML->addAttribute("architektura", $this->archi);
        $procXML->addAttribute("orajel", $this->orajel);
        return $xml;
    }
    
    public function AttachToXMLDocument(\SimpleXMLElement $xmldoc): SimpleXMLElement
    {
        $xml = parent::AttachToXMLDocument($xmldoc);
        $procXML = $xml->addChild("Processzor");
        $procXML->addAttribute("tokozas", $this->tokozas);
        $procXML->addAttribute("architektura", $this->archi);
        $procXML->addAttribute("orajel", $this->orajel);
        return $xml;
    }
}
