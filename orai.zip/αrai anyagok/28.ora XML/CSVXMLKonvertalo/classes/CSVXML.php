<?php
abstract class CSVXML
{
    public static function CSVKonvertalas(string $fajlnev, string $szeparator = ";") : SimpleXMLElement
    {
        if(file_exists($fajlnev))
        {
            $csv = fopen($fajlnev, "r");
            if($csv != false)
            {
                $fejlec = fgetcsv($csv, null, $szeparator);
                for($i = 0; $i < count($fejlec); $i++)
                {
                    $fejlec[$i] = trim($fejlec[$i]);
                    $fejlec[$i] = preg_replace("/[^a-zA-Z0-9]+/", "", $fejlec[$i]);
                }
                if($fejlec != false)
                {
                    $xml = new SimpleXMLElement("<CSVData></CSVData>");
                    while (!feof($csv))
                    {
                        $sor = fgetcsv($csv, null, $szeparator);
                        if($sor === false)
                        {
                            continue;
                        }
                        $xmlElem = $xml->addChild("Row");
                        for($i = 0; $i < count($fejlec) && $i < count($sor); $i++)
                        {
                            $xmlElem->addChild($fejlec[$i], $sor[$i]);
                        }
                    }
                    fclose($csv);
                    return $xml;
                }
                else
                {
                    throw new MissingHeaderException();
                }
            }
            else
            {
                throw new IOException("A megadott fájl megnyitása sikertelen!");
            }
        }
        else
        {
            throw new IOException("A megadott fájl nem található!");
        }
    }
}
