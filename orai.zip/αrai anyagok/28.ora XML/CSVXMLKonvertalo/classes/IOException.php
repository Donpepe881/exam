<?php

class IOException extends Exception
{
    public function __construct(string $message)
    {
        parent::__construct("Fájl műveleti hiba történt! ".$message);
    }
}
