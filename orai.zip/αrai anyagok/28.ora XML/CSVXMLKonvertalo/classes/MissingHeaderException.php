<?php

class MissingHeaderException extends Exception
{
    /*private string $missingHeader;
    
    public function getMissingHeader(): string
    {
        return $this->missingHeader;
    }*/
    
    public function __construct()
    {
        parent::__construct("Hiányzó fejléc információ! A dokumentumban nincs fejléc!");
    }
}
