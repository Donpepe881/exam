<?php 
require_once("classes/IOException.php");
require_once("classes/MissingHeaderException.php");
require_once("classes/CSVXML.php");
if(isset($_POST["ok"]))
{
    if(isset($_FILES["csv"]) && $_FILES["csv"]["error"] == 0)
    {
        $mime = finfo_file(finfo_open(FILEINFO_MIME_TYPE), $_FILES["csv"]["tmp_name"]);
        if($mime == "text/plain" || $mime == "text/csv")
        {
            move_uploaded_file($_FILES["csv"]["tmp_name"], "convert.csv");
            try
            {
                $xml = CSVXML::CSVKonvertalas("convert.csv");
                $result["file"] = hash("sha256", $_FILES["csv"]["name"]).".xml";
                $xml->asXML($result["file"]);
            }
            catch (Exception $ex)
            {
                $result["error"] = $ex->getMessage();
            }
        }
        else
        {
            $result["error"] = "Nem megengedett formátumú fájl!";
        }
    }
    else
    {
        $result["error"] = "Nem érkezett fájl!";
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <p><?php
            if(isset($result))
            {
                if(array_key_exists("file", $result))
                {
                    print("<a href=\"{$result["file"]}\" download>Eredmény letöltése</a>");
                }
                else
                {
                    print($result["error"]);
                }
            }
        ?></p>
        <form method="post" enctype="multipart/form-data">
            <label for="csv">CSV fájl</label>
            <input type="file" name="csv" id="csv" accept="text/plain, text/csv"><br>
            <input type="submit" name="ok" value="Feltölt">
        </form>
    </body>
</html>
