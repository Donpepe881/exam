<?php 
$szamokDb = array();
$xml = simplexml_load_file("otos.xml");
foreach($xml->children() as $tr)
{
    $td = $tr->td;
    if($td->count() > 0)
    {
        $i = 0;
        foreach($tr->children() as $cella)
        {
            if($i >= 11 && $i <= 15)
            {
                //print($cella." ");
                if(!array_key_exists($cella->__toString(), $szamokDb))
                {
                    $szamokDb[(string)$cella] = 1;
                }
                else
                {
                    $szamokDb[(string)$cella]++;
                }
            }
            $i++;
        }
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <ul>
        <?php
        ksort($szamokDb);
        $eredmenyXML = new SimpleXMLElement("<Result></Result>");
        foreach ($szamokDb as $szam=>$db)
        {
            print("<li>A(z) {$szam} - {$db} szor/szer volt kihúzva!</li>");
            $szamElem = $eredmenyXML->addChild("Szam", $db);
            $szamElem->addAttribute("szam", $szam);
            //$szamElem->addAttribute("darab", $db);
        }
        $eredmenyXML->asXML("result.xml");
        ?>
        </ul>
    </body>
</html>
