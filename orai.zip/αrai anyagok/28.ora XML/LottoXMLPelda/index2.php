<?php
$szamokDb = array();
$xml = simplexml_load_file("otos.xml");
foreach($xml->children() as $tr)
{
    $td = $tr->td;
    if($td->count() > 0)
    {
        $i = 0;
        foreach($tr->children() as $cella)
        {
            if($i >= 11 && $i <= 15)
            {
                //print($cella." ");
                if(!array_key_exists($cella->__toString(), $szamokDb))
                {
                    $szamokDb[(string)$cella] = 1;
                }
                else
                {
                    $szamokDb[(string)$cella]++;
                }
            }
            $i++;
        }
    }
}
ksort($szamokDb);
$eredmenyXML = new SimpleXMLElement("<Result></Result>");
foreach ($szamokDb as $szam=>$db)
{
    $szamElem = $eredmenyXML->addChild("Szam", $db);
    $szamElem->addAttribute("szam", $szam);
    //$szamElem->addAttribute("darab", $db);
}
header("Content-type: text/xml");
print($eredmenyXML->asXML());