<?php

class Alaplap extends GepAlkatresz
{
    private string $chipset;
    private MemoriaTipus $memoriaTipus;
    
    public function getChipset(): string
    {
        return $this->chipset;
    }

    public function getMemoriaTipus(): MemoriaTipus 
    {
        return $this->memoriaTipus;
    }

    private function setChipset(string $chipset): void 
    {
        $this->chipset = $chipset;
    }

    private function setMemoriaTipus(MemoriaTipus $memoriaTipus): void
    {
        $this->memoriaTipus = $memoriaTipus;
    }

    public function __construct(string $megnevezes, string $szeriaszam, int $ar, int $szel, int $hossz, string $chipset, MemoriaTipus $memoriaTipus)
    {
        parent::__construct($megnevezes, $szeriaszam, $ar, $szel, $hossz);
        $this->setChipset($chipset);
        $this->setMemoriaTipus($memoriaTipus);
    }

    public function AlapanyagAr(): int
    {
        //10g / cm2 --> a szél / hossz cm-ben megadva és feltétlezve, hogy 2000 ft. egy gramm alapanyag / nemesfém
        return $this->getSzel() * $this->getHossz() * 10 * 2000;
    }
    
    public function ToXML(): SimpleXMLElement
    {
        $xml = parent::ToXML();
        $alapXml = $xml->addChild("Alaplap");
        $alapXml->addAttribute("tipus", $this->memoriaTipus->value);
        $alapXml->addAttribute("chipset", $this->chipset);
        return $xml;
    }
    
    public function AttachToXMLDocument(\SimpleXMLElement $xmldoc): SimpleXMLElement
    {
        $xml = parent::AttachToXMLDocument($xmldoc);
        $alapXml = $xml->addChild("Alaplap");
        $alapXml->addAttribute("tipus", $this->memoriaTipus->value);
        $alapXml->addAttribute("chipset", $this->chipset);
        return $xml;
    }
    
    public function jsonSerialize(): mixed
    {
        $parent = parent::jsonSerialize();
        $parent["gepAlkatresz"] = "alaplap";
        $parent["tipus"] = $this->memoriaTipus->value;
        $parent["chipset"] = $this->chipset;
        return $parent;
    }
}
