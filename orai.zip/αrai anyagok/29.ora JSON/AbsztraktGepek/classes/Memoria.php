<?php

class Memoria extends GepAlkatresz
{
    private MemoriaTipus $tipus;
    private float $frekvencia;
    private int $kesleltetes;
    
    public function getTipus(): MemoriaTipus {
        return $this->tipus;
    }

    public function getFrekvencia(): float {
        return $this->frekvencia;
    }

    public function getKesleltetes(): int {
        return $this->kesleltetes;
    }

    private function setTipus(MemoriaTipus $tipus): void 
    {
        $this->tipus = $tipus;
    }

    private function setFrekvencia(float $frekvencia): void 
    {
        $this->frekvencia = $frekvencia;
    }

    private function setKesleltetes(int $kesleltetes): void 
    {
        if($kesleltetes >= 1 && $kesleltetes <= 40)
        {
            $this->kesleltetes = $kesleltetes;
        }
        else
        {
            //hiba dobása...
            $this->kesleltetes = -1;
        }
    }

    public function __construct(string $megnevezes, string $szeriaszam, int $ar, int $szel, int $hossz, MemoriaTipus $tipus, float $frekvencia, int $kesleltetes)
    {
        parent::__construct($megnevezes, $szeriaszam, $ar, $szel, $hossz);
        $this->setTipus($tipus);
        $this->setFrekvencia($frekvencia);
        $this->setKesleltetes($kesleltetes);
    }

    
    public function AlapanyagAr(): int
    {
        //15g / cm2 --> a szél / hossz cm-ben megadva és feltétlezve, hogy 3000 ft. egy gramm alapanyag / nemesfém
        return $this->getSzel() * $this->getHossz() * 15 * 3000;
    }
    
    public function ToXML(): SimpleXMLElement
    {
        $xml = parent::ToXML();
        $memXML = $xml->addChild("Memoria");
        $memXML->addAttribute("tipus", $this->tipus->value);
        $memXML->addAttribute("frekvencia", $this->frekvencia);
        $memXML->addAttribute("kesleltetes", $this->kesleltetes);
        return $xml;
    }
    
    public function AttachToXMLDocument(\SimpleXMLElement $xmldoc): SimpleXMLElement
    {
        $xml = parent::AttachToXMLDocument($xmldoc);
        $memXML = $xml->addChild("Memoria");
        $memXML->addAttribute("tipus", $this->tipus->value);
        $memXML->addAttribute("frekvencia", $this->frekvencia);
        $memXML->addAttribute("kesleltetes", $this->kesleltetes);
        return $xml;
    }
    
    public function jsonSerialize(): mixed
    {
        $parent = parent::jsonSerialize();
        $parent["gepAlkatresz"] = "memória";
        $parent["tipus"] = $this->tipus->value;
        $parent["frekvencia"] = $this->frekvencia;
        $parent["kesleltetes"] = $this->kesleltetes;
        return $parent;
    }
}
