<?php
require_once("classes/GepAlkatresz.php");
require_once("classes/MemoriaTipus.php");
require_once("classes/Alaplap.php");
require_once("classes/Processzor.php");
require_once("classes/Memoria.php");

function ArEsAlapanyagAr(GepAlkatresz $alkatresz)
{
    print("A(z) {$alkatresz->__toString()} alkatrész ára: ".$alkatresz->getAr().", az alapanyag ára: ".$alkatresz->AlapanyagAr());
}

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $xml = new SimpleXMLElement("<Alkatreszek></Alkatreszek>");
        $alkatreszek = array();
        $alkatreszek[] = new Alaplap("ASUS", "A001", 45000, 24, 28, "INTEL", MemoriaTipus::DDR4);
        $alkatreszek[] = new Processzor("AMD", "P001", 75000, 4, 4, "PGA", "Zen2", 4200);
        $alkatreszek[] = new Memoria("HyperX", "M001", 30000, 12, 4, MemoriaTipus::DDR5, 4600, 28);
        
        /*foreach($alkatreszek as $alk)
        {
            $alk->AttachToXMLDocument($xml);
        }
        $xml->asXML("alkatreszek.xml");*/
        
        /*$jsonArray = array("alkatreszek" => array());
        foreach($alkatreszek as $alk)
        {
            $jsonArray["alkatreszek"][] = $alk->jsonSerialize();
        }
        file_put_contents("alkatreszek.json", json_encode($jsonArray["alkatreszek"]));*/
        
        $data = json_decode(file_get_contents("alkatreszek.json"), true);
        $objects = array();
        foreach($data as $obj)
        {
            $objects[] = GepAlkatresz::DeserializeJson($obj);
        }
        print_r($objects);
        ?>
    </body>
</html>
