<?php

class Osztaly implements JsonSerializable
{
    private string $a;
    private int $b;

    public function getA(): string
    {
        return $this->a;
    }

    public function getB(): int
    {
        return $this->b;
    }

    public function __construct()
    {
        $this->a = "Helló";
        $this->b = 10;
    }

    public function jsonSerialize(): mixed
    {
        return array("a" => $this->a, "b" => $this->b);
    }
}

$tomb = array(1, 2, 3);
$atomb = array("A" => 1, "B" => 2, "C" => 3);
$obj = new Osztaly();

print (json_encode($obj));
