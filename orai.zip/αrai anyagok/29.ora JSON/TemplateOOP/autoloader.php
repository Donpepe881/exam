<?php
/*function LoadClass(string $classname)
{
    file_put_contents("autload_log.txt", "A PHP most keresi a $classname osztályt...\n", FILE_APPEND);
    if(file_exists("classes/$classname.php"))
    {
        require_once("classes/$classname.php");
        file_put_contents("autload_log.txt", "A fájlt megtaláltuk és betöltöttük...\n", FILE_APPEND);
    }
}
spl_autoload_register("LoadClass");*/

spl_autoload_register(function(string $classname)
{
    if(file_exists("classes/$classname.php"))
    {
        require_once("classes/$classname.php");
    }
});
