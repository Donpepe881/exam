<?php
function GetNoImg() : GdImage
{
    $nopic = imagecreatetruecolor(300, 300);
    imagefill($nopic, 0, 0, imagecolorallocate($nopic, 255, 255, 255));
    $red = imagecolorallocate($nopic, 255, 0, 0);
    $line = imagecreatetruecolor(350, 5);
    imagefill($line, 0, 0, $red);
    $elso = imagerotate($line, 135, imagecolorallocatealpha($nopic, 255, 255, 255, 127));
    $masodik = imagerotate($line, 45, imagecolorallocatealpha($nopic, 255, 255, 255, 127));
    imagecopy($nopic, $elso , 25, 20, 0, 0, imagesx($elso), imagesy($elso));
    imagecopy($nopic, $masodik , 25, 20, 0, 0, imagesx($masodik), imagesy($masodik));
    return $nopic;
}

if(isset($_GET["imgkey"]))
{
    $key = htmlspecialchars($_GET["imgkey"]);
    $kepek = json_decode(file_get_contents("kepek.json"), true);
    if(array_key_exists($key, $kepek))
    {
        if(file_exists($kepek[$key]))
        {
            $mime = finfo_file(finfo_open(FILEINFO_MIME_TYPE), $kepek[$key]);
            switch ($mime)
            {
                case "image/jpeg":
                    $kep = imagecreatefromjpeg($kepek[$key]);
                    header("Content-type: image/jpeg");
                    imagejpeg($kep);
                    break;
                case "image/png":
                    $kep = imagecreatefrompng($kepek[$key]);
                    header("Content-type: image/png");
                    imagepng($kep);
                    break;
                default :
                    $kep = GetNoImg();
                    header("Content-type: image/png");
                    imagepng($kep);
            }
        }
        else
        {
            $kep = GetNoImg();
            header("Content-type: image/png");
            imagepng($kep);
        }
    }
    else
    {
        $kep = GetNoImg();
        header("Content-type: image/png");
        imagepng($kep);
    }
}
else
{
    $kep = GetNoImg();
    header("Content-type: image/png");
    imagepng($kep);
}