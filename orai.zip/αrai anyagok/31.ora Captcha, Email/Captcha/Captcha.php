<?php

class Captcha
{
    private string $szoveg;
    
    public function getSzoveg(): string
    {
        return $this->szoveg;
    }
    
    public function __construct()
    {
        $this->GenerateString();
    }
    
    public function GenerateString() : void
    {
        $this->szoveg = "";
        for($i = 0; $i < 6; $i++)
        {
            switch(rand(1,3))
            {
                case 1:
                    $this->szoveg .= chr(rand(48,57));
                    break;
                case 2:
                    $this->szoveg .= chr(rand(65,90));
                    break;
                case 3:
                    $this->szoveg .= chr(rand(97,122));
                    break;
            }
        }
    }
    
    public function GetCaptcha() : GdImage
    {
        $vaszon = imagecreatetruecolor(strlen($this->szoveg)*75, 100);
        imagefill($vaszon, 0, 0, imagecolorallocate($vaszon, rand(0, 127), rand(0, 127), rand(0, 127)));
        $i = 0;
        foreach(str_split($this->szoveg) as $kar)
        {
            imagettftext($vaszon, rand(18, 36), rand(-30, 30), $i * 70 + 30, rand(30,70), imagecolorallocate($vaszon, rand(128, 255), rand(128, 255), rand(128, 255)), rand(1, 3).".ttf", $kar);
            $i++;
        }
        for($i = 0; $i < 7; $i++)
        {
            switch(rand(1,3))
            {
                case 1:
                    imageline($vaszon, rand(0, imagesx($vaszon) / 4), rand(0, imagesy($vaszon)), rand(imagesx($vaszon) / 2, imagesx($vaszon)), rand(0, imagesy($vaszon)), imagecolorallocate($vaszon, rand(128, 255), rand(128, 255), rand(128, 255)));
                    break;
                case 2:
                    imagerectangle($vaszon, rand(0, imagesx($vaszon) / 4), rand(0, imagesy($vaszon)), rand(imagesx($vaszon) / 2, imagesx($vaszon)), rand(0, imagesy($vaszon)), imagecolorallocate($vaszon, rand(128, 255), rand(128, 255), rand(128, 255)));
                    break;
                case 3:
                    imageellipse($vaszon, rand(imagesx($vaszon) / 4, imagesx($vaszon) / 4 + imagesx($vaszon) / 2), rand(imagesy($vaszon) / 4, imagesy($vaszon) / 4 + imagesy($vaszon) / 2), rand(10, 100), rand(10, 100), imagecolorallocate($vaszon, rand(128, 255), rand(128, 255), rand(128, 255)));
                    break;
            }
        }
        return $vaszon;
    }
}
