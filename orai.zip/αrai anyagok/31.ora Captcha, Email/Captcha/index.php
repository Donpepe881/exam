<?php
session_start();
header("Content-type: image/png");
require_once("Captcha.php");
$captcha = new Captcha();
$_SESSION["captcha"] = $captcha->getSzoveg();
imagepng($captcha->GetCaptcha());