<?php
session_start();
if(isset($_POST["ok"]))
{
    if(isset($_SESSION["captcha"]))
    {
        $captcha = $_SESSION["captcha"];
        $userCaptcha = htmlspecialchars($_POST["captcha"]);
        if(strtolower($captcha) == trim(strtolower($userCaptcha)))
        {
            $result = "Jó a captcha!";
        }
        else
        {
            $result = "Nem jó a captcha!";
        }
    }
    else
    {
        $result = "Nincs captcha!";
    }
    //beléptetés...
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Captcha login alap</title>
    </head>
    <body>
        <?php
        if(isset($result))
        {
            print("<h2>$result</h2>");
        }
        ?>
        <form method="post">
            <label for="user">Felhasználónév</label>
            <input type="text" name="user" id="user" placeholder="Felhasználónév"><br>
            <label for="pass">Jelszó</label>
            <input type="password" name="pass" id="pass" placeholder="Jelszó"><br>
            <img id="captcha" src="index.php" alt="captcha" title="captcha"><br>
            <a href="#" onclick="document.getElementById('captcha').src = 'index.php';">Frissítés</a><br>
            <label for="captchastr">Ide írja a képen látható karaktereket:</label>
            <input type="text" name="captcha" id="captchastr" placeholder="Captcha"><br>
            <input type="submit" name="ok" value="Belépés">
        </form>
    </body>
</html>
