<?php
spl_autoload_register(function(string $name)
{
    $name = substr($name, strrpos($name, "\\")+1);
    //print($name);
    if(file_exists("PHPMailer/$name.php"))
    {
        require_once("PHPMailer/$name.php");
    }
});