<?php
require_once("autloader.php");
if (isset($_POST["ok"])) {
    if (filter_input(INPUT_POST, "sender", FILTER_VALIDATE_EMAIL) && filter_input(INPUT_POST, "target", FILTER_VALIDATE_EMAIL) && isset($_POST["subject"]) && trim($_POST["subject"]) != "" && isset($_POST["body"]) && trim($_POST["body"]) != "") {
        $sender = filter_input(INPUT_POST, "sender", FILTER_SANITIZE_EMAIL);
        $target = filter_input(INPUT_POST, "target", FILTER_SANITIZE_EMAIL);
        $subject = htmlspecialchars($_POST["subject"]);
        $body = htmlspecialchars($_POST["body"]);
        /*if(mail($target, $subject, $body, array("From" => $sender)))
        {
            $result = "A levél sikeresen átadva az SMTP szervernek!";
        }
        else
        {
            $result = "A levél kiküldése sikertelen!";
        }*/
        $mailer = new PHPMailer\PHPMailer\PHPMailer(true);
        $mailer->setFrom($sender);
        $mailer->addAddress($target);
        $mailer->Subject = $subject;
        $mailer->Body = $body;
        $mailer->CharSet = "utf-8";
        $mailer->send();
    } else {
        $result = "Hiányzó adatok!";
    }
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title></title>
</head>

<body>
    <?php
    if (isset($result)) {
        print("<h2>$result</h2>");
    }
    ?>
    <form method="post">
        <label for="sender">Küldő:</label>
        <input type="email" name="sender" id="sender" placeholder="Küldő email címe"><br>
        <label for="target">Címzett:</label>
        <input type="email" name="target" id="target" placeholder="Címzett email címe"><br>
        <label for="subject">Tárgy:</label>
        <input type="text" name="subject" id="subject" placeholder="Levél tárgya"><br>
        <label for="body">Üzenet:</label>
        <textarea name="body" id="body" placeholder="A levél törzse"></textarea><br>
        <input type="submit" name="ok" value="Küldés">
    </form>
</body>

</html>