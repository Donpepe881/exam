<?php
mail("kis.balazs@ruander.hu", "Ez egy teszt levél", "Ez a levél törzse...");

