<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        
        <?php
        $driver = new mysqli_driver();
        $driver->report_mode = MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT;
        $con = new mysqli("localhost", "php", "123456aA", "deptemp");
        /*$result = $con->query("SELECT *, IF(`sal` > 2000, 'red', 'black') AS `szin` FROM `emp` ORDER BY `ename`");
        //print($result->num_rows);
        //print_r($result->fetch_all(MYSQLI_ASSOC));
        while($row = $result->fetch_assoc())
        {
            print("<h2 style=\"color:{$row["szin"]};\">{$row["ename"]}, {$row["job"]}</h2>");
        }*/
        /*$result = $con->query("SELECT AVG(`sal`) AS `atlagkereset` FROM `emp`");
        $avg = $result->fetch_array()[0];
        print("Az átlag kereset: $avg\$");*/
        $num = $con->query("INSERT INTO `emp` VALUES (9000, '".$con->real_escape_string("JAKAB")."', 'IT', NULL, '".(date("Y-m-d"))."', 2000, NULL, 40)");
        //print("$num rows affected<br>");
        print("<table>");
        $result = $con->query("SELECT * FROM `emp` INNER JOIN `dept` ON `emp`.`deptno` = `dept`.`deptno`");
        if($result->num_rows > 0)
        {
            $header = false;
            while($row = $result->fetch_assoc())
            {
                if(!$header)
                {
                    print("<tr>");
                    foreach(array_keys($row) as $col)
                    {
                        print("<th>$col</th>");
                    }
                    print("</tr>");
                    $header = true;
                }
                print("<tr>");
                foreach($row as $colVal)
                {
                    if(is_null($colVal))
                    {
                        $colVal = "NULL";
                    }
                    print("<td>$colVal</td>");
                }
                print("</tr>");
            }
        }
        $result->free();
        $con->close();
        ?>
        </table>
    </body>
</html>
