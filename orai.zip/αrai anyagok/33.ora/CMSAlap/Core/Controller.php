<?php

abstract class Controller
{
    public static function Router() : void
    {
        global $conf;
        $page = $conf["controller"]["defaultPage"];
        if(isset($_GET[$conf["controller"]["pageParam"]]) && trim($_GET[$conf["controller"]["pageParam"]]) != "")
        {
            $page = htmlspecialchars($_GET[$conf["controller"]["pageParam"]]);
        }
        //Ez az oldal létezik?
        $pageData = Model::IsExistingPage($page);
        if($pageData !== false)
        {
            
        }
    }
}
