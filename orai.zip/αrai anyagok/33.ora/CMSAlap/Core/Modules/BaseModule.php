<?php
abstract class BaseModule
{
    public abstract function Run(mixed $input) : void;
}
