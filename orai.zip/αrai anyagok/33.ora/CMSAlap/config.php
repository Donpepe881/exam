<?php
$conf = array();
//AB beállítások
$conf["db"]["host"] = "localhost";
$conf["db"]["user"] = "php";
$conf["db"]["pass"] = "123456aA";
$conf["db"]["db"] = "deptemp";
$conf["db"]["port"] = "3306";
$conf["db"]["driverConfig"] = MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT;
//Általános beállítások
$conf["controller"]["pageParam"] = "p";
$conf["controller"]["defaultPage"] = "index";