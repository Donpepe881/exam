<?php
abstract class ABKezelo
{
    private static mysqli $con;
    private static mysqli_driver $driver;
    
    public static function Connect()
    {
        global $conf;
        try
        {
            self::$driver = new mysqli_driver();
            self::$driver->report_mode = $conf["db"]["driverConfig"];
            self::$con = new mysqli($conf["db"]["host"], $conf["db"]["user"], $conf["db"]["pass"], $conf["db"]["db"], $conf["db"]["port"]);
        }
        catch(Exception $ex)
        {
            throw new ABKivetel("Az adatbázis csatlakozás sikertelen!", $ex);
        }
    }
    
    public static function Disconnect()
    {
        try
        {
            self::$con->close();
        }
        catch (Exception $ex)
        {
            throw new ABKivetel("Az adatbázis kapcsolat bontása sikertelen!", $ex);
        }
    }
    
    public static function InsertNewEmp(array $empData)
    {
        try
        {
            $prep = self::$con->prepare("INSERT INTO `emp` VALUES (?,?,?,?,?,?,?,?)");
            $prep->bind_param("issisddi", $empData["empno"], $empData["ename"], $empData["job"], $empData["mgr"], $empData["hiredate"], $empData["sal"], $empData["comm"], $empData["deptno"]);
            $prep->execute();
        }
        catch (Exception $ex)
        {
            throw new ABKivetel("A munkavállaló beszúrása sikertelen!", $ex);
        }
    }
    
    public static function InsertNewDept(array $deptData)
    {
        try
        {
            $colList = "`".implode("`,`", array_keys($deptData))."`";
            $valList = "";
            foreach ($deptData as $value)
            {
                if(is_string($value))
                {
                    $valList .= "'".self::$con->real_escape_string($value)."',";
                }
                else
                {
                    $valList .= self::$con->real_escape_string($value).",";
                }
            }
            $valList = substr($valList, 0, -1);
            self::$con->query("INSERT INTO `dept`($colList) VALUES ($valList)");
        }
        catch (Exception $ex)
        {
            throw new ABKivetel("A telephely beszúrása sikertelen!", $ex);
        }
    }
    
    public static function GetEmpDept(int $from = 0, int $count = 0)
    {
        try
        {
            $limit = "";
            if($from > 0)
            {
                $limit = "LIMIT $from";
                if($count > 0)
                {
                    $limit .= ", $count";
                }
            }
            $res = self::$con->query("SELECT * FROM `emp` INNER JOIN `dept` ON `emp`.`deptno` = `dept`.`deptno` $limit");
            $data = $res->fetch_all(MYSQLI_ASSOC);
            $res->free();
            return $data;
        } 
        catch (Exception $ex)
        {
            throw new ABKivetel("Az adatok beolvasása sikertelen!", $ex);
        }
    }
    
    public static function GetEmps(array $columns, int $from = 0, int $count = 0)
    {
        try
        {
            $limit = "";
            if($from > 0)
            {
                $limit = "LIMIT $from";
                if($count > 0)
                {
                    $limit .= ", $count";
                }
            }
            $cols = "*";
            if(count($columns) > 0)
            {
                $cols = "`".implode("`,`", $columns)."`";
            }
            $res = self::$con->query("SELECT $cols FROM `emp` $limit");
            $data = $res->fetch_all(MYSQLI_ASSOC);
            $res->free();
            return $data;
        } 
        catch (Exception $ex)
        {
            throw new ABKivetel("Az adatok beolvasása sikertelen!", $ex);
        }
    }
    
    public static function GetDepts(array $columns, int $from = 0, int $count = 0)
    {
        try
        {
            $limit = "";
            if($from > 0)
            {
                $limit = "LIMIT $from";
                if($count > 0)
                {
                    $limit .= ", $count";
                }
            }
            $cols = "*";
            if(count($columns) > 0)
            {
                $cols = "`".implode("`,`", $columns)."`";
            }
            $res = self::$con->query("SELECT $cols FROM `dept` $limit");
            $data = $res->fetch_all(MYSQLI_ASSOC);
            $res->free();
            return $data;
        } 
        catch (Exception $ex)
        {
            throw new ABKivetel("Az adatok beolvasása sikertelen!", $ex);
        }
    }
}
