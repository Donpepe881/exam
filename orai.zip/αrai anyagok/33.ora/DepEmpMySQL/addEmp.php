<?php
require_once("connect.php");
if(isset($_POST["ok"]))
{
    $keys = array("empno", "ename", "job", "mgr", "hiredate", "sal", "comm", "deptno");
    $input = array();
    $ok = true;
    foreach($keys as $key)
    {
        if(isset($_POST[$key]) && trim($_POST[$key]) != "")
        {
            $input[$key] = htmlspecialchars(trim($_POST[$key]));
        }
        else
        {
            $ok = false;
            break;
        }
    }
    if($ok)
    {
        try
        {
            ABKezelo::InsertNewEmp($input);
            $result = "Sikeres rögzítés";
        }
        catch (ABKivetel $ex)
        {
            $result = $ex->getMessage();
        }
    }
    else
    {
        $result = "Minden mező kitöltése kötelező!";
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        if(isset($result))
        {
            print("<h2>$result</h2>");
        }
        ?>
        <form method="post">
            <label for="empno">EMPNO</label>
            <input type="number" name="empno" id="empno" placeholder="EMPNO"><br>
            <label for="ename">ENAME</label>
            <input type="text" name="ename" id="ename" placeholder="ENAME"><br>
            <label for="job">JOB</label>
            <input type="text" name="job" id="job" placeholder="JOB"><br>
            <label for="mgr">MGR</label>
            <select name="mgr" id="mgr">
                <option value="null">Nincs főnöke</option>
                <?php
                $emps = ABKezelo::GetEmps(array("empno", "ename"));
                foreach($emps as $emp)
                {
                    print("<option value=\"{$emp["empno"]}\">{$emp["ename"]}</option>");
                }
                ?>
            </select><br>
            <label for="hiredate">HIREDATE</label>
            <input type="date" name="hiredate" id="hiredate" placeholder="HIREDATE"><br>
            <label for="sal">SAL</label>
            <input type="number" name="sal" id="sal" placeholder="SAL"><br>
            <label for="comm">COMM</label>
            <input type="number" name="comm" id="comm" placeholder="COMM"><br>
            <label for="deptno">DEPT</label>
            <select name="deptno" id="deptno">
                <option value="null">Nincs telephelyhelyhez rendelve</option>
                <?php
                $emps = ABKezelo::GetDepts(array("deptno", "dname"));
                foreach($emps as $emp)
                {
                    print("<option value=\"{$emp["deptno"]}\">{$emp["dname"]}</option>");
                }
                ?>
            </select><br>
            <input type="submit" name="ok" value="Beszúr">
        </form>
    </body>
</html>
