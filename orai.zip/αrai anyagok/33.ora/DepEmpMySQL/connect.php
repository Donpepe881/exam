<?php
require_once("config.php");
require_once("ABKivetel.php");
require_once("ABKezelo.php");
ABKezelo::Connect();