<?php
require_once("connect.php");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <table>
        <?php
        $dataTable = ABKezelo::GetEmpDept();
        if(count($dataTable) > 0)
        {
            $header = false;
            foreach($dataTable as $row)
            {
                if(!$header)
                {
                    print("<tr>");
                    foreach(array_keys($row) as $col)
                    {
                        print("<th>$col</th>");
                    }
                    print("</tr>");
                    $header = true;
                }
                print("<tr>");
                foreach($row as $colVal)
                {
                    if(is_null($colVal))
                    {
                        $colVal = "NULL";
                    }
                    print("<td>$colVal</td>");
                }
                print("</tr>");
            }
        }
        ?>
        </table>
    </body>
</html>
