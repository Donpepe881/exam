<?php
require_once("config.php");
require_once("ABKivetel.php");
require_once("ABKezelo.php");

ABKezelo::Connect();
//ABKezelo::InsertNewEmp(array("empno" => 9001, "ename" => "JAKAB", "job" => 'IT', "mgr" => NULL, "hiredate" => date("Y-m-d"), "sal" => 2000, "comm" => NULL, "deptno" => 40));
ABKezelo::InsertNewDept(array("deptno" => 50, "dname" => "T'ech"));
