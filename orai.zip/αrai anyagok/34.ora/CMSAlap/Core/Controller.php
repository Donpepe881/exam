<?php

abstract class Controller
{
    public static function Router() : void
    {
        global $conf;
        $page = $conf["controller"]["defaultPage"];
        if(isset($_GET[$conf["controller"]["pageParam"]]) && trim($_GET[$conf["controller"]["pageParam"]]) != "")
        {
            $page = htmlspecialchars($_GET[$conf["controller"]["pageParam"]]);
        }
        //Ez az oldal létezik?
        $pageData = Model::IsExistingPage($page);
        if($pageData !== false)
        {
            //Ez egy aloldal? --> Ha nem, akkor önmagában feldolgozandó, de ha igen, akkor ennek van egy kerete, amit meg kell keressünk.
            //Rekurzív visszavezetés
            //print_r($pageData);
            if($pageData["parent"] != null)
            {
               $parentTemplate = self::LoadParent($pageData["parent"]);
            }
            $pageTemplate = Template::Load($pageData["template"]);
            self::RunPage($pageData, $pageTemplate);
            if(isset($parentTemplate))
            {
                $parentTemplate->AddData($conf["controller"]["subpageMarker"], $pageTemplate);
            }
            else
            {
                //TODO: Tisztázni!!!
                View::Init($conf["controller"]["defaultPage"].".html");
                View::setBaseTemplate($pageTemplate);
            }
        }
    }
    
    private static function LoadParent(int $parentID) : Template
    {
        global $conf;
        $parentInfo = Model::GetPageById($parentID);
        if($parentInfo !== false)
        {
            $template = Template::Load($parentInfo["template"]);
            if($parentInfo["parent"] == null)
            {
                //TODO: Tisztázni!!!
                View::Init($conf["controller"]["defaultPage"].".html");
                View::setBaseTemplate($template);
            }
            else
            {
                $parentTemplate = self::LoadParent($parentInfo["parent"]);
                /*while(count($parentTemplate->{$conf["controller"]["subpageMarker"]}) > 0)
                {
                    $parentTemplate = $parentTemplate->{$conf["controller"]["subpageMarker"]}[0];
                }*/
                $parentTemplate->AddData($conf["controller"]["subpageMarker"], $template);
            }
            self::RunPage($parentInfo, $template);
            return $template;
        }
        else
        {
            throw new Exception("Az oldal hierarchia felépítése megszakadt!");
        }
    }
    
    private static function RunPage(array $pageInfo, Template $pageTemplate) : void
    {
        $modulesToLoad = Model::GetPageModules($pageInfo["id"]);
        foreach($modulesToLoad as $moduleData)
        {
            if(class_exists($moduleData["moduleName"]) && is_subclass_of($moduleData["moduleName"], "BaseModule"))
            {
                if($moduleData["stringParameter"] != null)
                {
                    $module = new $moduleData["moduleName"]($moduleData["stringParameter"]);
                }
                else
                {
                    $module = new $moduleData["moduleName"]();
                }
                $module->Run();
                if(is_subclass_of($moduleData["moduleName"], "BaseModuleVisual"))
                {
                    $pageTemplate->AddData($moduleData["flagToInsert"], $module->Render());
                }
            }
            else
            {
                //TODO: jelenteni, hogy a modul betöltése sikertelen!
            }
        }
    }
}
