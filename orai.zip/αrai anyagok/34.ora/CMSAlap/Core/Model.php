<?php
abstract class Model
{
    private static mysqli $con;
    private static mysqli_driver $driver;
    
    public static function Connect()
    {
        global $conf;
        try
        {
            self::$driver = new mysqli_driver();
            self::$driver->report_mode = $conf["db"]["driverConfig"];
            self::$con = new mysqli($conf["db"]["host"], $conf["db"]["user"], $conf["db"]["pass"], $conf["db"]["db"], $conf["db"]["port"]);
        } 
        catch (Exception $ex) 
        {
            throw new DBException("Sikertelen adatbázis csatlakozás!", $ex);
        }
    }
    
    public static function Close()
    {
        try
        {
            self::$con->close();
        }
        catch (Exception $ex)
        {
            throw new DBException("Sikertelen adatbázis kapcsolatbontás!", $ex);
        }
    }
    
    public static function IsExistingPage(string $pageName) : bool|array
    {
        try
        {
            $result = self::$con->query("SELECT * FROM `pages` WHERE `paramName` = '".self::$con->real_escape_string($pageName)."'");
            if($result->num_rows > 0)
            {
                $pageData = $result->fetch_all(MYSQLI_ASSOC)[0];
                $result->free();
                return $pageData;
            }
            $result->free();
            return false;
        }
        catch (Exception $ex)
        {
            throw new DBException("Sikertelen oldal ellenőrzés!", $ex);
        }
    }
    
    public static function GetPageById(int $pageID) : bool|array
    {
        try
        {
            $result = self::$con->query("SELECT * FROM `pages` WHERE `id` = $pageID");
            if($result->num_rows > 0)
            {
                $pageData = $result->fetch_all(MYSQLI_ASSOC)[0];
                $result->free();
                return $pageData;
            }
            $result->free();
            return false;
        }
        catch (Exception $ex)
        {
            throw new DBException("Sikertelen oldal lekérdezés!", $ex);
        }
    }
    
    public static function GetPageModules(int $pageID) : array
    {
        try
        {
            $result = self::$con->query("SELECT * FROM `pagemodules` INNER JOIN `modules` ON `pagemodules`.`moduleId` = `modules`.`id` WHERE `pageId` = $pageID");
            $pageData = $result->fetch_all(MYSQLI_ASSOC);
            $result->free();
            return $pageData;
        }
        catch (Exception $ex)
        {
            throw new DBException("Sikertelen modul lista lekérdezés!", $ex);
        }
    }
    
    public static function GetContent(string $key) : bool|array
    {
        try
        {
            $result = self::$con->query("SELECT * FROM `contentprinter_data` WHERE `key` = '".self::$con->real_escape_string($key)."'");
            if($result->num_rows > 0)
            {
                $content = $result->fetch_all(MYSQLI_ASSOC)[0];
                $result->free();
                return $content;
            }
            $result->free();
            return false;
        }
        catch (Exception $ex)
        {
            throw new DBException("Sikertelen tartalom betöltés!", $ex);
        }
    }
}
