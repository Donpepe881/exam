<?php
abstract class BaseModule
{
    public abstract function Run() : void;
}
