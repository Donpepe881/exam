<?php

abstract class BaseModuleVisual extends BaseModule
{
    protected Template $template;

    public abstract function Render(): Template;
}
