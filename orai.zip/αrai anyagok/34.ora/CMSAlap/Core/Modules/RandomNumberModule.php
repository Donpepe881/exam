<?php
class RandomNumberModule extends BaseModuleVisual
{
    private int $num;
    
    public function __construct()
    {
        $this->template = Template::Parse("<h3>§NUM§</h3>");
    }
    
    public function Render(): \Template
    {
        $this->template->AddData("NUM", (string)$this->num);
        return $this->template;
    }

    public function Run(): void
    {
        $this->num = rand(-1000, 1000);
    }
}
