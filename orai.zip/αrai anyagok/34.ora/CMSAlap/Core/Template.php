<?php

class Template
{
    private string $html, $rendered;
    private array $flagsData;
    private bool $modified;
    
    public function getFlags() : array
    {
        return array_keys($this->flagsData);
    }
    
    public function getModified(): bool
    {
        return $this->modified;
    }

    //A private construct eltakarja a láthatlan konstruktort, ugyanakkor kívülről nem elérhető, így nem lehet példányosítani az osztályt
    private function __construct()
    {
        
    }
    
    private function LoadTemplateFile(string $filename) : void
    {
        $this->modified = true;
        $this->rendered = "";
        $this->html = file_get_contents("Templates/".$filename);
        $this->SearchForFlags();
    }
    
    private function SearchForFlags() : void
    {
        $this->flagsData = array();
        if(preg_match_all("/§[A-Z]+§/", $this->html, $matches) !== false)
        {
            foreach ($matches[0] as $flag)
            {
                $this->flagsData[mb_substr($flag, 1, mb_strlen($flag) - 2)] = array();
            }
        }
    }
    
    public function AddData(string $flag, string|Template $data) : bool
    {
        if(array_key_exists($flag, $this->flagsData))
        {
            $this->flagsData[$flag][] = $data;
            $this->modified = true;
            return true;
        }
        return false;
    }
    
    public function InsertData(string $flag, int $num, string|Template $data) : bool
    {
        if(array_key_exists($flag, $this->flagsData))
        {
            if($num >= 0 && $num < count($this->flagsData[$flag]))
            {
                for($i = count($this->flagsData[$flag]) - 1; $i >= $num; $i--)
                {
                    $this->flagsData[$flag][$i+1] = $this->flagsData[$flag][$i];
                }
                $this->flagsData[$flag][$num] = $data;
            }
            else
            {
                $this->flagsData[$flag][] = $data;
            }
            $this->modified = true;
            return true;
        }
        return false;
    }
    
    public function DeleteData(string $flag): bool
    {
        if(array_key_exists($flag, $this->flagsData))
        {
            $this->flagsData[$flag] = array();
            $this->modified = true;
            return true;
        }
        return false;
    }
    
    public function DeleteExactData(string $flag, int $num)
    {
        if(array_key_exists($flag, $this->flagsData) && $num < count($this->flagsData[$flag]))
        {
            unset($this->flagsData[$flag][$num]);
            $this->modified = true;
            return true;
        }
        return false;
    }
    
    public function Render() : string
    {
        if($this->modified)
        {
            $this->rendered = $this->html;
            foreach ($this->flagsData as $flag=>$datas)
            {
                //$this->rendered = str_replace("§{$flag}§", implode("", $datas), $this->rendered);
                $content = "";
                foreach($datas as $data)
                {
                    if(is_a($data, "Template"))
                    {
                        $content .= $data->Render();
                    }
                    else
                    {
                        $content .= $data;
                    }
                }
                $this->rendered = str_replace("§{$flag}§", $content, $this->rendered);
            }
            $this->modified = false;
        }
        return $this->rendered;
    }
    
    public function __get($name)
    {
        if(array_key_exists($name, $this->flagsData))
        {
            return $this->flagsData[$name];
        }
    }
    
    public function __set($name, $value)
    {
        if(array_key_exists($name, $this->flagsData))
        {
            $this->flagsData[$name][] = $value;
        }
    }
    
    public function __isset($name)
    {
        return array_key_exists($name, $this->flagsData) && count($this->flagsData[$name]) > 0;
    }
    
    public function __unset($name)
    {
        if(array_key_exists($name, $this->flagsData))
        {
            $this->flagsData[$name] = array();
        }
    }


    public static function Load(string $filename) : Template
    {
        $template = new Template();
        $template->LoadTemplateFile($filename);
        return $template;
    }
    
    public static function Parse(string $templateString) : Template
    {
        $template = new Template();
        $template->html = $templateString;
        $template->modified = true;
        $template->rendered = "";
        $template->SearchForFlags();
        return $template;
    }
}
