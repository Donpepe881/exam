<?php
spl_autoload_register(function (string $name)
{
    if(strpos($name, "Exception") && file_exists("Core/Exceptions/$name.php"))
    {
        require_once("Core/Exceptions/$name.php");
    }
    elseif(strpos($name, "Module") && file_exists("Core/Modules/$name.php"))
    {
        require_once("Core/Modules/$name.php");
    }
    elseif(file_exists("Core/$name.php"))
    {
        require_once("Core/$name.php");
    }
});