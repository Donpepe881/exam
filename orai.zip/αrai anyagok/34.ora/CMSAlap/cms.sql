-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2023. Nov 28. 20:13
-- Kiszolgáló verziója: 10.4.28-MariaDB
-- PHP verzió: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `cms`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `contentprinter_data`
--

CREATE TABLE `contentprinter_data` (
  `key` varchar(64) NOT NULL,
  `content` text NOT NULL,
  `template` varchar(128) DEFAULT NULL,
  `flag` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `contentprinter_data`
--

INSERT INTO `contentprinter_data` (`key`, `content`, `template`, `flag`) VALUES
('INDEX_FOOTER', 'Minden jog fenntartva! 2023', 'footer.html', 'JOG'),
('INDEX_TITLE_KEY', 'Főoldal Másik', NULL, NULL);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `modules`
--

CREATE TABLE `modules` (
  `id` int(11) NOT NULL,
  `moduleName` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `modules`
--

INSERT INTO `modules` (`id`, `moduleName`) VALUES
(1, 'RandomNumberModule'),
(2, 'ContentPrinterModule');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pagemodules`
--

CREATE TABLE `pagemodules` (
  `id` int(11) NOT NULL,
  `moduleId` int(11) NOT NULL,
  `pageId` int(11) NOT NULL,
  `stringParameter` varchar(256) DEFAULT NULL,
  `flagToInsert` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `pagemodules`
--

INSERT INTO `pagemodules` (`id`, `moduleId`, `pageId`, `stringParameter`, `flagToInsert`) VALUES
(1, 1, 1, NULL, 'RANDOM'),
(2, 1, 3, NULL, 'RNUM'),
(3, 1, 4, NULL, 'RANDOM'),
(4, 2, 1, 'INDEX_TITLE_KEY', 'INDEXTITLE'),
(5, 2, 1, 'INDEX_FOOTER', 'FOOTER');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `paramName` varchar(128) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `template` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `pages`
--

INSERT INTO `pages` (`id`, `paramName`, `parent`, `enabled`, `template`) VALUES
(1, 'index', NULL, 1, 'index.html'),
(2, 'admin', NULL, 1, 'admin.html'),
(3, 'about', 1, 1, 'about.html'),
(4, 'teszt', 3, 1, 'teszt.html');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `contentprinter_data`
--
ALTER TABLE `contentprinter_data`
  ADD PRIMARY KEY (`key`);

--
-- A tábla indexei `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `pagemodules`
--
ALTER TABLE `pagemodules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pagemodules_page_FK` (`pageId`),
  ADD KEY `pagemodules_modules_FK` (`moduleId`);

--
-- A tábla indexei `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `paramName` (`paramName`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `modules`
--
ALTER TABLE `modules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `pagemodules`
--
ALTER TABLE `pagemodules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT a táblához `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `pagemodules`
--
ALTER TABLE `pagemodules`
  ADD CONSTRAINT `pagemodules_modules_FK` FOREIGN KEY (`moduleId`) REFERENCES `modules` (`id`),
  ADD CONSTRAINT `pagemodules_page_FK` FOREIGN KEY (`pageId`) REFERENCES `pages` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
