<?php

abstract class Controller
{
    public static function Router() : void
    {
        try
        {
            PermissionHandler::Init();
            global $conf;
            $page = $conf["controller"]["defaultPage"];
            if(isset($_GET[$conf["controller"]["pageParam"]]) && trim($_GET[$conf["controller"]["pageParam"]]) != "")
            {
                $page = htmlspecialchars($_GET[$conf["controller"]["pageParam"]]);
            }
            //Ez az oldal létezik?
            $pageData = Model::IsExistingPage($page);
            if($pageData !== false)
            {
                $allow = false;
                if($pageData["permission"] != null)
                {
                    if($pageData["permission"] == PermissionHandler::getGuestId() || PermissionHandler::IsUserLoggedIn())
                    {
                        if($pageData["permission"] == PermissionHandler::getGuestId() && PermissionHandler::IsUserLoggedIn())
                        {
                            Logger::LogUser("A felhasználó egy olyan oldalt próbált elérni, amihez nincs joga!", LogLevel::Warning);
                        }
                        elseif($pageData["permission"] == PermissionHandler::getGuestId())
                        {
                            $allow = true;
                        }
                        else
                        {
                            $allow = PermissionHandler::CheckRights(PermissionHandler::GetUserData()[$conf["permission"]["SessionUserPermissionId"]], $pageData["permission"]);
                        }
                    }
                    else
                    {
                        Logger::LogUser("A felhasználó egy olyan oldalt próbált elérni, amihez nincs joga!", LogLevel::Warning);
                    }
                }
                else
                {
                    $allow = true;
                }
                if($allow)
                {
                    //Ez egy aloldal? --> Ha nem, akkor önmagában feldolgozandó, de ha igen, akkor ennek van egy kerete, amit meg kell keressünk.
                    //Rekurzív visszavezetés
                    if($pageData["parent"] != null)
                    {
                       $parentTemplate = self::LoadParent($pageData["parent"]);
                    }
                    $pageTemplate = Template::Load($pageData["template"]);
                    self::RunPage($pageData, $pageTemplate);
                    if(isset($parentTemplate))
                    {
                        $parentTemplate->AddData($conf["controller"]["subpageMarker"], $pageTemplate);
                    }
                    else
                    {
                        View::Init($pageTemplate);
                    }
                }
                else
                {
                    //1. lehetőség
                    View::ReportFatalError("A megadott oldal megtekintéséhez nincs joga!");
                    //2. lehetőség
                    //View::Init($conf["controller"]["defaultPage"]);
                    //View::getBaseTemplate()->AddData("ERROR", "A megadott oldal megtekintéséhez nincs joga!");
                    //3. lehetőség
                    //header("Location: index.php"); //Itt még tudni kellene majd az index-en, hogy miért jöttünk ide, mert így csak odakerülünk - nem lesz hibaüzenet.
                }
            }
        }
        catch (Exception $ex)
        {
            Logger::LogGeneral("Az oldal betöltése sikertelen!", LogLevel::Error, LogReportLevel::Fatal, $ex);
        }
    }
    
    private static function LoadParent(int $parentID) : Template
    {
        global $conf;
        $parentInfo = Model::GetPageById($parentID);
        if($parentInfo !== false)
        {
            $template = Template::Load($parentInfo["template"]);
            if($parentInfo["parent"] == null)
            {
                View::Init($template);
            }
            else
            {
                $parentTemplate = self::LoadParent($parentInfo["parent"]);
                /*while(count($parentTemplate->{$conf["controller"]["subpageMarker"]}) > 0)
                {
                    $parentTemplate = $parentTemplate->{$conf["controller"]["subpageMarker"]}[0];
                }*/
                $parentTemplate->AddData($conf["controller"]["subpageMarker"], $template);
            }
            self::RunPage($parentInfo, $template);
            return $template;
        }
        else
        {
            throw new Exception("Az oldal hierarchia felépítése megszakadt!");
        }
    }
    
    private static function RunPage(array $pageInfo, Template $pageTemplate) : void
    {
        $modulesToLoad = Model::GetPageModules($pageInfo["id"]);
        foreach($modulesToLoad as $moduleData)
        {
            if(class_exists($moduleData["moduleName"]) && is_subclass_of($moduleData["moduleName"], "BaseModule"))
            {
                if($moduleData["stringParameter"] != null)
                {
                    $module = new $moduleData["moduleName"]($moduleData["stringParameter"]);
                }
                else
                {
                    $module = new $moduleData["moduleName"]();
                }
                $module->Run();
                if(is_subclass_of($moduleData["moduleName"], "BaseModuleVisual"))
                {
                    $pageTemplate->AddData($moduleData["flagToInsert"], $module->Render());
                }
            }
            else
            {
                throw new ModuleLoadFailedException("A megadott modul ({$moduleData["moduleName"]}) betöltése sikertelen!", $moduleData["moduleName"]);
            }
        }
    }
}
