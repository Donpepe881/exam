<?php
enum LogLevel : int
{
    case Info = 0;
    case Warning = 1;
    case Error = 2;
}

enum LogReportLevel : int
{
    case Silent = 0;
    case Show = 1;
    case Fatal = 2;
}