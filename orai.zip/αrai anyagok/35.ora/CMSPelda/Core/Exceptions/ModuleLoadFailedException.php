<?php

class ModuleLoadFailedException extends Exception
{
    private string $modulename;
    
    public function getModulename(): string
    {
        return $this->modulename;
    }
            
    public function __construct(string $message, string $modulename, Throwable $previous = null)
    {
        parent::__construct($message, 0, $previous);
        $this->modulename = $modulename;
        Logger::LogGeneral($message, LogLevel::Error);
    }
}
