<?php

class TemplateNotFoundException extends Exception
{
    private string $templateFile;
    
    public function getTemplateFile(): string
    {
        return $this->templateFile;
    }
        
    public function __construct(string $message, string $templateFile, Throwable $previous = null)
    {
        parent::__construct($message, 0, $previous);
        $this->templateFile = $templateFile;
        Logger::LogGeneral($message, LogLevel::Error);
    }
}
