<?php

abstract class Logger
{
    public static function LogGeneral(string $logText, LogLevel $level, LogReportLevel $reportLevel = LogReportLevel::Silent, Exception $ex = null) : void
    {
        global $conf;
        $logRow = "[".date("Y.m.d H:i:s")."][{$level->name}] - {$logText}\n";
        if($conf["system"]["generalLogName"] != null)
        {
            $filename = $conf["system"]["logDir"]."/".$conf["system"]["generalLogName"];
        }
        else
        {
            $filename = $conf["system"]["logDir"]."/".date("Y-m-d")."_log.txt";
        }
        file_put_contents($filename, $logRow, FILE_APPEND);
        if($ex != null)
        {
            file_put_contents($filename, "Exception details:\n\tMessage: ".$ex->getMessage()."\n\tFile:".$ex->getFile()."\n\tLine:".$ex->getLine()."\n\tTrace:".$ex->getTraceAsString()."\n", FILE_APPEND);
        }
        switch ($reportLevel)
        {
            case LogReportLevel::Show:
                View::getBaseTemplate($conf["system"]["errorFlag"], $logText);
                break;
            case LogReportLevel::Fatal:
                View::ReportFatalError($logText, $ex);
                break;
        }
    }
    
    public static function LogUser(string $logText, LogLevel $level, string $id = null)
    {
        global $conf;
        $logRow = "[".date("Y.m.d H:i:s")."][{$level->name}] - {$logText}\n";
        if($id != null)
        {
            file_put_contents($conf["system"]["logDir"]."/$id"."_user_log.txt", $logRow, FILE_APPEND);
        }
        elseif(session_id() !== false)
        {
            file_put_contents($conf["system"]["logDir"]."/".session_id()."_user_log.txt", $logRow, FILE_APPEND);
        }
        else
        {
            throw new UserNotRecognisableException("A felhasználó nem azonosítható, így nem is naplózható!");
        }
    }
}
