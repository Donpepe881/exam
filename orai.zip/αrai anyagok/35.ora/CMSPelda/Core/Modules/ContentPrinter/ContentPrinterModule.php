<?php

class ContentPrinterModule extends BaseModuleVisual
{
    private string $key;

    public function __construct(string $key)
    {
        $this->key = $key;
    }

    
    public function Render(): Template
    {
        return $this->template;
    }

    public function Run(): void
    {
        $content = ContentPrinterModuleEntity::GetContent($this->key);
        if($content !== false)
        {
            if($content["template"] != null && $content["flag"] != null)
            {
                $this->template = Template::Load($content["template"]);
                $this->template->AddData($content["flag"], $content["content"]);
            }
            else
            {
                $this->template = Template::Parse($content["content"]);
            }
        }
        else
        {
            //TODO: dobjunk hibát és kezeljük!
        }
    }
}
