<?php

abstract class ContentPrinterModuleEntity
{
    public static function GetContent(string $key) : bool|array
    {
        try
        {
            $result = Model::getCon()->query("SELECT * FROM `contentprinter_data` WHERE `key` = '".Model::getCon()->real_escape_string($key)."'");
            if($result->num_rows > 0)
            {
                $content = $result->fetch_all(MYSQLI_ASSOC)[0];
                $result->free();
                return $content;
            }
            $result->free();
            return false;
        }
        catch (Exception $ex)
        {
            throw new DBException("Sikertelen tartalom betöltés!", $ex);
        }
    }
}
