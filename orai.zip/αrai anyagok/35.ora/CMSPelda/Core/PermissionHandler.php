<?php

abstract class PermissionHandler
{
    private static int $guestId;
    
    public static function getGuestId(): int
    {
        return self::$guestId;
    }
        
    public static function Init()
    {
        self::$guestId = Model::GetGuestId();
    }
    
    public static function CheckRights(int $ownRight, int $targetRight) : bool
    {
        if($ownRight == $targetRight)
        {
            return true;
        }
        $parentRight = Model::GetParentPermission($ownRight);
        if($parentRight == false)
        {
            return false;
        }
        return self::CheckRights($parentRight["id"], $targetRight);
    }
    
    public static function IsUserLoggedIn() : bool
    {
        global $conf;
        return array_key_exists($conf["permission"]["SessionUserKey"], $_SESSION);
    }
    
    public static function GetUserData() : array
    {
        global $conf;
        if(isset($_SESSION[$conf["permission"]["SessionUserKey"]]))
        {
            return $_SESSION[$conf["permission"]["SessionUserKey"]];
        }
        throw new UserNotRecognisableException("Nincs felhasználó belépve!");
    }
    
    
}
