<?php

abstract class View
{
    private static Template $baseTemplate;
    
    public static function getBaseTemplate(): Template
    {
        return self::$baseTemplate;
    }

    public static function setBaseTemplate(Template $baseTemplate): void
    {
        global $conf;
        if(array_search($conf["system"]["errorFlag"], $baseTemplate->getFlags()) !== false)
        {
            self::$baseTemplate = $baseTemplate;
        }
        else
        {
            throw new GeneralViewException("Az alap template nem megfelelő, mivel nincs benne hibajelzési lehetőség!");
        }
    }
    
    public static function Init(string|Template $template) : void
    {
        if(is_a($template, "Template"))
        {
            self::setBaseTemplate($template);
        }
        else
        {
            self::setBaseTemplate(Template::Load($template));
        }
    }
    
    public static function ReportFatalError(string $message, Exception $ex = null) : void
    {
        global $conf;
        self::$baseTemplate = Template::Load($conf["controller"]["fatalErrorTemplate"]);
        self::$baseTemplate->AddData("MESSAGE", $message);
        if($ex != null)
        {
            self::$baseTemplate->AddData("EXMESSAGE", $ex->getMessage());
            self::$baseTemplate->AddData("EXSTACK", $ex->getTraceAsString());
        }
    }
    
    public static function FinalRender(string $contentType = "text/html") : void
    {
        header("Content-type: $contentType");
        print(self::$baseTemplate->Render());
    }
}