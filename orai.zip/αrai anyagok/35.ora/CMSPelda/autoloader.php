<?php
require_once("Core/Enums.php");
spl_autoload_register(function (string $name)
{
    if(strpos($name, "Exception") !== false && file_exists("Core/Exceptions/$name.php"))
    {
        require_once("Core/Exceptions/$name.php");
    }
    elseif(strpos($name, "Module") !== false && file_exists("Core/Modules/".explode("Module", $name)[0]."/$name.php") && strpos($name, "Base") === false)
    {
        require_once("Core/Modules/".explode("Module", $name)[0]."/$name.php");
    }
    elseif(strpos($name, "BaseModule") !== false && file_exists("Core/Modules/$name.php"))
    {
        require_once("Core/Modules/$name.php");
    }
    elseif(file_exists("Core/$name.php"))
    {
        require_once("Core/$name.php");
    }
});