-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2023. Nov 30. 20:19
-- Kiszolgáló verziója: 10.4.28-MariaDB
-- PHP verzió: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `cms`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `contentprinter_data`
--

CREATE TABLE `contentprinter_data` (
  `key` varchar(64) NOT NULL,
  `content` text NOT NULL,
  `template` varchar(128) DEFAULT NULL,
  `flag` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `modules`
--

CREATE TABLE `modules` (
  `id` int(11) NOT NULL,
  `moduleName` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `modules`
--

INSERT INTO `modules` (`id`, `moduleName`) VALUES
(2, 'ContentPrinterModule');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pagemodules`
--

CREATE TABLE `pagemodules` (
  `id` int(11) NOT NULL,
  `moduleId` int(11) NOT NULL,
  `pageId` int(11) NOT NULL,
  `stringParameter` varchar(256) DEFAULT NULL,
  `flagToInsert` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `paramName` varchar(128) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `template` varchar(128) NOT NULL,
  `permission` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `pages`
--

INSERT INTO `pages` (`id`, `paramName`, `parent`, `enabled`, `template`, `permission`) VALUES
(1, 'index', NULL, 1, 'index.html', NULL),
(2, 'admin', NULL, 1, 'admin.html', 1),
(5, 'contact', 1, 1, 'contact.html', NULL),
(6, 'login', 1, 1, 'login.html', 5),
(7, 'register', 1, 1, 'register.html', 5),
(8, 'guestbook', 1, 1, 'guestbook.html', 2);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `permissions`
--

CREATE TABLE `permissions` (
  `id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `password` varchar(128) DEFAULT NULL,
  `isGroup` tinyint(1) NOT NULL DEFAULT 0,
  `parent` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `password`, `isGroup`, `parent`) VALUES
(1, 'Administrators', NULL, 1, NULL),
(2, 'Users', NULL, 1, NULL),
(3, 'admin', '86a53dd33aa2112aa01a03ed488a794cfbbfe92607678827e25b7b1f52dad8a2', 0, 1),
(4, 'bela', 'ded5d6209c6662a847463cbf1cd4f9f8c6312cf12bccfbfcad28ffcf3f5c294a', 0, 2),
(5, 'Guests', NULL, 1, NULL);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `contentprinter_data`
--
ALTER TABLE `contentprinter_data`
  ADD PRIMARY KEY (`key`);

--
-- A tábla indexei `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `pagemodules`
--
ALTER TABLE `pagemodules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pagemodules_page_FK` (`pageId`),
  ADD KEY `pagemodules_modules_FK` (`moduleId`);

--
-- A tábla indexei `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `paramName` (`paramName`);

--
-- A tábla indexei `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `modules`
--
ALTER TABLE `modules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `pagemodules`
--
ALTER TABLE `pagemodules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT a táblához `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `pagemodules`
--
ALTER TABLE `pagemodules`
  ADD CONSTRAINT `pagemodules_modules_FK` FOREIGN KEY (`moduleId`) REFERENCES `modules` (`id`),
  ADD CONSTRAINT `pagemodules_page_FK` FOREIGN KEY (`pageId`) REFERENCES `pages` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
