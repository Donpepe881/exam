<?php
$conf = array();
//AB beállítások
$conf["db"]["host"] = "localhost";
$conf["db"]["user"] = "phpcms";
$conf["db"]["pass"] = "123456aA";
$conf["db"]["db"] = "cms";
$conf["db"]["port"] = "3306";
$conf["db"]["driverConfig"] = MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT;
//Általános beállítások
$conf["controller"]["pageParam"] = "p";
$conf["controller"]["defaultPage"] = "index";
$conf["controller"]["fatalErrorTemplate"] = "fatal.html";
$conf["controller"]["subpageMarker"] = "SUBPAGE";
//Rendszerbeállítások
$conf["system"]["errorFlag"] = "ERROR";
$conf["system"]["logDir"] = "Core/Logs";
$conf["system"]["generalLogName"] = null; //Ha ez ki van töltve, akkor abba a fájlba készül a log, ha nincs, akkor napi bontásban
//User
$conf["permission"]["SessionUserKey"] = "__USER__";
$conf["permission"]["SessionUserPermissionId"] = "PID";