<?php
abstract class Model
{
    private static mysqli $con;
    private static mysqli_driver $driver;
    
    public static function getCon(): mysqli
    {
        return self::$con;
    }

    public static function Connect()
    {
        global $conf;
        try
        {
            self::$driver = new mysqli_driver();
            self::$driver->report_mode = $conf["db"]["driverConfig"];
            self::$con = new mysqli($conf["db"]["host"], $conf["db"]["user"], $conf["db"]["pass"], $conf["db"]["db"], $conf["db"]["port"]);
        } 
        catch (Exception $ex) 
        {
            throw new DBException("Sikertelen adatbázis csatlakozás!", $ex);
        }
    }
    
    public static function Close()
    {
        try
        {
            self::$con->close();
        }
        catch (Exception $ex)
        {
            throw new DBException("Sikertelen adatbázis kapcsolatbontás!", $ex);
        }
    }
    
    public static function IsExistingPage(string $pageName) : bool|array
    {
        try
        {
            $result = self::$con->query("SELECT * FROM `pages` WHERE `paramName` = '".self::$con->real_escape_string($pageName)."'");
            if($result->num_rows > 0)
            {
                $pageData = $result->fetch_all(MYSQLI_ASSOC)[0];
                $result->free();
                return $pageData;
            }
            $result->free();
            return false;
        }
        catch (Exception $ex)
        {
            throw new DBException("Sikertelen oldal ellenőrzés!", $ex);
        }
    }
    
    public static function GetPageById(int $pageID) : bool|array
    {
        try
        {
            $result = self::$con->query("SELECT * FROM `pages` WHERE `id` = $pageID");
            if($result->num_rows > 0)
            {
                $pageData = $result->fetch_all(MYSQLI_ASSOC)[0];
                $result->free();
                return $pageData;
            }
            $result->free();
            return false;
        }
        catch (Exception $ex)
        {
            throw new DBException("Sikertelen oldal lekérdezés!", $ex);
        }
    }
    
    public static function GetPageModules(int $pageID) : array
    {
        try
        {
            $result = self::$con->query("SELECT * FROM `pagemodules` INNER JOIN `modules` ON `pagemodules`.`moduleId` = `modules`.`id` WHERE `pageId` = $pageID");
            $pageData = $result->fetch_all(MYSQLI_ASSOC);
            $result->free();
            return $pageData;
        }
        catch (Exception $ex)
        {
            throw new DBException("Sikertelen modul lista lekérdezés!", $ex);
        }
    }
    
    public static function GetGuestId() : int
    {
        try
        {
            $result = self::$con->query("SELECT `id` FROM `permissions` WHERE `name` = 'Guests'");
            if($result->num_rows > 0)
            {
                $id = $result->fetch_all(MYSQLI_NUM)[0][0];
                $result->free();
                return $id;
            }
            throw new Exception("Az adatbázis nem tartalmaz ilyen csoportot!");
        }
        catch (Exception $ex)
        {
            throw new DBException("A vendég csoport nem található!", $ex);
        }
    }
    
    public static function GetParentPermission(int $id) : bool|array
    {
        try
        {
            $result = self::$con->query("SELECT * FROM `permissions` WHERE `id` = (SELECT `parent` FROM `permissions` WHERE `id` = $id)");
            if($result->num_rows > 0)
            {
                $permission = $result->fetch_all(MYSQLI_ASSOC)[0];
                $result->free();
                return $permission;
            }
            return false;
        } 
        catch (Exception $ex)
        {
            throw new DBException("Hiba a jogok lekérdezése során!", $ex);
        }
    }
}
