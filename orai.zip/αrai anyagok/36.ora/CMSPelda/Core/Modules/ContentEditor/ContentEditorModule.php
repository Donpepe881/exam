<?php

class ContentEditorModule extends BaseModuleVisual
{
    public function __construct()
    {
        $this->template = Template::Load("contentEditorForm.html");
    }
    
    public function Render(): \Template
    {
        return $this->template;
    }

    public function Run(): void
    {
        $allContents = ContentEditorModuleEntity::ListAllContents();
        foreach ($allContents as $page=>$content)
        {
            $contentCount = count($content)+1;
            $pageSection = Template::Parse("<tr><td rowspan=\"$contentCount\">$page</td></tr>§DATA§");
            foreach($content as $data)
            {
                $pageSection->AddData("DATA", "<tr><td>{$data["key"]}</td><td>{$data["content"]}</td><td>{$data["template"]}</td><td>{$data["flag"]}</td></tr>");
            }
            $this->template->AddData("ROWS", $pageSection);
        }
    }
}
