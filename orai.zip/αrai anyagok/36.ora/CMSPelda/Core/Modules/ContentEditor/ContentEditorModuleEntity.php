<?php

abstract class ContentEditorModuleEntity
{
    public static function ListAllContents() : array
    {
        try
        {
            $content = array();
            $result = Model::getCon()->query("SELECT `content`.*, `pages`.`paramName` FROM `contentprinter_data` AS `content` INNER JOIN `pagemodules` ON `content`.`key` = `pagemodules`.`stringParameter` INNER JOIN `pages` ON `pagemodules`.`pageId` = `pages`.`id` ORDER BY `pages`.`paramName`");
            if($result->num_rows > 0)
            {
                while($row = $result->fetch_assoc())
                {
                    $content[$row["paramName"]][] = $row;
                }
                $result->free();
            }
            return $content;
        }
        catch (Exception $ex)
        {
            throw new DBException("Sikertelen tartalom lekérdezés!", $ex);
        }
    }
    
    public static function ModifyContent(string $key, string $content, string $template, string $flag) : void
    {
        try
        {
            Model::getCon()->query("UPDATE `contentprinter_data` SET `content` = '".Model::getCon()->real_escape_string($content)."', `template` = ".(($template == null)?"NULL":"'".Model::getCon()->real_escape_string($template)."'").", `flag` = ".(($flag == null)?"NULL":"'".Model::getCon()->real_escape_string($flag)."' WHERE `key` = '".Model::getCon()->real_escape_string($key)."'"));
        }
        catch (Exception $ex)
        {
            throw new DBException("A módosítás sikertelen!", $ex);
        }
    }
}
