<?php

class LoginModule extends BaseModuleVisual
{
    public function __construct()
    {
        $this->template = Template::Load("loginForm.html");
    }
    
    public function Render(): \Template
    {
        return $this->template;
    }

    public function Run(): void
    {
        global $conf;
        if(isset($_POST["ok"]))
        {
            if(isset($_POST["username"]) && isset($_POST["password"]) && trim($_POST["username"]) != "" && trim($_POST["password"]) != "")
            {
                $user = htmlspecialchars($_POST["username"]);
                $pass = hash("sha256", htmlspecialchars($_POST["password"]));
                $loginResult = LoginModuleEntity::CheckLogin($user, $pass);
                if($loginResult !== false)
                {
                    $_SESSION[$conf["permission"]["SessionUserKey"]] = array($conf["permission"]["SessionUserPermissionId"] => $loginResult[$conf["permission"]["SessionUserPermissionId"]], "parent" => $loginResult["parent"]);
                    header("Location: index.php?".$conf["controller"]["pageParam"]."=".$loginResult["paramName"]);
                }
                else
                {
                    $response = "Hibás felhasználónév / jelszó!";
                }
            }
            else
            {
                $response = "Hiányos felhasználónév / jelszó!";
            }
        }
        $this->template->AddData("TITLE", "Belépés");
        if(isset($response))
        {
            $this->template->AddData("RESPONSE", $response);
        }
    }
}
