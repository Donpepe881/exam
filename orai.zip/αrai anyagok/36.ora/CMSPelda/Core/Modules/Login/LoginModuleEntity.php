<?php

abstract class LoginModuleEntity
{
    public static function CheckLogin(string $username, string $encPass) : bool|array
    {
        global $conf;
        try
        {
            $result = Model::getCon()->query("SELECT `per`.`id` AS `".$conf["permission"]["SessionUserPermissionId"]."`, `per`.`parent`, `page`.`paramName` FROM `permissions` AS `per` INNER JOIN `pages` AS `page` ON `per`.`landing` = `page`.`id` WHERE `per`.`name` = '".Model::getCon()->real_escape_string($username)."' AND `per`.`password` = '".Model::getCon()->real_escape_string($encPass)."'");
            if($result->num_rows > 0)
            {
                $data = $result->fetch_all(MYSQLI_ASSOC)[0];
                $result->free();
                return $data;
            }
            return false;
        }
        catch (Exception $ex)
        {
            throw new DBException("Adatbázis hiba a beléptetés során!", $ex);
        }
    }
}
