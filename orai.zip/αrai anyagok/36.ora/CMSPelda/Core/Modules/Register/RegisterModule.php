<?php

class RegisterModule extends BaseModuleVisual
{
    private int $registerGroup;
    private string $landing;
    
    public function __construct(string $params)
    {
        $this->template = Template::Load("registerForm.html");
        $encArgs = json_decode($params, true);
        $this->registerGroup = intval($encArgs["registerGroup"]);
        $this->landing = $encArgs["landing"];
    }
    
    public function Render(): \Template
    {
        return $this->template;
    }

    public function Run(): void
    {
        global $conf;
        if(isset($_POST["ok"]))
        {
            if(isset($_POST["username"]) && isset($_POST["password"]) && isset($_POST["password2"]) && trim($_POST["username"]) != "" && trim($_POST["password"]) != "" && trim($_POST["password2"]) != "")
            {
                $user = htmlspecialchars($_POST["username"]);
                $pass = hash("sha256", htmlspecialchars($_POST["password"]));
                $pass2 = hash("sha256", htmlspecialchars($_POST["password2"]));
                if($pass == $pass2)
                {
                    if(RegisterModuleEntity::CheckLogin($user))
                    {
                        try
                        {
                            RegisterModuleEntity::RegisterUser($user, $pass, $this->registerGroup, $this->landing);
                            $response["success"] = true;
                            $response["info"] = "Sikeres regisztráció! Belépéshez menjen a belépés oldalra!";
                        }
                        catch (Exception $ex)
                        {
                            $response["success"] = false;
                            $response["info"] = "A regisztráció sikertelen! Egyéb hiba.";
                        }
                    }
                    else
                    {
                        $response["success"] = false;
                        $response["info"] = "A regisztráció sikertelen! Létező felhasználónév!";
                    }
                }
                else
                {
                    $response["success"] = false;
                    $response["info"] = "A regisztráció sikertelen! A két jelszónak meg kell egyeznie!";
                }
            }
            else
            {
                $response["success"] = false;
                $response["info"] = "A regisztráció sikertelen! Hiányos felhasználónév / jelszó!";
            }
        }
        $this->template->AddData("TITLE", "Regisztráció");
        if(isset($response))
        {
            $this->template->AddData("SUCCESS", $response["success"]?"success":"error");
            $this->template->AddData("RESPONSE", $response["info"]);
        }
    }
}
