<?php

class RegisterModuleEntity
{
    public static function CheckLogin(string $username) : bool
    {
        try
        {
            $result = Model::getCon()->query("SELECT * FROM `permissions` WHERE `name` = '".Model::getCon()->real_escape_string($username)."'");
            $loginResult = $result->num_rows === 0;
            $result->free();
            return $loginResult;
        }
        catch (Exception $ex)
        {
            throw new DBException("Adatbázis hiba a felhasználónév ellenőrzése során!", $ex);
        }
    }
    
    public static function RegisterUser(string $username, string $encPass, int $parent, string $landing) : void
    {
        try
        {
            Model::getCon()->query("INSERT INTO `permissions` VALUES (NULL, '".Model::getCon()->real_escape_string($username)."', '".Model::getCon()->real_escape_string($encPass)."', 0, $parent, '".Model::getCon()->real_escape_string($landing)."')");
        }
        catch (Exception $ex)
        {
            throw new DBException("Sikertelen regisztráció!", $ex);
        }
    }
}
