<?php

$conf["methodParam"] = "method";

$conf["DBHost"] = "localhost";
$conf["DBName"] = "vizsgaa";
$conf["DBPort"] = "3307";
$conf["DBUser"] = "pedro";
$conf["DBPass"] = "123456aA";